import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { Navbar } from './components/Navbar.js';
import { Sidebar } from './components/Sidebar.js';
import { AIAdvisorDrawer } from './components/AIAdvisorDrawer.js';

// Views
import { AdminDashboardView } from './views/AdminDashboardView.js';
import { CustomerManagementView } from './views/CustomerManagementView.js';
import { CloudAccountsView } from './views/CloudAccountsView.js';
import { InfrastructureView } from './views/InfrastructureView.js';
import { FinOpsView } from './views/FinOpsView.js';
import { MonitoringView } from './views/MonitoringView.js';
import { SecurityView } from './views/SecurityView.js';
import { AutomationView } from './views/AutomationView.js';
import { AlertsView } from './views/AlertsView.js';
import { TicketsView } from './views/TicketsView.js';
import { ReportsView } from './views/ReportsView.js';
import { AuditLogsView } from './views/AuditLogsView.js';
import { SettingsView } from './views/SettingsView.js';

const MainLayout: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const { user } = useAuth();

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <AdminDashboardView onNavigate={setActiveTab} />;
      case 'customers':
        return <CustomerManagementView />;
      case 'cloud_accounts':
        return <CloudAccountsView />;
      case 'infrastructure':
        return <InfrastructureView />;
      case 'finops':
        return <FinOpsView />;
      case 'monitoring':
        return <MonitoringView />;
      case 'security':
        return <SecurityView />;
      case 'automation':
        return <AutomationView />;
      case 'alerts':
        return <AlertsView />;
      case 'tickets':
        return <TicketsView />;
      case 'reports':
        return <ReportsView />;
      case 'audit_logs':
        return <AuditLogsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <AdminDashboardView onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-nordic-bg text-slate-100 flex flex-col font-sans">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="flex-1 p-6 overflow-y-auto max-w-7xl mx-auto w-full">
          {renderContent()}
        </main>
      </div>
      <AIAdvisorDrawer />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
};

export default App;
