// ====================================================================
// SWEDTEL Web SaaS Platform - Authentication & Tenant Context
// ====================================================================

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserContext, Customer } from '../types.js';
import { ApiClient } from '../api/client.js';

interface AuthContextType {
  user: UserContext;
  selectedRoleKey: string;
  selectedTenantId: string;
  customers: Customer[];
  isAiDrawerOpen: boolean;
  activeAiContext: { prompt: string; contextType: 'FINOPS' | 'SECURITY' | 'INCIDENT_TRIAGE' | 'GENERAL'; incident?: any };
  switchRole: (roleKey: string) => Promise<void>;
  switchTenant: (tenantId: string) => void;
  openAiAdvisor: (contextType: 'FINOPS' | 'SECURITY' | 'INCIDENT_TRIAGE' | 'GENERAL', prompt?: string, incident?: any) => void;
  closeAiAdvisor: () => void;
  refreshCustomers: () => Promise<void>;
}

const defaultUser: UserContext = {
  userId: 'user-admin-001',
  email: 'admin@swedtel.com',
  firstName: 'Erik',
  lastName: 'Lindqvist',
  organizationId: 'org-swedtel-hq',
  organizationType: 'PROVIDER',
  role: 'SUPER_ADMIN',
  permissions: ['*']
};

const AuthContext = createContext<AuthContextType>({
  user: defaultUser,
  selectedRoleKey: 'superadmin',
  selectedTenantId: 'ALL',
  customers: [],
  isAiDrawerOpen: false,
  activeAiContext: { prompt: '', contextType: 'FINOPS' },
  switchRole: async () => {},
  switchTenant: () => {},
  openAiAdvisor: () => {},
  closeAiAdvisor: () => {},
  refreshCustomers: async () => {}
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserContext>(defaultUser);
  const [selectedRoleKey, setSelectedRoleKey] = useState<string>('superadmin');
  const [selectedTenantId, setSelectedTenantId] = useState<string>('ALL');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [activeAiContext, setActiveAiContext] = useState<{ prompt: string; contextType: 'FINOPS' | 'SECURITY' | 'INCIDENT_TRIAGE' | 'GENERAL'; incident?: any }>({
    prompt: '',
    contextType: 'FINOPS'
  });

  const refreshCustomers = async () => {
    try {
      const data = await ApiClient.getCustomers();
      if (Array.isArray(data)) {
        setCustomers(data);
      }
    } catch (e) {
      console.warn('Failed to load customers list', e);
    }
  };

  useEffect(() => {
    refreshCustomers();
  }, []);

  const switchRole = async (roleKey: string) => {
    setSelectedRoleKey(roleKey);
    try {
      const updatedUser = await ApiClient.switchDevRole(roleKey);
      if (updatedUser) {
        setUser(updatedUser);
        if (updatedUser.customerId) {
          setSelectedTenantId(updatedUser.customerId);
          ApiClient.setTenantId(updatedUser.customerId);
        } else {
          setSelectedTenantId('ALL');
          ApiClient.setTenantId('ALL');
        }
      }
    } catch (e) {
      console.warn('Role switch fallback active');
    }
  };

  const switchTenant = (tenantId: string) => {
    setSelectedTenantId(tenantId);
    ApiClient.setTenantId(tenantId);
  };

  const openAiAdvisor = (contextType: 'FINOPS' | 'SECURITY' | 'INCIDENT_TRIAGE' | 'GENERAL', prompt = '', incident?: any) => {
    setActiveAiContext({ contextType, prompt, incident });
    setIsAiDrawerOpen(true);
  };

  const closeAiAdvisor = () => {
    setIsAiDrawerOpen(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        selectedRoleKey,
        selectedTenantId,
        customers,
        isAiDrawerOpen,
        activeAiContext,
        switchRole,
        switchTenant,
        openAiAdvisor,
        closeAiAdvisor,
        refreshCustomers
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
