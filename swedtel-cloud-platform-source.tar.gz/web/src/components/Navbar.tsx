import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import { 
  ShieldCheck, 
  Sparkles, 
  Building2, 
  UserCheck, 
  Bell, 
  Terminal,
  Activity
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    user, 
    selectedRoleKey, 
    selectedTenantId, 
    customers, 
    switchRole, 
    switchTenant,
    openAiAdvisor 
  } = useAuth();

  const isProvider = user.organizationType === 'PROVIDER';

  return (
    <header className="h-16 bg-nordic-card border-b border-nordic-border px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Brand Identity */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-nordic-blue to-nordic-cyan flex items-center justify-center shadow-lg shadow-blue-500/20">
          <Terminal className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-extrabold tracking-wider text-base text-white">SWEDTEL</span>
            <span className="text-xs px-2 py-0.5 rounded bg-blue-950 text-nordic-cyan font-mono border border-blue-800">CLOUD SaaS</span>
          </div>
          <p className="text-[10px] text-slate-400 font-mono">Nordic Enterprise Cloud Platform</p>
        </div>
      </div>

      {/* Global Controls: Tenant Filter & Dev Role Switcher */}
      <div className="flex items-center gap-4">
        {/* Multi-Tenant Filter */}
        {isProvider ? (
          <div className="flex items-center gap-2 bg-nordic-bg border border-nordic-border rounded-lg px-3 py-1.5 text-xs">
            <Building2 className="w-4 h-4 text-nordic-cyan" />
            <span className="text-slate-400">Tenant View:</span>
            <select
              value={selectedTenantId}
              onChange={(e) => switchTenant(e.target.value)}
              aria-label="Filter tenant view by customer organization"
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-nordic-card">Fleet-Wide (All Customers)</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id} className="bg-nordic-card">
                  {c.name} ({c.tier})
                </option>
              ))}
            </select>
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-nordic-bg border border-nordic-border rounded-lg px-3 py-1.5 text-xs">
            <Building2 className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-400">Tenant:</span>
            <span className="text-emerald-400 font-semibold font-mono">
              {customers.find(c => c.id === selectedTenantId)?.name || 'Nordic Health Solutions AB'}
            </span>
          </div>
        )}

        {/* Role Switcher (Allows instant verification of RBAC & Tenant Scopes) */}
        <div className="flex items-center gap-2 bg-nordic-bg border border-nordic-border rounded-lg px-3 py-1.5 text-xs">
          <UserCheck className="w-4 h-4 text-nordic-blue" />
          <span className="text-slate-400">Role:</span>
          <select
            value={selectedRoleKey}
            onChange={(e) => switchRole(e.target.value)}
            aria-label="Switch active user identity and role"
            className="bg-transparent text-nordic-cyan font-semibold focus:outline-none cursor-pointer"
          >
            <option value="superadmin" className="bg-nordic-card">SWEDTEL Super Admin</option>
            <option value="engineer" className="bg-nordic-card">SWEDTEL Cloud Engineer</option>
            <option value="finops" className="bg-nordic-card">SWEDTEL FinOps Specialist</option>
            <option value="customer_admin" className="bg-nordic-card">Customer Admin (NordicHealth)</option>
            <option value="customer_viewer" className="bg-nordic-card">Customer Viewer (Read-Only)</option>
          </select>
        </div>

        {/* Gemini AI Advisor Trigger Button */}
        <button
          onClick={() => openAiAdvisor('FINOPS', 'Analyze our multi-cloud infrastructure and suggest top 3 cost optimizations.')}
          className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-semibold px-3.5 py-1.5 rounded-lg shadow-md shadow-blue-600/20 transition-all"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Gemini AI Advisor</span>
        </button>

        {/* User Badge */}
        <div className="flex items-center gap-2.5 pl-2 border-l border-nordic-border">
          <div className="w-8 h-8 rounded-full bg-nordic-elevated border border-nordic-border flex items-center justify-center text-xs font-bold text-nordic-cyan">
            {user.firstName[0]}{user.lastName[0]}
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs font-medium text-white">{user.firstName} {user.lastName}</div>
            <div className="text-[10px] text-slate-400 font-mono">{user.role}</div>
          </div>
        </div>
      </div>
    </header>
  );
};
