import React from 'react';
import { AlertTriangle, ShieldAlert, X } from 'lucide-react';

interface SafetyApprovalModalProps {
  isOpen: boolean;
  title: string;
  actionDescription: string;
  impactWarning: string;
  targetProvider: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const SafetyApprovalModal: React.FC<SafetyApprovalModalProps> = ({
  isOpen,
  title,
  actionDescription,
  impactWarning,
  targetProvider,
  onConfirm,
  onCancel
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-nordic-card border border-rose-900/60 rounded-2xl max-w-lg w-full shadow-2xl p-6 space-y-5 animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-nordic-border pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-950/80 border border-rose-800 flex items-center justify-center">
              <ShieldAlert className="w-6 h-6 text-rose-500" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Operator Approval Required</h3>
              <p className="text-xs text-rose-400 font-mono">Destructive Action Governance</p>
            </div>
          </div>
          <button onClick={onCancel} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div className="bg-nordic-elevated p-3.5 rounded-xl space-y-1.5 border border-nordic-border">
            <div className="font-bold text-slate-200">{title}</div>
            <div className="text-slate-400 leading-relaxed">{actionDescription}</div>
          </div>

          <div className="bg-rose-950/40 border border-rose-800/60 rounded-xl p-3.5 flex items-start gap-2.5 text-rose-200">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-semibold text-rose-300">Safety Notice:</span>
              <p className="text-[11px] leading-relaxed text-rose-200">{impactWarning}</p>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1">
            <span>Target Provider: <strong className="text-white">{targetProvider}</strong></span>
            <span>Policy: SOC 2 CC6.8 Approval</span>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded-lg bg-nordic-elevated hover:bg-nordic-border text-slate-300 text-xs font-semibold transition-all"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-lg shadow-rose-600/30 transition-all"
          >
            Authorize & Execute Action
          </button>
        </div>
      </div>
    </div>
  );
};
