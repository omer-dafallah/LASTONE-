import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { Cloud, X, CheckCircle2, AlertCircle, Key, ShieldCheck } from 'lucide-react';

interface ConnectCloudModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const ConnectCloudModal: React.FC<ConnectCloudModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { customers, selectedTenantId } = useAuth();
  const [provider, setProvider] = useState<'GCP' | 'AWS' | 'AZURE'>('GCP');
  const [connectionMode, setConnectionMode] = useState<'DEMO' | 'LIVE'>('DEMO');
  const [customerId, setCustomerId] = useState<string>(selectedTenantId !== 'ALL' ? selectedTenantId : customers[0]?.id || '');
  const [accountName, setAccountName] = useState('');
  const [accountOrProjectId, setAccountOrProjectId] = useState('');
  const [targetServiceAccount, setTargetServiceAccount] = useState('');
  const [environment, setEnvironment] = useState<'PRODUCTION' | 'STAGING' | 'DEVELOPMENT'>('PRODUCTION');
  const [connectionType, setConnectionType] = useState<'WIF' | 'STS_ASSUME_ROLE' | 'SERVICE_PRINCIPAL'>('WIF');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<string | null>(null);
  const [validationSuccess, setValidationSuccess] = useState<any | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setErrorCode(null);
    setLoading(true);
    setValidationSuccess(null);

    try {
      const res = await ApiClient.connectCloudAccount({
        customerId,
        provider,
        name: accountName,
        accountOrProjectId,
        connectionMode,
        targetServiceAccount: targetServiceAccount ? targetServiceAccount.trim() : undefined,
        environment,
        connectionType
      });

      setValidationSuccess(res.validation);
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1600);
    } catch (err: any) {
      setError(err.message || 'Failed to connect cloud account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-nordic-card border border-nordic-border rounded-2xl max-w-xl w-full shadow-2xl p-6 space-y-5 animate-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-nordic-border pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-nordic-blue/20 border border-nordic-blue flex items-center justify-center">
              <Cloud className="w-6 h-6 text-nordic-cyan" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Connect Cloud Account</h3>
              <p className="text-xs text-slate-400 font-mono">Server-Side Keyless Workload Identity</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="bg-rose-950/50 border border-rose-800 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-rose-200">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-rose-300">Connection Failed</p>
              <p className="mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {validationSuccess && (
          <div className="bg-emerald-950/50 border border-emerald-800 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-emerald-300">Cloud Account Verified & Resources Discovered!</p>
              <p className="text-[11px] text-emerald-400 font-mono">Principal: {validationSuccess.identityPrincipal}</p>
              {validationSuccess.detectedPermissions && validationSuccess.detectedPermissions.length > 0 && (
                <p className="text-[10px] text-slate-300">
                  Verified IAM Roles: {validationSuccess.detectedPermissions.join(', ')}
                </p>
              )}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Connection Mode Selection */}
          {provider === 'GCP' && (
            <div className="bg-nordic-elevated p-3 rounded-xl border border-nordic-border space-y-2">
              <label className="block text-slate-300 font-semibold">Integration Mode</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setConnectionMode('DEMO')}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    connectionMode === 'DEMO'
                      ? 'bg-blue-950/60 border-nordic-cyan text-white shadow-md'
                      : 'bg-nordic-bg border-nordic-border text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="font-bold flex items-center justify-between">
                    <span>Demo Sandbox</span>
                    <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">SIMULATED</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Simulated telecom infrastructure with full sandbox control.</p>
                </button>
                <button
                  type="button"
                  onClick={() => setConnectionMode('LIVE')}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    connectionMode === 'LIVE'
                      ? 'bg-emerald-950/60 border-emerald-400 text-white shadow-md'
                      : 'bg-nordic-bg border-nordic-border text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="font-bold flex items-center justify-between">
                    <span>Live Google Cloud</span>
                    <span className="text-[9px] bg-emerald-900/60 text-emerald-400 px-1.5 py-0.5 rounded">READ-ONLY</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Real-time resource discovery via ADC / IAM Service Account.</p>
                </button>
              </div>
            </div>
          )}

          {/* Provider Choice */}
          <div>
            <label className="block text-slate-400 font-semibold mb-2">Cloud Provider</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => { setProvider('GCP'); setConnectionType('WIF'); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                  provider === 'GCP'
                    ? 'bg-blue-950/60 border-nordic-cyan text-white shadow-lg'
                    : 'bg-nordic-elevated border-nordic-border text-slate-400 hover:text-white'
                }`}
              >
                <Cloud className="w-5 h-5 text-blue-400" />
                <span className="font-bold">Google Cloud</span>
                <span className="text-[9px] text-emerald-400 font-mono">LIVE / DEMO</span>
              </button>
              <button
                type="button"
                onClick={() => { setProvider('AWS'); setConnectionType('STS_ASSUME_ROLE'); setConnectionMode('DEMO'); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                  provider === 'AWS'
                    ? 'bg-amber-950/60 border-amber-500 text-white shadow-lg'
                    : 'bg-nordic-elevated border-nordic-border text-slate-400 hover:text-white'
                }`}
              >
                <Cloud className="w-5 h-5 text-amber-400" />
                <span className="font-bold">AWS</span>
                <span className="text-[9px] text-amber-400 font-mono">DEMO SANDBOX</span>
              </button>
              <button
                type="button"
                onClick={() => { setProvider('AZURE'); setConnectionType('SERVICE_PRINCIPAL'); setConnectionMode('DEMO'); }}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                  provider === 'AZURE'
                    ? 'bg-sky-950/60 border-sky-500 text-white shadow-lg'
                    : 'bg-nordic-elevated border-nordic-border text-slate-400 hover:text-white'
                }`}
              >
                <Cloud className="w-5 h-5 text-sky-400" />
                <span className="font-bold">Azure</span>
                <span className="text-[9px] text-sky-400 font-mono">DEMO SANDBOX</span>
              </button>
            </div>
          </div>

          {/* Customer Organization Selection */}
          <div>
            <label className="block text-slate-400 font-semibold mb-1">Customer Organization</label>
            <select
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
              required
            >
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.code})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Account Display Name</label>
              <input
                type="text"
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                placeholder="e.g. NordicHealth GKE Prod"
                className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                required
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Environment</label>
              <select
                value={environment}
                onChange={(e) => setEnvironment(e.target.value as any)}
                className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
              >
                <option value="PRODUCTION">Production</option>
                <option value="STAGING">Staging</option>
                <option value="DEVELOPMENT">Development</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-semibold mb-1">
              {provider === 'GCP' ? 'Google Cloud Project ID' : provider === 'AWS' ? 'AWS 12-Digit Account ID' : 'Azure Subscription ID (UUID)'}
            </label>
            <input
              type="text"
              value={accountOrProjectId}
              onChange={(e) => setAccountOrProjectId(e.target.value)}
              placeholder={provider === 'GCP' ? 'e.g. my-company-prod-1234' : provider === 'AWS' ? 'e.g. 829471928410' : 'e.g. a4f9104c-32ef-410a-9ff1-998811223344'}
              className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-nordic-blue"
              required
            />
          </div>

          {provider === 'GCP' && connectionMode === 'LIVE' && (
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Target Service Account for Impersonation (Optional)
              </label>
              <input
                type="email"
                value={targetServiceAccount}
                onChange={(e) => setTargetServiceAccount(e.target.value)}
                placeholder="e.g. swedtel-viewer@my-project.iam.gserviceaccount.com"
                className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-nordic-blue"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Leave empty to use Server Application Default Credentials (ADC) directly.
              </p>
            </div>
          )}

          <div className="bg-nordic-elevated/70 p-3 rounded-xl border border-nordic-border flex items-start gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-nordic-cyan shrink-0 mt-0.5" />
            <p>
              <strong>Zero Secret Leakage Architecture:</strong> Credentials and tokens are managed entirely server-side via Workload Identity Federation / ADC. No private keys or tokens are ever exposed to or stored on the browser.
            </p>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-nordic-elevated hover:bg-nordic-border text-slate-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-lg bg-nordic-blue hover:bg-blue-600 disabled:opacity-50 text-white text-xs font-semibold shadow-lg shadow-blue-600/30"
            >
              {loading ? 'Validating Connection...' : 'Verify & Connect Account'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
