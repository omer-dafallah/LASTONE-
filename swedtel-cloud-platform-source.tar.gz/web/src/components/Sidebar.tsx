import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  LayoutDashboard,
  Building2,
  Cloud,
  Server,
  DollarSign,
  Activity,
  ShieldCheck,
  Zap,
  AlertTriangle,
  LifeBuoy,
  FileText,
  History,
  Settings
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const { user } = useAuth();
  const isProvider = user.organizationType === 'PROVIDER';

  const navItems = [
    { id: 'dashboard', label: isProvider ? 'Admin Overview' : 'Customer Portal', icon: LayoutDashboard },
    ...(isProvider ? [{ id: 'customers', label: 'Customers', icon: Building2 }] : []),
    { id: 'cloud_accounts', label: 'Cloud Accounts', icon: Cloud },
    { id: 'infrastructure', label: 'Infrastructure', icon: Server },
    { id: 'finops', label: 'FinOps & Costs', icon: DollarSign },
    { id: 'monitoring', label: 'Monitoring', icon: Activity },
    { id: 'security', label: 'Security & CIS', icon: ShieldCheck },
    { id: 'automation', label: 'Automation', icon: Zap },
    { id: 'alerts', label: 'Alerts & SRE', icon: AlertTriangle },
    { id: 'tickets', label: 'Support Desk', icon: LifeBuoy },
    { id: 'reports', label: 'Executive Reports', icon: FileText },
    ...(isProvider ? [{ id: 'audit_logs', label: 'SOC 2 Audit Logs', icon: History }] : []),
    { id: 'settings', label: 'Platform & GCP', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-nordic-card border-r border-nordic-border flex flex-col justify-between p-4 h-[calc(100vh-4rem)] sticky top-16">
      <div className="space-y-1">
        <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono">
          {isProvider ? 'Fleet Operations' : 'Customer Workspace'}
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-nordic-blue text-white shadow-lg shadow-blue-500/20 font-semibold'
                  : 'text-slate-300 hover:bg-nordic-elevated hover:text-white'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Cloud Status Footer Widget */}
      <div className="bg-nordic-bg/70 border border-nordic-border rounded-lg p-3 text-xs space-y-2">
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono">GCP Adapter</span>
          <span className="flex items-center gap-1.5 text-emerald-400 font-mono font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            WIF Ready
          </span>
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono">PostgreSQL</span>
          <span className="text-nordic-cyan font-mono">Cloud SQL Pool</span>
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono">Gemini AI</span>
          <span className="text-blue-400 font-mono">Pro / Flash Lite</span>
        </div>
      </div>
    </aside>
  );
};
