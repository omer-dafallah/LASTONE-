import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { Sparkles, X, Send, Bot, Shield, Zap, RefreshCw } from 'lucide-react';

export const AIAdvisorDrawer: React.FC = () => {
  const { isAiDrawerOpen, closeAiAdvisor, activeAiContext, selectedTenantId } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [contextType, setContextType] = useState<'FINOPS' | 'SECURITY' | 'INCIDENT_TRIAGE' | 'GENERAL'>('FINOPS');
  const [loading, setLoading] = useState(false);
  const [responseMarkdown, setResponseMarkdown] = useState<string | null>(null);
  const [metaInfo, setMetaInfo] = useState<{ model: string; durationMs: number; isFallback: boolean } | null>(null);

  useEffect(() => {
    if (activeAiContext.contextType) {
      setContextType(activeAiContext.contextType);
    }
    if (activeAiContext.prompt) {
      setPrompt(activeAiContext.prompt);
      // Auto-trigger if pre-set prompt provided
      handleConsult(activeAiContext.prompt, activeAiContext.contextType, activeAiContext.incident);
    }
  }, [activeAiContext]);

  const handleConsult = async (queryText?: string, type?: string, incident?: any) => {
    const textToSubmit = queryText || prompt;
    if (!textToSubmit.trim()) return;

    setLoading(true);
    setResponseMarkdown(null);

    try {
      const res = await ApiClient.consultAI(
        textToSubmit,
        type || contextType,
        selectedTenantId !== 'ALL' ? selectedTenantId : undefined,
        incident || activeAiContext.incident
      );

      setResponseMarkdown(res.markdownResponse);
      setMetaInfo({
        model: res.modelUsed,
        durationMs: res.executionDurationMs,
        isFallback: res.isFallback
      });
    } catch (err: unknown) {
      setResponseMarkdown(`⚠️ Consultation request failed: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  };

  if (!isAiDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-2xl bg-nordic-card border-l border-nordic-border h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-5 border-b border-nordic-border flex items-center justify-between bg-nordic-elevated/40">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">SWEDTEL Gemini Enterprise Advisor</h3>
              <p className="text-xs text-slate-400 font-mono">Server-Side Multi-Cloud Intelligence</p>
            </div>
          </div>
          <button
            onClick={closeAiAdvisor}
            className="p-1.5 rounded-lg hover:bg-nordic-border text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="px-5 py-3 border-b border-nordic-border flex items-center gap-2 bg-nordic-bg/50">
          <button
            onClick={() => { setContextType('FINOPS'); setPrompt('Provide multi-cloud FinOps rightsizing recommendations.'); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              contextType === 'FINOPS'
                ? 'bg-nordic-blue text-white'
                : 'bg-nordic-elevated text-slate-300 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            FinOps Advisor
          </button>
          <button
            onClick={() => { setContextType('INCIDENT_TRIAGE'); setPrompt('Analyze high memory utilization and provide immediate SRE remediation runbook.'); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              contextType === 'INCIDENT_TRIAGE'
                ? 'bg-rose-600 text-white'
                : 'bg-nordic-elevated text-slate-300 hover:text-white'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Flash SRE Triage
          </button>
          <button
            onClick={() => { setContextType('SECURITY'); setPrompt('Review CIS GCP 5.1 Storage permissions remediation.'); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              contextType === 'SECURITY'
                ? 'bg-emerald-600 text-white'
                : 'bg-nordic-elevated text-slate-300 hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            CIS Security
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 font-sans text-sm">
          {loading && (
            <div className="flex flex-col items-center justify-center py-20 space-y-3 text-slate-400">
              <Sparkles className="w-8 h-8 text-nordic-cyan animate-spin" />
              <p className="text-xs font-mono">Querying server-side Gemini ({contextType === 'INCIDENT_TRIAGE' ? 'gemini-3.1-flash-lite' : 'gemini-3.1-pro'})...</p>
            </div>
          )}

          {responseMarkdown && (
            <div className="space-y-4">
              {metaInfo && (
                <div className="flex items-center justify-between text-[11px] font-mono bg-nordic-bg border border-nordic-border px-3 py-2 rounded-lg text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <Bot className="w-3.5 h-3.5 text-nordic-cyan" />
                    Model: <strong className="text-white">{metaInfo.model}</strong>
                  </span>
                  <span>Latency: {metaInfo.durationMs}ms</span>
                </div>
              )}
              <div className="bg-nordic-elevated/60 border border-nordic-border rounded-xl p-5 text-slate-200 leading-relaxed whitespace-pre-wrap font-sans text-xs">
                {responseMarkdown}
              </div>
            </div>
          )}

          {!loading && !responseMarkdown && (
            <div className="text-center py-16 text-slate-400 space-y-3">
              <Bot className="w-12 h-12 mx-auto text-slate-600" />
              <p className="text-sm font-medium text-slate-300">Ready for Multi-Cloud Advisory</p>
              <p className="text-xs max-w-sm mx-auto text-slate-400">
                Ask architectural questions, request rightsizing analysis, or trigger SRE triage.
              </p>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-nordic-border bg-nordic-elevated/40">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleConsult();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ask Gemini Cloud Advisor..."
              className="flex-1 bg-nordic-bg border border-nordic-border rounded-lg px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-nordic-blue"
            />
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className="bg-nordic-blue hover:bg-blue-600 disabled:opacity-50 text-white p-2.5 rounded-lg transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
