import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { SecurityFinding } from '../types.js';
import { 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Wrench, 
  Sparkles, 
  Lock, 
  FileCheck 
} from 'lucide-react';

export const SecurityView: React.FC = () => {
  const { selectedTenantId, openAiAdvisor } = useAuth();
  const [securityData, setSecurityData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [remediatingId, setRemediatingId] = useState<string | null>(null);

  const loadSecurity = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getSecurityFindings();
      setSecurityData(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSecurity();
  }, [selectedTenantId]);

  const handleRemediate = async (id: string) => {
    setRemediatingId(id);
    try {
      await ApiClient.remediateFinding(id);
      await loadSecurity();
    } catch (err: unknown) {
      alert(`Remediation failed: ${(err as Error).message}`);
    } finally {
      setRemediatingId(null);
    }
  };

  const findings: SecurityFinding[] = securityData?.findings || [];
  const score = securityData?.score || 94;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Security & CIS Benchmark Compliance</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            CIS Google Cloud Foundation Benchmark v2.0 & SOC 2 Continuous Audit
          </p>
        </div>
        <button
          onClick={() => openAiAdvisor('SECURITY', 'Provide an audit overview and remediation roadmap for open CIS findings.')}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs font-semibold shadow-lg shadow-emerald-600/20"
        >
          <Sparkles className="w-4 h-4" />
          <span>Gemini Security Advisor</span>
        </button>
      </div>

      {/* Compliance Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <span className="text-xs text-slate-400 font-medium">CIS Compliance Posture</span>
          <div className="text-3xl font-extrabold text-emerald-400 font-mono">{score}%</div>
          <div className="text-xs text-slate-400">
            Passing: <strong className="text-white">18 of 20</strong> core controls
          </div>
          <div className="w-full bg-nordic-bg rounded-full h-2 overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${score}%` }}></div>
          </div>
        </div>

        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <span className="text-xs text-slate-400 font-medium">Continuous SOC 2 Readiness</span>
          <div className="text-2xl font-extrabold text-white">TYPE II AUDIT</div>
          <div className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium">
            <CheckCircle2 className="w-4 h-4" /> Continuous Monitoring Active
          </div>
          <p className="text-[11px] text-slate-400 font-mono">Zero Public Buckets • CMEK Validated</p>
        </div>

        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <span className="text-xs text-slate-400 font-medium">Open Remediation Items</span>
          <div className="text-2xl font-extrabold text-amber-400 font-mono">
            {findings.filter(f => f.status === 'OPEN').length} Issues
          </div>
          <div className="text-xs text-slate-400">
            1-Click Automated Fix Available
          </div>
          <div className="text-[11px] text-slate-400 font-mono">Audit logged with operator identity</div>
        </div>
      </div>

      {/* Findings Table */}
      <div className="bg-nordic-card border border-nordic-border rounded-xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-nordic-border flex items-center justify-between bg-nordic-elevated/40">
          <h3 className="font-bold text-sm text-white">CIS Benchmark Findings & Security Controls</h3>
          <span className="text-xs text-slate-400 font-mono">SOC 2 CC6.8 Baseline</span>
        </div>

        <div className="divide-y divide-nordic-border">
          {findings.map((f) => (
            <div key={f.id} className="p-5 space-y-3 hover:bg-nordic-elevated/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                    f.severity === 'CRITICAL' || f.severity === 'HIGH'
                      ? 'bg-rose-950 text-rose-300 border-rose-800'
                      : 'bg-amber-950 text-amber-300 border-amber-800'
                  }`}>
                    {f.severity}
                  </span>
                  <span className="text-xs font-mono font-bold text-nordic-cyan">
                    {f.complianceFramework} • {f.cisControlId}
                  </span>
                </div>

                <span className={`text-xs font-semibold px-2.5 py-0.5 rounded ${
                  f.status === 'RESOLVED'
                    ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                    : 'bg-rose-950/60 text-rose-400 border border-rose-800'
                }`}>
                  {f.status}
                </span>
              </div>

              <div>
                <h4 className="font-bold text-sm text-white">{f.title}</h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{f.description}</p>
              </div>

              <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 text-xs space-y-1">
                <span className="font-semibold text-slate-300">Recommended Remediation:</span>
                <p className="text-slate-400 font-mono text-[11px]">{f.remediationSteps}</p>
              </div>

              {f.status === 'OPEN' && (
                <div className="flex items-center justify-end gap-3 pt-1">
                  <button
                    onClick={() => openAiAdvisor('SECURITY', `Explain how to fix CIS issue: ${f.title}`, f)}
                    className="px-3 py-1.5 rounded-lg bg-nordic-elevated hover:bg-nordic-border text-slate-300 text-xs font-semibold transition-all flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-nordic-cyan" />
                    <span>Explain Fix</span>
                  </button>
                  <button
                    onClick={() => handleRemediate(f.id)}
                    disabled={remediatingId === f.id}
                    className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md shadow-emerald-600/30 flex items-center gap-1.5"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>{remediatingId === f.id ? 'Applying Fix...' : '1-Click Auto-Remediate'}</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
