import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { CloudAccount } from '../types.js';
import { ConnectCloudModal } from '../components/ConnectCloudModal.js';
import { 
  Cloud, 
  Plus, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Activity,
  Layers,
  Key
} from 'lucide-react';

export const CloudAccountsView: React.FC = () => {
  const { selectedTenantId } = useAuth();
  const [accounts, setAccounts] = useState<CloudAccount[]>([]);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [syncingId, setSyncingId] = useState<string | null>(null);

  const loadAccounts = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getCloudAccounts();
      setAccounts(data || []);
    } finally {
      setLoading(false);
    }
  };

  const handleSyncAccount = async (accountId: string) => {
    setSyncingId(accountId);
    try {
      await ApiClient.syncCloudAccount(accountId);
      await loadAccounts();
    } catch (err: any) {
      alert(`Sync failed: ${err.message}`);
    } finally {
      setSyncingId(null);
    }
  };

  useEffect(() => {
    loadAccounts();
  }, [selectedTenantId]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Connected Cloud Accounts</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Keyless Federated Integrations with Live GCP & Demo Sandboxes
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={loadAccounts}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-nordic-elevated hover:bg-nordic-border text-slate-300 text-xs font-semibold border border-nordic-border transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => setIsConnectModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-nordic-blue hover:bg-blue-600 text-white text-xs font-semibold shadow-lg shadow-blue-600/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Connect Cloud Account</span>
          </button>
        </div>
      </div>

      {/* Account Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {accounts.map((acc) => {
          const isGcp = acc.provider === 'GCP';
          const isAws = acc.provider === 'AWS';
          const isAzure = acc.provider === 'AZURE';
          const isLive = acc.connectionMode === 'LIVE' || (!acc.isDemo && isGcp);
          const isCurrentlySyncing = syncingId === acc.id || acc.lastSyncStatus === 'SYNCING';

          return (
            <div
              key={acc.id}
              className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4 hover:border-nordic-blue/60 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                    isGcp 
                      ? 'bg-blue-950 text-nordic-cyan border-blue-800' 
                      : isAws 
                      ? 'bg-amber-950 text-amber-300 border-amber-800' 
                      : 'bg-sky-950 text-sky-300 border-sky-800'
                  }`}>
                    {acc.provider} • {acc.environment}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className={`flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded border ${
                      isLive
                        ? 'text-emerald-400 bg-emerald-950/60 border-emerald-800'
                        : 'text-slate-300 bg-slate-800 border-slate-700'
                    }`}>
                      {isLive ? (
                        <>
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                          LIVE GCP
                        </>
                      ) : (
                        'DEMO SANDBOX'
                      )}
                    </span>
                  </div>
                </div>

                <div>
                  <h3 className="font-bold text-sm text-white">{acc.name}</h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5 truncate">
                    ID: {acc.accountOrProjectId}
                  </p>
                  {acc.targetServiceAccount && (
                    <p className="text-[10px] text-nordic-cyan font-mono truncate mt-0.5">
                      SA: {acc.targetServiceAccount}
                    </p>
                  )}
                </div>

                <div className="bg-nordic-elevated/60 rounded-lg p-3 space-y-1.5 text-xs border border-nordic-border/50 font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-sans">Auth Architecture:</span>
                    <span className="text-nordic-cyan font-bold">{acc.connectionType}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-sans">Resources:</span>
                    <strong className="text-white">{acc.resourceCount || 0} discovered</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-sans">Monthly Cost:</span>
                    <strong className="text-emerald-400">€{(acc.monthlyCost || 0).toLocaleString()}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-sans">Status:</span>
                    <span className={acc.status === 'CONNECTED' ? 'text-emerald-400' : 'text-amber-400'}>
                      {acc.status}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-nordic-border flex items-center justify-between text-xs">
                <div className="text-[10px] text-slate-400 font-mono truncate max-w-[140px]">
                  {acc.customerName || 'Nordic Health Solutions'}
                </div>
                <button
                  onClick={() => handleSyncAccount(acc.id)}
                  disabled={isCurrentlySyncing}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-nordic-elevated hover:bg-nordic-border text-slate-200 text-[11px] font-semibold border border-nordic-border transition-all disabled:opacity-50"
                  title="Trigger immediate discovery sync"
                >
                  <RefreshCw className={`w-3 h-3 text-nordic-cyan ${isCurrentlySyncing ? 'animate-spin' : ''}`} />
                  <span>{isCurrentlySyncing ? 'Syncing...' : 'Sync'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <ConnectCloudModal
        isOpen={isConnectModalOpen}
        onClose={() => setIsConnectModalOpen(false)}
        onSuccess={loadAccounts}
      />
    </div>
  );
};
