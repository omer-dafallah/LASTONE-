import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { CloudResource } from '../types.js';
import { Activity, RefreshCw, Cpu, Database, HardDrive, Wifi, CheckCircle2 } from 'lucide-react';

export const MonitoringView: React.FC = () => {
  const { selectedTenantId } = useAuth();
  const [resources, setResources] = useState<CloudResource[]>([]);
  const [loading, setLoading] = useState(true);

  const loadMetrics = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getResources();
      setResources(data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMetrics();
    const timer = setInterval(loadMetrics, 10000); // 10s live polling
    return () => clearInterval(timer);
  }, [selectedTenantId]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Real-Time Telemetry & Monitoring</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Cloud Monitoring & CloudWatch Live Telemetry Stream (10s Polling)
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800 text-[11px] text-emerald-400 font-mono font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Streaming Live Metrics
          </span>
          <button
            onClick={loadMetrics}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-nordic-card border border-nordic-border text-xs text-slate-300 hover:text-white"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Poll Now</span>
          </button>
        </div>
      </div>

      {/* Resource Telemetry Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {resources.map((r) => (
          <div
            key={r.id}
            className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4 shadow-lg hover:border-nordic-blue/60 transition-all"
          >
            <div className="flex items-center justify-between border-b border-nordic-border pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-white font-mono">{r.name}</h3>
                  <span className={`text-[10px] font-bold font-mono px-1.5 py-0.2 rounded ${
                    r.provider === 'GCP' ? 'bg-blue-950 text-blue-300' : r.provider === 'AWS' ? 'bg-amber-950 text-amber-300' : 'bg-sky-950 text-sky-300'
                  }`}>
                    {r.provider}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">{r.region} • {r.resourceType}</div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                r.status === 'HEALTHY' ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800' : 'bg-rose-950/60 text-rose-400 border-rose-800'
              }`}>
                {r.status}
              </span>
            </div>

            {/* Metrics Progress Grid */}
            <div className="grid grid-cols-2 gap-4 text-xs">
              {/* CPU */}
              <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 space-y-1.5">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Cpu className="w-3.5 h-3.5 text-nordic-cyan" /> CPU Load
                  </span>
                  <strong className="text-white font-mono">{r.cpuUtilizationPct}%</strong>
                </div>
                <div className="w-full bg-nordic-bg rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${r.cpuUtilizationPct > 80 ? 'bg-rose-500' : 'bg-nordic-cyan'}`}
                    style={{ width: `${r.cpuUtilizationPct}%` }}
                  ></div>
                </div>
              </div>

              {/* Memory */}
              <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 space-y-1.5">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Database className="w-3.5 h-3.5 text-indigo-400" /> Memory Util
                  </span>
                  <strong className="text-white font-mono">{r.memoryUtilizationPct}%</strong>
                </div>
                <div className="w-full bg-nordic-bg rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${r.memoryUtilizationPct > 80 ? 'bg-amber-500' : 'bg-indigo-500'}`}
                    style={{ width: `${r.memoryUtilizationPct}%` }}
                  ></div>
                </div>
              </div>

              {/* Disk I/O */}
              <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 space-y-1.5">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1.5 font-medium">
                    <HardDrive className="w-3.5 h-3.5 text-emerald-400" /> Disk Usage
                  </span>
                  <strong className="text-white font-mono">{r.diskUtilizationPct}%</strong>
                </div>
                <div className="w-full bg-nordic-bg rounded-full h-1.5 overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${r.diskUtilizationPct}%` }}></div>
                </div>
              </div>

              {/* Network Throughput */}
              <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 space-y-1.5">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Wifi className="w-3.5 h-3.5 text-sky-400" /> Network In/Out
                  </span>
                  <strong className="text-white font-mono">{r.networkInMbps}M</strong>
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  ↓ {r.networkInMbps} Mbps • ↑ {r.networkOutMbps} Mbps
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1">
              <span>Telemetry Source: Google Cloud Monitoring API</span>
              <span>Updated: Just now</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
