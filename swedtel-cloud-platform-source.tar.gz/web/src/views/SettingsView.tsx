import React from 'react';
import { 
  Server, 
  Database, 
  Key, 
  ShieldCheck, 
  Cloud, 
  Sparkles, 
  CheckCircle2, 
  Terminal, 
  ExternalLink 
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Platform Architecture & Google Cloud Deployment</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Production Readiness Checklist & Workload Identity Federation (WIF) Architecture
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-950/60 border border-blue-800 text-xs text-nordic-cyan font-mono">
          <Cloud className="w-4 h-4" />
          <span>GCP Target Architecture Ready</span>
        </div>
      </div>

      {/* GCP Deployment Topology */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Component 1: Cloud Run */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Server className="w-5 h-5 text-nordic-blue" />
              <h3 className="font-bold text-sm text-white">Google Cloud Run (API Backend)</h3>
            </div>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              PRODUCTION READY
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Stateless containerized Node.js/TypeScript REST API with automated scaling (0 to 100 instances), zero-downtime rolling updates, and internal VPC connector for Cloud SQL peering.
          </p>
          <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 font-mono text-[11px] text-slate-300 space-y-1">
            <div>Region: <strong>europe-north1 (Hamina, Finland)</strong></div>
            <div>Min Instances: 1 • Max: 50</div>
            <div>Direct VPC Egress: Enabled</div>
          </div>
        </div>

        {/* Component 2: Cloud SQL PostgreSQL */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Database className="w-5 h-5 text-nordic-cyan" />
              <h3 className="font-bold text-sm text-white">Google Cloud SQL (PostgreSQL 16)</h3>
            </div>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              HA REGIONAL
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            High-availability PostgreSQL cluster with automated cross-zone failover, automated point-in-time recovery (PITR), and private IP only access with IAM database authentication.
          </p>
          <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 font-mono text-[11px] text-slate-300 space-y-1">
            <div>Engine: <strong>PostgreSQL 16 Enterprise</strong></div>
            <div>Storage: Auto-increasing SSD with CMEK</div>
            <div>Connection: Cloud SQL Auth Proxy</div>
          </div>
        </div>

        {/* Component 3: Secret Manager */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Key className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-sm text-white">Google Secret Manager</h3>
            </div>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              ZERO CLIENT LEAKAGE
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            All database credentials, JWT secrets, and Gemini API keys are loaded dynamically server-side at container startup. The web browser never touches sensitive credentials.
          </p>
          <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 font-mono text-[11px] text-slate-300 space-y-1">
            <div>IAM Role: <code>roles/secretmanager.secretAccessor</code></div>
            <div>Rotation: 90 Days Automated</div>
          </div>
        </div>

        {/* Component 4: Workload Identity Federation (WIF) */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-sm text-white">Keyless Multi-Cloud Federation (WIF)</h3>
            </div>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              KEYLESS AUTH
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Eliminates downloadable JSON service account keys. Cross-account access uses short-lived tokens via Workload Identity Pools and AWS STS AssumeRole.
          </p>
          <div className="bg-nordic-elevated/60 p-3 rounded-lg border border-nordic-border/50 font-mono text-[11px] text-slate-300 space-y-1">
            <div>Principal: <code>swedtel-hub@swedtel-cloud-platform.iam.gserviceaccount.com</code></div>
            <div>Token Expiration: 3600 seconds max</div>
          </div>
        </div>
      </div>

      {/* Production Deployment Architecture Summary */}
      <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Terminal className="w-4 h-4 text-nordic-cyan" />
          <span>Google Cloud Deployment Verification Artifacts</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
          <div className="bg-nordic-elevated p-3 rounded-lg border border-nordic-border space-y-1">
            <div className="text-slate-400 text-[10px]">TERRAFORM / INFRA</div>
            <div className="font-bold text-white">/infra/terraform/</div>
            <div className="text-emerald-400 text-[11px]">✓ Cloud Run & SQL</div>
          </div>
          <div className="bg-nordic-elevated p-3 rounded-lg border border-nordic-border space-y-1">
            <div className="text-slate-400 text-[10px]">DATABASE MIGRATIONS</div>
            <div className="font-bold text-white">/server/migrations/</div>
            <div className="text-emerald-400 text-[11px]">✓ Schema & Seeds</div>
          </div>
          <div className="bg-nordic-elevated p-3 rounded-lg border border-nordic-border space-y-1">
            <div className="text-slate-400 text-[10px]">CONTAINER SPEC</div>
            <div className="font-bold text-white">Dockerfile & compose</div>
            <div className="text-emerald-400 text-[11px]">✓ Multi-Stage Builds</div>
          </div>
        </div>
      </div>
    </div>
  );
};
