import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { 
  Building2, 
  Plus, 
  ShieldCheck, 
  DollarSign, 
  Clock, 
  Search, 
  CheckCircle2, 
  X, 
  AlertCircle 
} from 'lucide-react';

export const CustomerManagementView: React.FC = () => {
  const { customers, refreshCustomers, switchTenant } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    industry: 'Healthcare & Life Sciences',
    contactEmail: '',
    phone: '',
    tier: 'ENTERPRISE',
    slaLevel: '24/7 Dedicated SRE (99.99%)',
    monthlyBudget: 50000
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const filtered = customers.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.code.toLowerCase().includes(search.toLowerCase()) ||
    c.industry.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await ApiClient.createCustomer(formData);
      await refreshCustomers();
      setIsModalOpen(false);
      setFormData({
        name: '',
        code: '',
        industry: 'Healthcare & Life Sciences',
        contactEmail: '',
        phone: '',
        tier: 'ENTERPRISE',
        slaLevel: '24/7 Dedicated SRE (99.99%)',
        monthlyBudget: 50000
      });
    } catch (err: unknown) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Customer Organizations</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Multi-Tenant Enterprise Organizations & Cloud Contract SLAs
          </p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-nordic-blue hover:bg-blue-600 text-white text-xs font-semibold shadow-lg shadow-blue-600/30 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Onboard New Customer</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter customers by organization name, code, or industry..."
          className="w-full bg-nordic-card border border-nordic-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-nordic-blue"
        />
      </div>

      {/* Customer Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {filtered.map((c) => (
          <div
            key={c.id}
            className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4 hover:border-nordic-blue/60 transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-nordic-elevated text-nordic-cyan border border-nordic-border">
                  {c.code}
                </span>
                <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
                  <CheckCircle2 className="w-3 h-3" />
                  {c.status}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-sm text-white">{c.name}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{c.industry}</p>
              </div>

              <div className="bg-nordic-elevated/60 rounded-lg p-3 space-y-1.5 text-xs border border-nordic-border/50">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Monthly Budget:</span>
                  <strong className="text-white font-mono">€{c.monthlyBudget.toLocaleString()}</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Current Spend:</span>
                  <strong className="text-nordic-cyan font-mono">€{(c.monthlySpend || 0).toLocaleString()}</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">SLA Contract:</span>
                  <span className="text-slate-300 text-[11px] truncate max-w-[140px]">{c.slaLevel}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Security Score:</span>
                  <span className="text-emerald-400 font-bold font-mono">{c.securityScore || 94}%</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-nordic-border flex items-center justify-between">
              <div className="text-[11px] text-slate-400 font-mono truncate max-w-[160px]">
                {c.contactEmail}
              </div>
              <button
                onClick={() => switchTenant(c.id)}
                className="px-3 py-1.5 rounded-lg bg-nordic-elevated hover:bg-nordic-blue text-slate-200 hover:text-white text-xs font-semibold transition-all"
              >
                Switch Tenant
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Onboard Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-nordic-card border border-nordic-border rounded-2xl max-w-lg w-full shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-nordic-border pb-3">
              <div className="flex items-center gap-2.5">
                <Building2 className="w-5 h-5 text-nordic-cyan" />
                <h3 className="font-bold text-white text-base">Onboard Customer Organization</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="bg-rose-950/50 border border-rose-800 rounded-xl p-3 text-xs text-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleCreate} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Company Legal Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Scania Logistics AB"
                    className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Organization Code</label>
                  <input
                    type="text"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    placeholder="e.g. SCANIA_LOG"
                    className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white font-mono uppercase focus:outline-none focus:border-nordic-blue"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Industry Vertical</label>
                  <input
                    type="text"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                    className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Contact Email</label>
                  <input
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                    placeholder="ops@company.se"
                    className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Monthly Budget (€)</label>
                  <input
                    type="number"
                    value={formData.monthlyBudget}
                    onChange={(e) => setFormData({ ...formData, monthlyBudget: Number(e.target.value) })}
                    className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-nordic-blue"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Contract Tier</label>
                  <select
                    value={formData.tier}
                    onChange={(e) => setFormData({ ...formData, tier: e.target.value })}
                    className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                  >
                    <option value="STARTER">Starter</option>
                    <option value="GROWTH">Growth</option>
                    <option value="ENTERPRISE">Enterprise</option>
                    <option value="MISSION_CRITICAL">Mission Critical (24/7)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-nordic-border">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-nordic-elevated hover:bg-nordic-border text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-lg bg-nordic-blue hover:bg-blue-600 text-white text-xs font-semibold shadow-lg shadow-blue-600/30"
                >
                  {loading ? 'Creating Tenant...' : 'Onboard Customer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
