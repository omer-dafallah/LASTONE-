import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { CloudResource } from '../types.js';
import { 
  Server, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw,
  Cpu,
  Database,
  HardDrive
} from 'lucide-react';

export const InfrastructureView: React.FC = () => {
  const { selectedTenantId } = useAuth();
  const [resources, setResources] = useState<CloudResource[]>([]);
  const [search, setSearch] = useState('');
  const [selectedProvider, setSelectedProvider] = useState<string>('ALL');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [loading, setLoading] = useState(true);

  const loadResources = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getResources();
      setResources(data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadResources();
  }, [selectedTenantId]);

  const filtered = resources.filter((r) => {
    const matchSearch = r.name.toLowerCase().includes(search.toLowerCase()) || r.resourceId.toLowerCase().includes(search.toLowerCase());
    const matchProvider = selectedProvider === 'ALL' || r.provider === selectedProvider;
    const matchType = selectedType === 'ALL' || r.resourceType === selectedType;
    return matchSearch && matchProvider && matchType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Cloud Infrastructure Inventory</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Real-Time Resource Telemetry, Sizing, and Performance Metrics
          </p>
        </div>
        <button
          onClick={loadResources}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-nordic-card border border-nordic-border text-xs text-slate-300 hover:text-white"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Telemetry</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-nordic-card border border-nordic-border rounded-xl p-4 flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search resources by name, ID, or tags..."
            className="w-full bg-nordic-bg border border-nordic-border rounded-lg pl-10 pr-4 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-nordic-blue"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedProvider}
            onChange={(e) => setSelectedProvider(e.target.value)}
            className="bg-nordic-bg border border-nordic-border rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
          >
            <option value="ALL">All Cloud Providers</option>
            <option value="GCP">Google Cloud (GCP)</option>
            <option value="AWS">Amazon Web Services (AWS)</option>
            <option value="AZURE">Microsoft Azure</option>
          </select>

          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="bg-nordic-bg border border-nordic-border rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
          >
            <option value="ALL">All Resource Types</option>
            <option value="KUBERNETES_CLUSTER">Kubernetes (GKE)</option>
            <option value="MANAGED_DATABASE">Managed DB (Cloud SQL / Azure SQL)</option>
            <option value="VIRTUAL_MACHINE">Virtual Machines (EC2 / Compute)</option>
            <option value="OBJECT_STORAGE">Object Storage (GCS / S3)</option>
          </select>
        </div>
      </div>

      {/* Resource Inventory Table */}
      <div className="bg-nordic-card border border-nordic-border rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-nordic-elevated/80 text-[11px] uppercase font-mono text-slate-400 border-b border-nordic-border">
              <tr>
                <th className="py-3 px-4">Resource Identifier</th>
                <th className="py-3 px-4">Provider / Region</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">CPU Utilization</th>
                <th className="py-3 px-4">Memory Util</th>
                <th className="py-3 px-4">Monthly Cost</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-nordic-border/50 text-slate-300">
              {filtered.map((r) => (
                <tr key={r.id} className="hover:bg-nordic-elevated/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-white font-mono text-xs">{r.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono truncate max-w-xs">{r.resourceId}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1.5">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold font-mono ${
                        r.provider === 'GCP' ? 'bg-blue-950 text-blue-300' : r.provider === 'AWS' ? 'bg-amber-950 text-amber-300' : 'bg-sky-950 text-sky-300'
                      }`}>
                        {r.provider}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">{r.region}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-slate-300 font-medium">{r.resourceType}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-nordic-bg rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${r.cpuUtilizationPct > 80 ? 'bg-rose-500' : 'bg-nordic-cyan'}`}
                          style={{ width: `${r.cpuUtilizationPct}%` }}
                        ></div>
                      </div>
                      <span className="font-mono text-xs">{r.cpuUtilizationPct}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-nordic-bg rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${r.memoryUtilizationPct > 80 ? 'bg-amber-500' : 'bg-indigo-400'}`}
                          style={{ width: `${r.memoryUtilizationPct}%` }}
                        ></div>
                      </div>
                      <span className="font-mono text-xs">{r.memoryUtilizationPct}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-bold font-mono text-white">
                    €{r.monthlyCost.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                      r.status === 'HEALTHY' 
                        ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800' 
                        : 'bg-rose-950/60 text-rose-400 border-rose-800'
                    }`}>
                      {r.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
