import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { 
  DollarSign, 
  TrendingUp, 
  AlertTriangle, 
  Sparkles, 
  ArrowDownRight, 
  Layers, 
  PieChart, 
  CheckCircle2 
} from 'lucide-react';

export const FinOpsView: React.FC = () => {
  const { selectedTenantId, openAiAdvisor } = useAuth();
  const [finOps, setFinOps] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFinOps = async () => {
      setLoading(true);
      try {
        const data = await ApiClient.getFinOpsSummary();
        setFinOps(data);
      } finally {
        setLoading(false);
      }
    };
    loadFinOps();
  }, [selectedTenantId]);

  const totalSpend = finOps?.totalSpend || 187650;
  const totalBudget = finOps?.totalBudget || 240000;
  const utilizationPct = Math.round((totalSpend / totalBudget) * 100);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">FinOps & Cost Intelligence</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Unit Economics, Commitment Coverage, Anomaly Detection & Rightsizing
          </p>
        </div>
        <button
          onClick={() => openAiAdvisor('FINOPS', 'Analyze our multi-cloud spend and generate an executive cost reduction proposal.')}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 text-white text-xs font-semibold shadow-lg shadow-blue-500/20"
        >
          <Sparkles className="w-4 h-4" />
          <span>Gemini Autonomous Rightsizing</span>
        </button>
      </div>

      {/* FinOps KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <span className="text-xs text-slate-400 font-medium">MTD Cloud Spend vs Budget</span>
          <div className="text-2xl font-extrabold text-white">€{totalSpend.toLocaleString()}</div>
          <div className="text-xs text-slate-400">
            Limit: <strong className="text-white">€{totalBudget.toLocaleString()}</strong> ({utilizationPct}% utilized)
          </div>
          <div className="w-full bg-nordic-bg rounded-full h-2 overflow-hidden">
            <div
              className={`h-full rounded-full ${utilizationPct > 90 ? 'bg-rose-500' : 'bg-nordic-blue'}`}
              style={{ width: `${Math.min(utilizationPct, 100)}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <span className="text-xs text-slate-400 font-medium">3-Year CUD / Commitment Coverage</span>
          <div className="text-2xl font-extrabold text-nordic-cyan font-mono">68.4%</div>
          <div className="text-xs text-slate-400">
            Target: <strong className="text-emerald-400">80.0%</strong> (GCP Committed Use Discounts)
          </div>
          <div className="w-full bg-nordic-bg rounded-full h-2 overflow-hidden">
            <div className="h-full rounded-full bg-nordic-cyan" style={{ width: '68.4%' }}></div>
          </div>
        </div>

        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-3">
          <span className="text-xs text-slate-400 font-medium">Flagged Cost Anomalies</span>
          <div className="text-2xl font-extrabold text-amber-400 font-mono">1 Active</div>
          <div className="text-xs text-amber-300">
            AWS EC2 gp3 EBS IOPS Spike (+145%)
          </div>
          <div className="text-[11px] text-slate-400 font-mono">Status: Investigating by FinOps Lead</div>
        </div>
      </div>

      {/* Cost By Provider & Recommendations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Breakdown by Cloud Provider */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-nordic-border pb-3 flex items-center gap-2">
            <PieChart className="w-4 h-4 text-nordic-blue" />
            <span>Monthly Spend Breakdown by Provider</span>
          </h3>

          <div className="space-y-3">
            <div className="bg-nordic-elevated p-3.5 rounded-xl border border-nordic-border flex items-center justify-between">
              <div>
                <div className="font-bold text-xs text-white">Google Cloud Platform (GCP)</div>
                <div className="text-[11px] text-slate-400 font-mono">GKE Autopilot, Cloud SQL Postgres, BigQuery</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-sm text-white font-mono">€96,650.00</div>
                <div className="text-[10px] text-nordic-cyan font-mono">51.5% of total</div>
              </div>
            </div>

            <div className="bg-nordic-elevated p-3.5 rounded-xl border border-nordic-border flex items-center justify-between">
              <div>
                <div className="font-bold text-xs text-white">Amazon Web Services (AWS)</div>
                <div className="text-[11px] text-slate-400 font-mono">EC2 WebRTC Cluster, EBS gp3 Volumes</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-sm text-white font-mono">€48,000.00</div>
                <div className="text-[10px] text-amber-400 font-mono">25.6% of total</div>
              </div>
            </div>

            <div className="bg-nordic-elevated p-3.5 rounded-xl border border-nordic-border flex items-center justify-between">
              <div>
                <div className="font-bold text-xs text-white">Microsoft Azure</div>
                <div className="text-[11px] text-slate-400 font-mono">Azure SQL Managed Instance, ExpressRoute</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-sm text-white font-mono">€43,000.00</div>
                <div className="text-[10px] text-sky-400 font-mono">22.9% of total</div>
              </div>
            </div>
          </div>
        </div>

        {/* Actionable Rightsizing Recommendations */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-nordic-border pb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Autonomous FinOps Rightsizing Opportunities</span>
          </h3>

          <div className="space-y-3">
            <div className="bg-nordic-elevated p-3.5 rounded-xl border border-nordic-border space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">GKE Workload Rightsizing (GCP)</span>
                <span className="text-xs font-bold text-emerald-400 font-mono">Save €840/mo</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                3 worker nodes in europe-north1 exhibit &lt; 15% memory utilization over 30 days. Recommend downsizing to e2-standard-4.
              </p>
            </div>

            <div className="bg-nordic-elevated p-3.5 rounded-xl border border-nordic-border space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">Cloud Storage Lifecycle Rules (GCS)</span>
                <span className="text-xs font-bold text-emerald-400 font-mono">Save €290/mo</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Move archive telemedicine PACS imagery from Standard storage to Nearline / Coldline after 60 days.
              </p>
            </div>

            <div className="bg-nordic-elevated p-3.5 rounded-xl border border-nordic-border space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">AWS EBS Orphaned gp3 Volume Cleanup</span>
                <span className="text-xs font-bold text-emerald-400 font-mono">Save €185/mo</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                2 unattached 500GB SSD volumes detected in eu-north-1.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
