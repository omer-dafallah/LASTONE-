import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { AutomationWorkflow } from '../types.js';
import { SafetyApprovalModal } from '../components/SafetyApprovalModal.js';
import { 
  Zap, 
  Play, 
  CheckCircle2, 
  Clock, 
  ShieldAlert, 
  RotateCcw,
  Terminal
} from 'lucide-react';

export const AutomationView: React.FC = () => {
  const { selectedTenantId } = useAuth();
  const [workflows, setWorkflows] = useState<AutomationWorkflow[]>([]);
  const [executions, setExecutions] = useState<any[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<AutomationWorkflow | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getAutomationWorkflows();
      setWorkflows(data?.workflows || []);
      setExecutions(data?.executions || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedTenantId]);

  const handleTriggerClick = (wf: AutomationWorkflow) => {
    setSelectedWorkflow(wf);
    setIsModalOpen(true);
  };

  const handleConfirmExecution = async () => {
    if (!selectedWorkflow) return;
    setIsModalOpen(false);
    try {
      await ApiClient.executeWorkflow(selectedWorkflow.id);
      await loadData();
    } catch (err: unknown) {
      alert(`Execution failed: ${(err as Error).message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Cloud Automation & Runbooks</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Safe Multi-Cloud Orchestration with Two-Man Operator Approval Gates
          </p>
        </div>
      </div>

      {/* Workflows Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {workflows.map((wf) => (
          <div
            key={wf.id}
            className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4 hover:border-nordic-blue/60 transition-all flex flex-col justify-between shadow-lg"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-950 text-nordic-cyan border border-blue-800">
                  {wf.targetProvider} • {wf.actionType}
                </span>
                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
                  ACTIVE
                </span>
              </div>

              <div>
                <h3 className="font-bold text-sm text-white">{wf.name}</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{wf.description}</p>
              </div>

              <div className="bg-nordic-elevated/60 rounded-lg p-3 space-y-1 text-xs border border-nordic-border/50 font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-sans">Trigger:</span>
                  <span className="text-slate-200">{wf.triggerType} ({wf.scheduleCron || 'Manual'})</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-sans">Approval Policy:</span>
                  <span className="text-amber-400 font-bold">Mandatory Operator Signoff</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-nordic-border flex items-center justify-between">
              <span className="text-[10px] text-slate-400 font-mono">
                Scope: {wf.customerName || 'Nordic Health'}
              </span>
              <button
                onClick={() => handleTriggerClick(wf)}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-nordic-blue hover:bg-blue-600 text-white text-xs font-semibold shadow-md shadow-blue-600/30 transition-all"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Trigger Runbook</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Execution Audit Log */}
      <div className="bg-nordic-card border border-nordic-border rounded-xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-nordic-border flex items-center justify-between bg-nordic-elevated/40">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-nordic-cyan" />
            <h3 className="font-bold text-sm text-white">Recent Automation Execution Runs</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Audit Logged</span>
        </div>

        <div className="divide-y divide-nordic-border">
          {executions.map((ex) => (
            <div key={ex.id} className="p-4 flex items-center justify-between text-xs hover:bg-nordic-elevated/20">
              <div className="space-y-1">
                <div className="flex items-center gap-2 font-mono">
                  <strong className="text-white">{ex.workflowName}</strong>
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-400">{ex.triggeredBy}</span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono">{ex.executionLog}</div>
              </div>
              <div className="text-right font-mono space-y-0.5">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  {ex.status}
                </span>
                <div className="text-[10px] text-slate-500">{ex.durationMs}ms</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Safety Confirmation Modal */}
      {selectedWorkflow && (
        <SafetyApprovalModal
          isOpen={isModalOpen}
          title={`Confirm Automation: ${selectedWorkflow.name}`}
          actionDescription={selectedWorkflow.description}
          impactWarning="This runbook alters cloud infrastructure state. Changes will be executed through server-side authenticated provider adapters and recorded to the SOC 2 audit trail."
          targetProvider={selectedWorkflow.targetProvider}
          onConfirm={handleConfirmExecution}
          onCancel={() => setIsModalOpen(false)}
        />
      )}
    </div>
  );
};
