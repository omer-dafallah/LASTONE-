import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { AlertItem } from '../types.js';
import { 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  Check, 
  X, 
  Clock, 
  Terminal 
} from 'lucide-react';

export const AlertsView: React.FC = () => {
  const { selectedTenantId, openAiAdvisor } = useAuth();
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  const loadAlerts = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getAlerts();
      setAlerts(data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAlerts();
  }, [selectedTenantId]);

  const handleResolve = async (id: string) => {
    setResolvingId(id);
    try {
      await ApiClient.resolveAlert(id, 'Resolved and mitigated by SRE on-call engineer.');
      await loadAlerts();
    } catch (err: unknown) {
      alert(`Failed to resolve alert: ${(err as Error).message}`);
    } finally {
      setResolvingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Active SRE Alerts & Incidents</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Cloud Monitoring Incident Queue & Automated Gemini SRE Triage
          </p>
        </div>
      </div>

      {/* Alert Queue */}
      <div className="bg-nordic-card border border-nordic-border rounded-xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-nordic-border flex items-center justify-between bg-nordic-elevated/40">
          <h3 className="font-bold text-sm text-white">Incident Feed</h3>
          <span className="text-xs text-rose-400 font-mono font-bold">
            {alerts.filter(a => a.status === 'OPEN').length} Open Alerts
          </span>
        </div>

        <div className="divide-y divide-nordic-border">
          {alerts.map((a) => (
            <div key={a.id} className="p-5 space-y-3 hover:bg-nordic-elevated/20 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                    a.severity === 'CRITICAL'
                      ? 'bg-rose-950 text-rose-300 border-rose-800'
                      : a.severity === 'HIGH'
                      ? 'bg-amber-950 text-amber-300 border-amber-800'
                      : 'bg-blue-950 text-blue-300 border-blue-800'
                  }`}>
                    {a.severity}
                  </span>
                  <span className="text-xs font-mono text-slate-400">{a.source}</span>
                </div>
                <span className={`text-xs font-semibold px-2.5 py-0.5 rounded ${
                  a.status === 'RESOLVED'
                    ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                    : 'bg-rose-950/60 text-rose-400 border border-rose-800'
                }`}>
                  {a.status}
                </span>
              </div>

              <div>
                <h4 className="font-bold text-sm text-white">{a.title}</h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{a.description}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-nordic-border/50 text-xs">
                <span className="text-[11px] text-slate-400 font-mono">
                  Triggered: {new Date(a.triggeredAt).toLocaleTimeString()} • Tenant: {a.customerName || 'Nordic Health'}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openAiAdvisor('INCIDENT_TRIAGE', `Provide Flash SRE triage runbook for: ${a.title}`, a)}
                    className="px-3 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-200 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                    <span>Gemini SRE Runbook</span>
                  </button>

                  {a.status === 'OPEN' && (
                    <button
                      onClick={() => handleResolve(a.id)}
                      disabled={resolvingId === a.id}
                      className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{resolvingId === a.id ? 'Resolving...' : 'Mark Resolved'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
