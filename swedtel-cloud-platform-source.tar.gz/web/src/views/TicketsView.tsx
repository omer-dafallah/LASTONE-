import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { SupportTicket } from '../types.js';
import { 
  LifeBuoy, 
  Plus, 
  Send, 
  Lock, 
  Clock, 
  CheckCircle2, 
  MessageSquare, 
  X, 
  AlertCircle 
} from 'lucide-react';

export const TicketsView: React.FC = () => {
  const { user, selectedTenantId } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isInternalNote, setIsInternalNote] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPriority, setNewPriority] = useState('P3_MEDIUM');
  const [loading, setLoading] = useState(true);

  const isProviderStaff = user.organizationType === 'PROVIDER';

  const loadTickets = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getTickets();
      setTickets(data || []);
      if (selectedTicket) {
        const refreshed = data.find((t: any) => t.id === selectedTicket.id);
        if (refreshed) setSelectedTicket(refreshed);
      } else if (data.length > 0) {
        setSelectedTicket(data[0]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTickets();
  }, [selectedTenantId]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !messageText.trim()) return;

    try {
      await ApiClient.addTicketMessage(selectedTicket.id, messageText, isInternalNote);
      setMessageText('');
      await loadTickets();
    } catch (err: unknown) {
      alert(`Message failed: ${(err as Error).message}`);
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await ApiClient.createTicket({
        customerId: user.customerId || selectedTenantId !== 'ALL' ? selectedTenantId : 'cust-nordic-health-001',
        title: newTitle,
        description: newDesc,
        priority: newPriority,
        category: 'INFRASTRUCTURE'
      });
      setIsCreateOpen(false);
      setNewTitle('');
      setNewDesc('');
      await loadTickets();
    } catch (err: unknown) {
      alert(`Create ticket failed: ${(err as Error).message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Support Desk & Incident Escalation</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            24/7 SLA Backed Cloud Support with Internal Engineering Notes
          </p>
        </div>
        <button
          onClick={() => setIsCreateOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-nordic-blue hover:bg-blue-600 text-white text-xs font-semibold shadow-lg shadow-blue-600/30"
        >
          <Plus className="w-4 h-4" />
          <span>Open Support Ticket</span>
        </button>
      </div>

      {/* Main Split Layout: Tickets List vs Active Conversation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-16rem)]">
        {/* Left List */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl overflow-y-auto divide-y divide-nordic-border">
          {tickets.map((t) => {
            const isSelected = selectedTicket?.id === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTicket(t)}
                className={`w-full text-left p-4 space-y-2 transition-all block ${
                  isSelected ? 'bg-nordic-elevated border-l-4 border-l-nordic-blue' : 'hover:bg-nordic-elevated/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-nordic-cyan">{t.ticketNumber}</span>
                  <span className={`text-[10px] font-mono px-2 py-0.2 rounded font-bold ${
                    t.priority === 'P1_CRITICAL' ? 'bg-rose-950 text-rose-300' : 'bg-nordic-bg text-slate-300'
                  }`}>
                    {t.priority}
                  </span>
                </div>
                <h4 className="font-bold text-xs text-white line-clamp-1">{t.title}</h4>
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span>{t.customerName || 'Nordic Health'}</span>
                  <span>{t.status}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Active Ticket Detail */}
        {selectedTicket ? (
          <div className="lg:col-span-2 bg-nordic-card border border-nordic-border rounded-xl flex flex-col justify-between overflow-hidden">
            {/* Ticket Header */}
            <div className="p-4 border-b border-nordic-border bg-nordic-elevated/40 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-nordic-cyan">{selectedTicket.ticketNumber}</span>
                  <h3 className="font-bold text-sm text-white">{selectedTicket.title}</h3>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Opened by {selectedTicket.createdByName} • SLA Guarantee: &lt; 15 mins (24/7 Dedicated)
                </p>
              </div>
              <span className="text-xs font-mono px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-semibold">
                {selectedTicket.status}
              </span>
            </div>

            {/* Conversation Messages */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
              <div className="bg-nordic-elevated p-4 rounded-xl border border-nordic-border space-y-1.5">
                <span className="font-semibold text-slate-300">Initial Issue Description:</span>
                <p className="text-slate-300 leading-relaxed">{selectedTicket.description}</p>
              </div>

              {selectedTicket.messages?.map((m) => (
                <div
                  key={m.id}
                  className={`p-3.5 rounded-xl border space-y-1 text-xs ${
                    m.isInternalNote
                      ? 'bg-amber-950/40 border-amber-800/80 text-amber-200 ml-4'
                      : 'bg-nordic-elevated/70 border-nordic-border text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono">
                    <span className="font-bold flex items-center gap-1">
                      {m.isInternalNote && <Lock className="w-3 h-3 text-amber-400" />}
                      {m.senderName} {m.isInternalNote && '(SWEDTEL Internal Note)'}
                    </span>
                    <span className="text-slate-400">{new Date(m.createdAt).toLocaleTimeString()}</span>
                  </div>
                  <p className="leading-relaxed">{m.message}</p>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-nordic-border bg-nordic-elevated/40 space-y-2">
              {isProviderStaff && (
                <label className="flex items-center gap-2 text-xs text-amber-300 font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isInternalNote}
                    onChange={(e) => setIsInternalNote(e.target.checked)}
                    className="rounded bg-nordic-bg border-nordic-border text-amber-500 focus:ring-0"
                  />
                  <span>Post as Internal Engineering Note (Hidden from Customer Tenant)</span>
                </label>
              )}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder={isInternalNote ? 'Write private engineering note...' : 'Reply to customer...'}
                  className="flex-1 bg-nordic-bg border border-nordic-border rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-nordic-blue"
                />
                <button
                  type="submit"
                  disabled={!messageText.trim()}
                  className="bg-nordic-blue hover:bg-blue-600 disabled:opacity-50 text-white px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="lg:col-span-2 bg-nordic-card border border-nordic-border rounded-xl flex items-center justify-center text-slate-500 text-xs">
            Select a ticket from the queue
          </div>
        )}
      </div>

      {/* Create Ticket Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-nordic-card border border-nordic-border rounded-2xl max-w-lg w-full shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-nordic-border pb-3">
              <h3 className="font-bold text-white text-base">Open Support Incident</h3>
              <button onClick={() => setIsCreateOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Incident Summary</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. GKE Ingress TLS Certificate Renewal Issue"
                  className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Priority</label>
                <select
                  value={newPriority}
                  onChange={(e) => setNewPriority(e.target.value)}
                  className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                >
                  <option value="P1_CRITICAL">P1 - Critical (Outage / &lt;15m SLA)</option>
                  <option value="P2_HIGH">P2 - High (Degraded Performance)</option>
                  <option value="P3_MEDIUM">P3 - Medium (General Cloud Assistance)</option>
                  <option value="P4_LOW">P4 - Low (Informational)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Detailed Description</label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={4}
                  placeholder="Provide affected regions, services, and impact details..."
                  className="w-full bg-nordic-bg border border-nordic-border rounded-lg px-3 py-2 text-white focus:outline-none focus:border-nordic-blue"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-nordic-border">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 rounded-lg bg-nordic-elevated text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-nordic-blue hover:bg-blue-600 text-white text-xs font-semibold"
                >
                  Submit Incident
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
