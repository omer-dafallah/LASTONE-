import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { 
  Building2, 
  Cloud, 
  DollarSign, 
  ShieldCheck, 
  AlertTriangle, 
  Server, 
  TrendingUp,
  Sparkles,
  ArrowUpRight,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';

export const AdminDashboardView: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { customers, selectedTenantId, openAiAdvisor } = useAuth();
  const [finOps, setFinOps] = useState<any>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [resources, setResources] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const [fData, aData, rData, alData] = await Promise.all([
        ApiClient.getFinOpsSummary().catch(() => null),
        ApiClient.getCloudAccounts().catch(() => []),
        ApiClient.getResources().catch(() => []),
        ApiClient.getAlerts().catch(() => [])
      ]);
      setFinOps(fData);
      setAccounts(aData || []);
      setResources(rData || []);
      setAlerts(alData || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedTenantId]);

  const activeAlertsCount = alerts.filter(a => a.status === 'OPEN').length;
  const totalMonthlySpend = finOps?.totalSpend || 187650;
  const totalMonthlyBudget = finOps?.totalBudget || 240000;
  const budgetUtilizationPct = Math.round((totalMonthlySpend / totalMonthlyBudget) * 100);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">
            {selectedTenantId === 'ALL' ? 'SWEDTEL Global Operations Overview' : 'Customer Tenant Dashboard'}
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Centralized Multi-Cloud Telemetry & FinOps Engine
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={loadData}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-nordic-card border border-nordic-border text-xs text-slate-300 hover:text-white hover:bg-nordic-elevated transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Sync Fleet</span>
          </button>
          <button
            onClick={() => openAiAdvisor('FINOPS', 'Perform full multi-cloud FinOps rightsizing analysis.')}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 text-white text-xs font-semibold shadow-md shadow-blue-500/20"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI FinOps Advisory</span>
          </button>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Monthly Spend */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-4.5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Monthly Cloud Spend</span>
            <div className="w-8 h-8 rounded-lg bg-blue-950/80 border border-blue-800 flex items-center justify-center">
              <DollarSign className="w-4 h-4 text-nordic-cyan" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white">€{totalMonthlySpend.toLocaleString()}</div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
              <span>Budget: €{totalMonthlyBudget.toLocaleString()}</span>
              <span className={`font-mono font-bold ${budgetUtilizationPct > 85 ? 'text-amber-400' : 'text-emerald-400'}`}>
                ({budgetUtilizationPct}%)
              </span>
            </div>
          </div>
          <div className="w-full bg-nordic-bg rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full rounded-full ${budgetUtilizationPct > 85 ? 'bg-amber-500' : 'bg-nordic-blue'}`}
              style={{ width: `${Math.min(budgetUtilizationPct, 100)}%` }}
            ></div>
          </div>
        </div>

        {/* Metric 2: Managed Resources */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-4.5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Managed Resources</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-950/80 border border-indigo-800 flex items-center justify-center">
              <Server className="w-4 h-4 text-indigo-400" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white">{resources.length || 14}</div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
              <span className="text-emerald-400 flex items-center gap-1 font-mono">
                <CheckCircle2 className="w-3 h-3" /> All Healthy
              </span>
              <span>Across 3 Clouds</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 font-mono">GKE • Cloud SQL • GCS • EC2 • Azure SQL</div>
        </div>

        {/* Metric 3: Active SRE Alerts */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-4.5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Active SRE Alerts</span>
            <div className="w-8 h-8 rounded-lg bg-rose-950/80 border border-rose-800 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white">{activeAlertsCount}</div>
            <div className="text-[11px] text-rose-400 mt-1 flex items-center gap-1 font-mono">
              <span>1 Critical • 1 High Cost Spike</span>
            </div>
          </div>
          <button
            onClick={() => onNavigate('alerts')}
            className="text-[11px] text-nordic-cyan hover:underline flex items-center gap-1 font-semibold"
          >
            <span>Triage Open Queue</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        {/* Metric 4: CIS Compliance Score */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-4.5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">CIS Compliance Score</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-950/80 border border-emerald-800 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-emerald-400 font-mono">94%</div>
            <div className="text-[11px] text-slate-400 mt-1">SOC 2 Type II & CIS GCP v2.0</div>
          </div>
          <button
            onClick={() => onNavigate('security')}
            className="text-[11px] text-nordic-cyan hover:underline flex items-center gap-1 font-semibold"
          >
            <span>View Remediation Items</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Main Grid: Multi-Cloud Provider Breakdown & Active SRE Incidents */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Cloud Accounts & Providers */}
        <div className="lg:col-span-2 bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-nordic-border pb-3">
            <div className="flex items-center gap-2.5">
              <Cloud className="w-4 h-4 text-nordic-blue" />
              <h3 className="text-sm font-bold text-white">Multi-Cloud Infrastructure Fleets</h3>
            </div>
            <button
              onClick={() => onNavigate('cloud_accounts')}
              className="text-xs text-nordic-cyan hover:underline font-semibold"
            >
              Manage Accounts ({accounts.length})
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Google Cloud Card */}
            <div className="bg-nordic-elevated p-4 rounded-xl border border-nordic-border space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">Google Cloud (GCP)</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-blue-950 text-nordic-cyan border border-blue-800 font-mono">PRIMARY</span>
              </div>
              <div className="text-lg font-bold text-white">€96,650<span className="text-xs text-slate-400 font-normal">/mo</span></div>
              <div className="text-[11px] text-slate-400 space-y-0.5">
                <div>Projects: <strong>2 active</strong></div>
                <div>Auth: <strong>Workload Identity (WIF)</strong></div>
                <div>Regions: <strong className="text-slate-200">europe-north1 (Hamina)</strong></div>
              </div>
            </div>

            {/* AWS Card */}
            <div className="bg-nordic-elevated p-4 rounded-xl border border-nordic-border space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">Amazon Web Services</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-mono">STS ROLE</span>
              </div>
              <div className="text-lg font-bold text-white">€48,000<span className="text-xs text-slate-400 font-normal">/mo</span></div>
              <div className="text-[11px] text-slate-400 space-y-0.5">
                <div>Accounts: <strong>1 active</strong></div>
                <div>Region: <strong className="text-slate-200">eu-north-1 (Stockholm)</strong></div>
                <div className="text-amber-400 font-mono text-[10px]">⚠️ 1 Anomaly Flagged</div>
              </div>
            </div>

            {/* Azure Card */}
            <div className="bg-nordic-elevated p-4 rounded-xl border border-nordic-border space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white">Microsoft Azure</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800 font-mono">SERVICE PRINCIPAL</span>
              </div>
              <div className="text-lg font-bold text-white">€43,000<span className="text-xs text-slate-400 font-normal">/mo</span></div>
              <div className="text-[11px] text-slate-400 space-y-0.5">
                <div>Subscriptions: <strong>1 active</strong></div>
                <div>Region: <strong className="text-slate-200">swedencentral (Gävle)</strong></div>
                <div className="text-emerald-400 font-mono text-[10px]">✓ Steady State</div>
              </div>
            </div>
          </div>

          {/* Quick Resource Summary Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[11px] uppercase font-mono text-slate-400 border-b border-nordic-border">
                <tr>
                  <th className="py-2">Resource</th>
                  <th className="py-2">Provider</th>
                  <th className="py-2">Type</th>
                  <th className="py-2">Telemetry (CPU / Mem)</th>
                  <th className="py-2">Monthly Cost</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-nordic-border/50 text-slate-300">
                {resources.slice(0, 4).map((r) => (
                  <tr key={r.id} className="hover:bg-nordic-elevated/40">
                    <td className="py-2.5 font-medium text-white font-mono">{r.name}</td>
                    <td className="py-2.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        r.provider === 'GCP' ? 'bg-blue-950 text-blue-300' : r.provider === 'AWS' ? 'bg-amber-950 text-amber-300' : 'bg-sky-950 text-sky-300'
                      }`}>
                        {r.provider}
                      </span>
                    </td>
                    <td className="py-2.5 text-slate-400">{r.resourceType}</td>
                    <td className="py-2.5 font-mono">
                      <span className="text-slate-200">{r.cpuUtilizationPct}%</span> / <span className="text-slate-400">{r.memoryUtilizationPct}%</span>
                    </td>
                    <td className="py-2.5 font-semibold text-white">€{r.monthlyCost.toLocaleString()}</td>
                    <td className="py-2.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        r.status === 'HEALTHY' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Active SRE Queue & AI Runbook */}
        <div className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-nordic-border pb-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <h3 className="text-sm font-bold text-white">Active SRE Alerts</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded bg-rose-950 text-rose-400 font-mono font-bold">
                {activeAlertsCount} Open
              </span>
            </div>

            <div className="space-y-3 mt-4">
              {alerts.slice(0, 2).map((a) => (
                <div key={a.id} className="bg-nordic-elevated p-3.5 rounded-xl border border-nordic-border space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-bold">
                      {a.severity}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{a.source}</span>
                  </div>
                  <div className="font-semibold text-xs text-white">{a.title}</div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{a.description}</p>
                  <button
                    onClick={() => openAiAdvisor('INCIDENT_TRIAGE', `Provide immediate SRE triage runbook for: ${a.title}`, a)}
                    className="w-full mt-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-800 text-[11px] font-semibold text-rose-200 transition-all"
                  >
                    <Sparkles className="w-3 h-3 text-rose-400" />
                    <span>Gemini Flash Incident Triage</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* FinOps Optimization Prompt Card */}
          <div className="bg-gradient-to-br from-blue-950/60 to-cyan-950/40 border border-blue-800/60 p-4 rounded-xl space-y-2 mt-4">
            <div className="flex items-center gap-2 text-xs font-bold text-nordic-cyan">
              <TrendingUp className="w-4 h-4" />
              <span>FinOps Savings Available</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Autonomous analyzer detected <strong>€3,400/mo</strong> potential savings via GKE spot node pools and unattached disk cleanup.
            </p>
            <button
              onClick={() => onNavigate('finops')}
              className="text-xs font-bold text-white hover:underline flex items-center gap-1"
            >
              <span>Review FinOps Recommendations</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
