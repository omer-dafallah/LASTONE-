import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { AuditLogItem } from '../types.js';
import { History, ShieldCheck, Search, Filter, Terminal } from 'lucide-react';

export const AuditLogsView: React.FC = () => {
  const { selectedTenantId } = useAuth();
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAudit = async () => {
      setLoading(true);
      try {
        const data = await ApiClient.getAuditLogs();
        setLogs(data || []);
      } finally {
        setLoading(false);
      }
    };
    loadAudit();
  }, [selectedTenantId]);

  const filtered = logs.filter(l => 
    l.action.toLowerCase().includes(search.toLowerCase()) ||
    l.userEmail.toLowerCase().includes(search.toLowerCase()) ||
    l.resourceType.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">SOC 2 Continuous Audit Trail</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Immutable Audit Trail of All Administrative, Tenant, and Automation Operations
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-400 font-mono">
          <ShieldCheck className="w-4 h-4" />
          <span>SOC 2 Type II Certified Logger</span>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter audit logs by action, user email, or resource type..."
          className="w-full bg-nordic-card border border-nordic-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-nordic-blue"
        />
      </div>

      {/* Audit Log Table */}
      <div className="bg-nordic-card border border-nordic-border rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-nordic-elevated/80 text-[11px] uppercase font-mono text-slate-400 border-b border-nordic-border">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Operator Identity</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Target Resource</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-nordic-border/50 text-slate-300 font-mono">
              {filtered.map((log) => (
                <tr key={log.id} className="hover:bg-nordic-elevated/30">
                  <td className="py-3 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                    {new Date(log.createdAt).toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-white font-semibold">{log.userEmail}</div>
                    <div className="text-[10px] text-slate-400">{log.userRole}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-nordic-cyan">{log.action}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {log.resourceType}:{log.resourceId || 'fleet'}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      log.status === 'SUCCESS' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                    }`}>
                      {log.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[10px] text-slate-400 max-w-xs truncate">
                    {JSON.stringify(log.details || {})}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
