import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { ApiClient } from '../api/client.js';
import { FileText, Download, Plus, CheckCircle2, Sparkles } from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { user, selectedTenantId } = useAuth();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const loadReports = async () => {
    setLoading(true);
    try {
      const data = await ApiClient.getReports();
      setReports(data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, [selectedTenantId]);

  const handleGenerate = async (type: string) => {
    setGenerating(true);
    try {
      await ApiClient.generateReport({
        customerId: user.customerId || (selectedTenantId !== 'ALL' ? selectedTenantId : 'cust-nordic-health-001'),
        type,
        title: `SWEDTEL Executive ${type.replace('_', ' ')} Summary`
      });
      await loadReports();
    } catch (err: unknown) {
      alert(`Report generation failed: ${(err as Error).message}`);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">Executive Reports & Audits</h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Automated FinOps, CIS Security Compliance, and Monthly SLA Reports
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleGenerate('FINOPS_MONTHLY')}
            disabled={generating}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-nordic-blue hover:bg-blue-600 text-white text-xs font-semibold shadow-lg shadow-blue-600/30"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Generate FinOps Report</span>
          </button>
          <button
            onClick={() => handleGenerate('CIS_SECURITY')}
            disabled={generating}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/30"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Generate CIS Audit</span>
          </button>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {reports.map((rep) => (
          <div
            key={rep.id}
            className="bg-nordic-card border border-nordic-border rounded-xl p-5 space-y-4 hover:border-nordic-blue/60 transition-all flex flex-col justify-between"
          >
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-950 text-nordic-cyan border border-blue-800">
                  {rep.type}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> READY
                </span>
              </div>
              <h3 className="font-bold text-sm text-white">{rep.title}</h3>
              <p className="text-xs text-slate-400 font-mono">
                Period: {rep.periodStart} to {rep.periodEnd} • Tenant: {rep.customerName || 'Nordic Health'}
              </p>
            </div>

            <div className="pt-3 border-t border-nordic-border flex items-center justify-between text-xs">
              <span className="text-[10px] text-slate-400 font-mono">Format: PDF & JSON Artifact</span>
              <a
                href={rep.fileUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-nordic-elevated hover:bg-nordic-blue text-slate-200 hover:text-white font-semibold transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Report</span>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
