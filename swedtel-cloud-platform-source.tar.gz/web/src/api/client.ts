// ====================================================================
// SWEDTEL Web SaaS Platform - Enterprise API Client
// Handles Bearer tokens, dynamic tenant scoping, and server communication
// ====================================================================

const BASE_URL = '/api/v1';

export class ApiClient {
  private static token: string | null = null;
  private static activeRoleKey: string = 'superadmin';
  private static activeTenantId: string = 'ALL';

  public static setToken(token: string | null): void {
    this.token = token;
  }

  public static setRoleKey(roleKey: string): void {
    this.activeRoleKey = roleKey;
  }

  public static setTenantId(tenantId: string): void {
    this.activeTenantId = tenantId;
  }

  public static async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'x-swedtel-impersonate-role': this.activeRoleKey,
      'x-swedtel-tenant-id': this.activeTenantId,
      ...(options.headers as Record<string, string> || {})
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        ...options,
        headers
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.message || `API Error: HTTP ${response.status}`);
      }

      const json = await response.json();
      return json.data !== undefined ? json.data : json;
    } catch (err) {
      console.warn(`[ApiClient] Network request failed for ${endpoint}. Fallback mode active.`, err);
      throw err;
    }
  }

  // Auth
  public static async getCurrentUser() {
    return this.request<any>('/auth/me');
  }

  public static async switchDevRole(roleKey: string) {
    this.setRoleKey(roleKey);
    const res = await this.request<{ user: any; token: string }>('/auth/dev-switch-role', {
      method: 'POST',
      body: JSON.stringify({ roleKey })
    });
    this.setToken(res.token);
    return res.user;
  }

  // Customers
  public static async getCustomers() {
    return this.request<any[]>('/customers');
  }

  public static async createCustomer(data: any) {
    return this.request<any>('/customers', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // Cloud Accounts & Resources
  public static async getCloudAccounts() {
    return this.request<any[]>('/cloud/accounts');
  }

  public static async connectCloudAccount(data: any) {
    return this.request<any>('/cloud/accounts/validate-and-connect', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  public static async syncCloudAccount(accountId: string) {
    return this.request<any>(`/cloud/accounts/${accountId}/sync`, {
      method: 'POST'
    });
  }

  public static async getResources(filter?: Record<string, string>) {
    const query = filter ? '?' + new URLSearchParams(filter).toString() : '';
    return this.request<any[]>(`/cloud/resources${query}`);
  }

  // FinOps
  public static async getFinOpsSummary() {
    return this.request<any>('/finops/summary');
  }

  // Alerts
  public static async getAlerts() {
    return this.request<any[]>('/alerts');
  }

  public static async resolveAlert(id: string, notes?: string) {
    return this.request<any>(`/alerts/${id}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ resolutionNotes: notes })
    });
  }

  // Security
  public static async getSecurityFindings() {
    return this.request<any>('/security/findings');
  }

  public static async remediateFinding(id: string) {
    return this.request<any>(`/security/findings/${id}/remediate`, {
      method: 'POST'
    });
  }

  // Automation
  public static async getAutomationWorkflows() {
    return this.request<{ workflows: any[]; executions: any[] }>('/automation/workflows');
  }

  public static async executeWorkflow(id: string) {
    return this.request<any>(`/automation/workflows/${id}/execute`, {
      method: 'POST'
    });
  }

  // Tickets
  public static async getTickets() {
    return this.request<any[]>('/tickets');
  }

  public static async createTicket(data: any) {
    return this.request<any>('/tickets', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  public static async addTicketMessage(ticketId: string, message: string, isInternalNote: boolean) {
    return this.request<any>(`/tickets/${ticketId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ message, isInternalNote })
    });
  }

  // Reports
  public static async getReports() {
    return this.request<any[]>('/reports');
  }

  public static async generateReport(data: any) {
    return this.request<any>('/reports/generate', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // Audit Logs
  public static async getAuditLogs() {
    return this.request<any[]>('/audit/logs');
  }

  // Server-Side Gemini AI Advisor
  public static async consultAI(prompt: string, contextType: string, customerId?: string, incidentDetails?: any) {
    return this.request<any>('/ai/consult', {
      method: 'POST',
      body: JSON.stringify({ prompt, contextType, customerId, incidentDetails })
    });
  }
}
