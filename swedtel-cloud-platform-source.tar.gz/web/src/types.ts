// ====================================================================
// SWEDTEL Web SaaS Platform - Frontend Domain Types
// ====================================================================

export type UserRole = 
  | 'SUPER_ADMIN' 
  | 'CLOUD_ENGINEER' 
  | 'FINOPS_SPECIALIST' 
  | 'ACCOUNT_MANAGER' 
  | 'CUSTOMER_ADMIN' 
  | 'CUSTOMER_VIEWER';

export interface UserContext {
  userId: string;
  email: string;
  firstName: string;
  lastName: string;
  organizationId: string;
  organizationType: 'PROVIDER' | 'CUSTOMER';
  role: UserRole;
  customerId?: string;
  permissions: string[];
}

export interface Customer {
  id: string;
  name: string;
  code: string;
  industry: string;
  contactEmail: string;
  phone?: string;
  tier: string;
  slaLevel: string;
  status: 'ACTIVE' | 'PROVISIONING' | 'SUSPENDED';
  monthlyBudget: number;
  monthlySpend?: number;
  securityScore?: number;
  cloudAccountsCount?: number;
  resourcesCount?: number;
  createdAt: string;
}

export interface CloudAccount {
  id: string;
  customerId: string;
  customerName?: string;
  provider: 'GCP' | 'AWS' | 'AZURE';
  name: string;
  accountOrProjectId: string;
  targetServiceAccount?: string;
  environment: 'PRODUCTION' | 'STAGING' | 'DEVELOPMENT' | 'DR';
  connectionType: 'WIF' | 'STS_ASSUME_ROLE' | 'SERVICE_PRINCIPAL';
  connectionMode?: 'DEMO' | 'LIVE';
  status: 'CONNECTED' | 'DEGRADED' | 'SYNC_PENDING' | 'AUTH_ERROR' | 'PERMISSION_ERROR' | 'API_NOT_ENABLED';
  lastSyncedAt?: string;
  lastSyncStatus?: 'SUCCESS' | 'FAILED' | 'SYNCING' | 'PENDING';
  lastSyncError?: string;
  isDemo: boolean;
  resourceCount?: number;
  monthlyCost?: number;
}

export interface CloudResource {
  id: string;
  customerId: string;
  customerName?: string;
  cloudAccountId: string;
  projectId?: string;
  provider: 'GCP' | 'AWS' | 'AZURE';
  resourceType: 'KUBERNETES_CLUSTER' | 'VIRTUAL_MACHINE' | 'MANAGED_DATABASE' | 'OBJECT_STORAGE' | 'VPC_NETWORK';
  resourceId: string;
  name: string;
  region: string;
  zone?: string;
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'STOPPED';
  cpuUtilizationPct: number;
  memoryUtilizationPct: number;
  diskUtilizationPct: number;
  networkInMbps: number;
  networkOutMbps: number;
  monthlyCost: number;
  tags: Record<string, string>;
  metadata?: Record<string, any>;
  isDemo: boolean;
  connectionMode?: 'DEMO' | 'LIVE';
  lastTelemetryAt: string;
}

export interface FinOpsSummary {
  totalSpend: number;
  totalBudget: number;
  utilizationPct: number;
  anomaliesCount: number;
  anomalies: Array<{
    id: string;
    serviceName: string;
    amount: number;
    anomalyReason: string;
    provider: string;
  }>;
  costByProvider: Record<string, number>;
  costByService: Record<string, number>;
}

export interface AlertItem {
  id: string;
  customerId: string;
  customerName?: string;
  title: string;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';
  source: string;
  metricName?: string;
  triggeredAt: string;
  resolutionNotes?: string;
}

export interface SecurityFinding {
  id: string;
  customerId: string;
  customerName?: string;
  title: string;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  complianceFramework: string;
  cisControlId: string;
  remediationSteps: string;
  status: 'OPEN' | 'RESOLVED';
  isAutomatedFixAvailable: boolean;
}

export interface AutomationWorkflow {
  id: string;
  customerId: string;
  customerName?: string;
  name: string;
  description: string;
  targetProvider: 'GCP' | 'AWS' | 'AZURE' | 'ALL';
  triggerType: string;
  scheduleCron?: string;
  actionType: string;
  requiresApproval: boolean;
  isActive: boolean;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  customerId: string;
  customerName?: string;
  createdByName: string;
  assignedToName?: string;
  title: string;
  description: string;
  category: string;
  priority: 'P1_CRITICAL' | 'P2_HIGH' | 'P3_MEDIUM' | 'P4_LOW';
  status: 'OPEN' | 'IN_PROGRESS' | 'WAITING_CUSTOMER' | 'RESOLVED' | 'CLOSED';
  slaDueAt: string;
  messages?: Array<{
    id: string;
    senderName: string;
    message: string;
    isInternalNote: boolean;
    createdAt: string;
  }>;
}

export interface AuditLogItem {
  id: string;
  userEmail: string;
  userRole: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  status: 'SUCCESS' | 'DENIED' | 'FAILURE';
  details: Record<string, unknown>;
  createdAt: string;
}
