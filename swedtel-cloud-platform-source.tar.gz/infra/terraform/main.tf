# ====================================================================
# SWEDTEL Cloud Management Platform - Google Cloud Platform Terraform Blueprint
# Target Architecture: Google Cloud Run, Cloud SQL PostgreSQL, Secret Manager,
# Workload Identity Federation (WIF), Cloud Armor, and Cloud Storage
# ====================================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.30.0"
    }
  }
}

variable "project_id" {
  description = "Google Cloud Project ID for SWEDTEL Platform Hub"
  type        = string
  default     = "swedtel-cloud-platform-prod"
}

variable "region" {
  description = "Primary Google Cloud Region (Nordic Data Centers)"
  type        = string
  default     = "europe-north1" # Hamina, Finland
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# 1. VPC Network & Private Service Access for Cloud SQL
resource "google_compute_network" "swedtel_vpc" {
  name                    = "swedtel-platform-vpc"
  auto_create_subnetworks = false
}

resource "google_compute_subnetwork" "swedtel_subnet" {
  name          = "swedtel-nordic-subnet"
  ip_cidr_range = "10.10.0.0/20"
  region        = var.region
  network       = google_compute_network.swedtel_vpc.id
}

resource "google_vpc_access_connector" "connector" {
  name          = "swedtel-vpc-conn"
  region        = var.region
  ip_cidr_range = "10.8.0.0/28"
  network       = google_compute_network.swedtel_vpc.name
}

# 2. Cloud SQL - PostgreSQL 16 Enterprise (High Availability)
resource "google_sql_database_instance" "postgres" {
  name             = "swedtel-postgres-primary"
  database_version = "POSTGRES_16"
  region           = var.region

  settings {
    tier              = "db-custom-4-16384"
    availability_type = "REGIONAL" # Cross-zone automated failover
    disk_size         = 100
    disk_autoresize   = true

    ip_configuration {
      ipv4_enabled    = false
      private_network = google_compute_network.swedtel_vpc.id
    }

    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
      start_time                     = "02:00"
    }
  }
}

resource "google_sql_database" "swedtel_db" {
  name     = "swedtel_cloud_db"
  instance = google_sql_database_instance.postgres.name
}

# 3. Google Secret Manager Secrets
resource "google_secret_manager_secret" "db_password" {
  secret_id = "swedtel-db-password"
  replication {
    auto {}
  }
}

resource "google_secret_manager_secret" "jwt_secret" {
  secret_id = "swedtel-jwt-secret"
  replication {
    auto {}
  }
}

resource "google_secret_manager_secret" "gemini_api_key" {
  secret_id = "swedtel-gemini-api-key"
  replication {
    auto {}
  }
}

# 4. Service Accounts & Workload Identity Federation (WIF)
resource "google_service_account" "api_sa" {
  account_id   = "swedtel-api-runner"
  display_name = "SWEDTEL Backend API Cloud Run Runner"
}

resource "google_secret_manager_secret_iam_member" "api_secret_accessor" {
  for_each = toset([
    google_secret_manager_secret.db_password.secret_id,
    google_secret_manager_secret.jwt_secret.secret_id,
    google_secret_manager_secret.gemini_api_key.secret_id
  ])
  secret_id = each.key
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.api_sa.email}"
}

# 5. Cloud Run Service (Backend REST API)
resource "google_cloud_run_v2_service" "api_service" {
  name     = "swedtel-backend-api"
  location = var.region
  ingress  = "INGRESS_TRAFFIC_ALL"

  template {
    service_account = google_service_account.api_sa.email

    scaling {
      min_instance_count = 1
      max_instance_count = 50
    }

    vpc_access {
      connector = google_vpc_access_connector.connector.id
      egress    = "ALL_TRAFFIC"
    }

    containers {
      image = "europe-north1-docker.pkg.dev/${var.project_id}/swedtel-containers/api:v1.0.0"

      resources {
        limits = {
          cpu    = "2000m"
          memory = "2Gi"
        }
      }

      env {
        name  = "NODE_ENV"
        value = "production"
      }
      env {
        name  = "PORT"
        value = "4000"
      }
      env {
        name  = "GCP_PROJECT_ID"
        value = var.project_id
      }
      env {
        name  = "GCP_SECRET_NAME_JWT"
        value = google_secret_manager_secret.jwt_secret.secret_id
      }
      env {
        name  = "GCP_SECRET_NAME_GEMINI"
        value = google_secret_manager_secret.gemini_api_key.secret_id
      }
    }
  }
}

# 6. Cloud Armor Security Policy
resource "google_compute_security_policy" "cloud_armor" {
  name = "swedtel-cloud-armor-policy"

  # Rate limiting rule (1000 requests per minute per IP)
  rule {
    action   = "rate_based_ban"
    priority = "1000"
    match {
      versioned_expr = "SRC_IPS_V1"
      config {
        src_ip_ranges = ["*"]
      }
    }
    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"
      rate_limit_threshold {
        count        = 1000
        interval_sec = 60
      }
    }
  }

  # Default allow rule
  rule {
    action   = "allow"
    priority = "2147483647"
    match {
      versioned_expr = "SRC_IPS_V1"
      config {
        src_ip_ranges = ["*"]
      }
    }
  }
}
