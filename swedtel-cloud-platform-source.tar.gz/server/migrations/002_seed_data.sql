-- ====================================================================
-- SWEDTEL Cloud Management Platform - Seed Enterprise Demo Data
-- Migration: 002_seed_data.sql
-- ====================================================================

-- 1. Insert Core Roles
INSERT INTO roles (id, code, name, description, is_system_role) VALUES
('11111111-1111-1111-1111-111111111101', 'SUPER_ADMIN', 'SWEDTEL Super Admin', 'Full unrestricted platform and tenant administration', TRUE),
('11111111-1111-1111-1111-111111111102', 'CLOUD_ENGINEER', 'SWEDTEL Cloud Engineer', 'Cloud infrastructure operations, automation, and SRE triage', TRUE),
('11111111-1111-1111-1111-111111111103', 'FINOPS_SPECIALIST', 'SWEDTEL FinOps Specialist', 'Cloud cost optimization, unit economics, and budget governance', TRUE),
('11111111-1111-1111-1111-111111111104', 'ACCOUNT_MANAGER', 'SWEDTEL Account Manager', 'Customer relationship, contract SLA tracking, and ticket escalation', TRUE),
('11111111-1111-1111-1111-111111111105', 'CUSTOMER_ADMIN', 'Customer Organization Admin', 'Tenant administrator with full control over customer cloud resources and budgets', TRUE),
('11111111-1111-1111-1111-111111111106', 'CUSTOMER_VIEWER', 'Customer Read-Only Viewer', 'Read-only observer of customer infrastructure, costs, and reports', TRUE)
ON CONFLICT (code) DO NOTHING;

-- 2. Insert Organizations
INSERT INTO organizations (id, name, code, type, tier, is_active) VALUES
('22222222-2222-2222-2222-222222222201', 'SWEDTEL Global AB', 'SWEDTEL_HQ', 'PROVIDER', 'MISSION_CRITICAL', TRUE),
('22222222-2222-2222-2222-222222222202', 'Nordic Health Solutions AB', 'NORDIC_HEALTH', 'CUSTOMER', 'MISSION_CRITICAL', TRUE),
('22222222-2222-2222-2222-222222222203', 'Stockholm Financial Services', 'STHLM_FIN', 'CUSTOMER', 'ENTERPRISE', TRUE),
('22222222-2222-2222-2222-222222222204', 'Scania Logistics Cloud', 'SCANIA_LOG', 'CUSTOMER', 'ENTERPRISE', TRUE)
ON CONFLICT (code) DO NOTHING;

-- 3. Insert Users (Password: SwedtelCloud2026! hashed with bcrypt)
-- Using a standard bcrypt hash representation
INSERT INTO users (id, organization_id, email, password_hash, first_name, last_name, job_title, is_active, email_verified) VALUES
('33333333-3333-3333-3333-333333333301', '22222222-2222-2222-2222-222222222201', 'admin@swedtel.com', '$2a$12$KIXl02K.7q2hGz4JkZ.x7eE57vBfx0C9/8oRk4W8Ea2H5.pQw7n6C', 'Erik', 'Lindqvist', 'Chief Cloud Architect', TRUE, TRUE),
('33333333-3333-3333-3333-333333333302', '22222222-2222-2222-2222-222222222201', 'engineer@swedtel.com', '$2a$12$KIXl02K.7q2hGz4JkZ.x7eE57vBfx0C9/8oRk4W8Ea2H5.pQw7n6C', 'Astrid', 'Bergström', 'Lead SRE & Automation Engineer', TRUE, TRUE),
('33333333-3333-3333-3333-333333333303', '22222222-2222-2222-2222-222222222201', 'finops@swedtel.com', '$2a$12$KIXl02K.7q2hGz4JkZ.x7eE57vBfx0C9/8oRk4W8Ea2H5.pQw7n6C', 'Nils', 'Holgersson', 'FinOps Lead Specialist', TRUE, TRUE),
('33333333-3333-3333-3333-333333333304', '22222222-2222-2222-2222-222222222202', 'karin@nordichealth.se', '$2a$12$KIXl02K.7q2hGz4JkZ.x7eE57vBfx0C9/8oRk4W8Ea2H5.pQw7n6C', 'Karin', 'Larsson', 'Director of Cloud IT', TRUE, TRUE)
ON CONFLICT (email) DO NOTHING;

-- Assign User Roles
INSERT INTO user_roles (user_id, role_id, organization_id) VALUES
('33333333-3333-3333-3333-333333333301', '11111111-1111-1111-1111-111111111101', '22222222-2222-2222-2222-222222222201'),
('33333333-3333-3333-3333-333333333302', '11111111-1111-1111-1111-111111111102', '22222222-2222-2222-2222-222222222201'),
('33333333-3333-3333-3333-333333333303', '11111111-1111-1111-1111-111111111103', '22222222-2222-2222-2222-222222222201'),
('33333333-3333-3333-3333-333333333304', '11111111-1111-1111-1111-111111111105', '22222222-2222-2222-2222-222222222202')
ON CONFLICT DO NOTHING;

-- 4. Insert Customers
INSERT INTO customers (id, organization_id, name, code, industry, contact_email, phone, tier, sla_level, status, monthly_budget, dedicated_engineer_id) VALUES
('44444444-4444-4444-4444-444444444401', '22222222-2222-2222-2222-222222222202', 'Nordic Health Solutions AB', 'NORDIC_HEALTH', 'Healthcare & Life Sciences', 'ops@nordichealth.se', '+46 8 500 1200', 'MISSION_CRITICAL', '24/7 Dedicated SRE (99.99%)', 'ACTIVE', 75000.00, '33333333-3333-3333-3333-333333333302'),
('44444444-4444-4444-4444-444444444402', '22222222-2222-2222-2222-222222222203', 'Stockholm Financial Services', 'STHLM_FIN', 'Banking & FinTech', 'cloud-infra@sthlmfin.se', '+46 8 600 4500', 'ENTERPRISE', '24/7 Business Critical (99.95%)', 'ACTIVE', 120000.00, '33333333-3333-3333-3333-333333333301'),
('44444444-4444-4444-4444-444444444403', '22222222-2222-2222-2222-222222222204', 'Scania Logistics Cloud', 'SCANIA_LOG', 'Automotive & Logistics', 'telematics@scania.se', '+46 8 700 9800', 'ENTERPRISE', 'Business Hours Standard (99.9%)', 'ACTIVE', 45000.00, '33333333-3333-3333-3333-333333333302')
ON CONFLICT (code) DO NOTHING;

-- 5. Insert Cloud Accounts (Cross-Cloud Connections)
INSERT INTO cloud_accounts (id, customer_id, provider, name, account_or_project_id, environment, connection_type, auth_secret_name, status, is_demo) VALUES
('55555555-5555-5555-5555-555555555501', '44444444-4444-4444-4444-444444444401', 'GCP', 'NordicHealth Core GKE & Analytics', 'nordic-health-prod-5849', 'PRODUCTION', 'WIF', 'projects/swedtel-hub/secrets/nordic-gcp-wif', 'CONNECTED', FALSE),
('55555555-5555-5555-5555-555555555502', '44444444-4444-4444-4444-444444444401', 'AWS', 'NordicHealth Telehealth Streaming', '829471928410', 'PRODUCTION', 'STS_ASSUME_ROLE', 'projects/swedtel-hub/secrets/nordic-aws-sts', 'CONNECTED', TRUE),
('55555555-5555-5555-5555-555555555503', '44444444-4444-4444-4444-444444444402', 'GCP', 'SthlmFin Risk Engine & BigQuery', 'sthlm-fin-analytics-9912', 'PRODUCTION', 'WIF', 'projects/swedtel-hub/secrets/sthlm-gcp-wif', 'CONNECTED', FALSE),
('55555555-5555-5555-5555-555555555504', '44444444-4444-4444-4444-444444444402', 'AZURE', 'SthlmFin Core Banking Ledger', 'a4f9104c-32ef-410a-9ff1-998811223344', 'PRODUCTION', 'SERVICE_PRINCIPAL', 'projects/swedtel-hub/secrets/sthlm-azure-sp', 'CONNECTED', TRUE)
ON CONFLICT DO NOTHING;

-- 6. Insert Cloud Resources
INSERT INTO cloud_resources (id, customer_id, cloud_account_id, provider, resource_type, resource_id, name, region, zone, status, cpu_utilization_pct, memory_utilization_pct, disk_utilization_pct, monthly_cost, tags, is_demo) VALUES
('66666666-6666-6666-6666-666666666601', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', 'GCP', 'KUBERNETES_CLUSTER', 'gke-nordic-prod-cluster-01', 'gke-nordic-prod-cluster', 'europe-north1', 'europe-north1-a', 'HEALTHY', 42.50, 68.20, 31.00, 14200.00, '{"env":"prod","team":"platform","tier":"p1"}'::jsonb, FALSE),
('66666666-6666-6666-6666-666666666602', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', 'GCP', 'MANAGED_DATABASE', 'cloudsql-nordic-ehr-pg16', 'cloudsql-nordic-ehr-db', 'europe-north1', 'europe-north1-b', 'HEALTHY', 24.80, 54.10, 48.30, 4850.00, '{"env":"prod","type":"postgres16","compliance":"hipaa"}'::jsonb, FALSE),
('66666666-6666-6666-6666-666666666603', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', 'GCP', 'OBJECT_STORAGE', 'gcs-patient-imaging-vault', 'gcs-patient-imaging-vault', 'europe-north1', NULL, 'HEALTHY', 0.00, 0.00, 82.40, 6200.00, '{"storage_class":"standard","retention":"7y"}'::jsonb, FALSE),
('66666666-6666-6666-6666-666666666604', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555502', 'AWS', 'VIRTUAL_MACHINE', 'i-0a883921049bfe91', 'ec2-telehealth-webrtc-node01', 'eu-north-1', 'eu-north-1a', 'WARNING', 89.20, 92.50, 44.00, 1850.00, '{"service":"webrtc","autoscaling":"enabled"}'::jsonb, TRUE),
('66666666-6666-6666-6666-666666666605', '44444444-4444-4444-4444-444444444402', '55555555-5555-5555-5555-555555555503', 'GCP', 'MANAGED_DATABASE', 'bigquery-sthlm-risk-wh', 'bigquery-sthlm-risk-wh', 'europe-west3', NULL, 'HEALTHY', 15.00, 30.00, 65.00, 24500.00, '{"env":"prod","engine":"bigquery"}'::jsonb, FALSE),
('66666666-6666-6666-6666-666666666606', '44444444-4444-4444-4444-444444444402', '55555555-5555-5555-5555-555555555504', 'AZURE', 'MANAGED_DATABASE', 'azsql-sthlm-ledger-db', 'azsql-sthlm-ledger-db', 'swedencentral', NULL, 'HEALTHY', 35.00, 60.00, 50.00, 18900.00, '{"env":"prod","region":"sweden-central"}'::jsonb, TRUE)
ON CONFLICT DO NOTHING;

-- 7. Insert Cost Records & FinOps
INSERT INTO cost_records (customer_id, cloud_account_id, provider, service_name, project_identifier, cost_date, amount, currency, is_anomaly, anomaly_reason, is_demo) VALUES
('44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', 'GCP', 'Google Kubernetes Engine (GKE)', 'nordic-health-prod-5849', CURRENT_DATE - INTERVAL '1 day', 473.33, 'EUR', FALSE, NULL, FALSE),
('44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', 'GCP', 'Cloud SQL PostgreSQL', 'nordic-health-prod-5849', CURRENT_DATE - INTERVAL '1 day', 161.66, 'EUR', FALSE, NULL, FALSE),
('44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', 'GCP', 'Cloud Storage (GCS)', 'nordic-health-prod-5849', CURRENT_DATE - INTERVAL '1 day', 206.66, 'EUR', FALSE, NULL, FALSE),
('44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555502', 'AWS', 'Amazon EC2 Compute', '829471928410', CURRENT_DATE - INTERVAL '1 day', 185.00, 'EUR', TRUE, 'Unexpected +145% spike in unattached gp3 EBS IOPS during batch ingest', TRUE),
('44444444-4444-4444-4444-444444444402', '55555555-5555-5555-5555-555555555503', 'GCP', 'BigQuery Enterprise Slots', 'sthlm-fin-analytics-9912', CURRENT_DATE - INTERVAL '1 day', 816.66, 'EUR', FALSE, NULL, FALSE),
('44444444-4444-4444-4444-444444444402', '55555555-5555-5555-5555-555555555504', 'AZURE', 'Azure SQL Managed Instance', 'a4f9104c-32ef-410a', CURRENT_DATE - INTERVAL '1 day', 630.00, 'EUR', FALSE, NULL, TRUE);

-- 8. Insert Budgets
INSERT INTO budgets (customer_id, name, monthly_limit, current_spend, currency, alert_threshold_pct, alert_emails, status) VALUES
('44444444-4444-4444-4444-444444444401', 'NordicHealth Monthly Operating Budget', 75000.00, 48250.00, 'EUR', 85, ARRAY['ops@nordichealth.se', 'finops@swedtel.com'], 'ON_TRACK'),
('44444444-4444-4444-4444-444444444402', 'SthlmFin Risk Analytics & Core Ledger', 120000.00, 108400.00, 'EUR', 90, ARRAY['cloud-infra@sthlmfin.se'], 'NEAR_LIMIT');

-- 9. Insert Alerts
INSERT INTO alerts (id, customer_id, cloud_account_id, resource_id, title, description, severity, status, source, triggered_at) VALUES
('77777777-7777-7777-7777-777777777701', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555502', '66666666-6666-6666-6666-666666666604', 'High Memory Utilization Threshold Exceeded', 'EC2 node ec2-telehealth-webrtc-node01 memory sustained > 92% for 15 minutes', 'CRITICAL', 'OPEN', 'AWS_CLOUDWATCH', NOW() - INTERVAL '42 minutes'),
('77777777-7777-7777-7777-777777777702', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555502', NULL, 'FinOps Cost Spike Anomaly in AWS eu-north-1', 'Daily EBS spend increased +145% above rolling 30-day baseline', 'HIGH', 'IN_PROGRESS', 'SWEDTEL_FINOPS_DETECTOR', NOW() - INTERVAL '3 hours'),
('77777777-7777-7777-7777-777777777703', '44444444-4444-4444-4444-444444444402', '55555555-5555-5555-5555-555555555503', '66666666-6666-6666-6666-666666666605', 'BigQuery Slot Contention During Nightly Risk Batch', 'Query execution time exceeded SLA target by 18 minutes', 'MEDIUM', 'OPEN', 'GCP_CLOUD_MONITORING', NOW() - INTERVAL '5 hours')
ON CONFLICT DO NOTHING;

-- 10. Insert Security Findings
INSERT INTO security_findings (id, customer_id, cloud_account_id, resource_id, title, description, severity, compliance_framework, cis_control_id, remediation_steps, status, is_automated_fix_available) VALUES
('88888888-8888-8888-8888-888888888801', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', '66666666-6666-6666-6666-666666666603', 'Ensure Cloud Storage Bucket Access is Not Publicly Readable', 'Storage bucket gcs-patient-imaging-vault must enforce Uniform Bucket-Level Access and prevent allUsers IAM binding', 'CRITICAL', 'CIS_BENCHMARK_V2', 'CIS GCP 5.1', 'Run gcloud storage buckets update --uniform-bucket-level-access to enforce strict IAM access control', 'OPEN', TRUE),
('88888888-8888-8888-8888-888888888802', '44444444-4444-4444-4444-444444444401', '55555555-5555-5555-5555-555555555501', '66666666-6666-6666-6666-666666666602', 'Enable Point-in-Time Recovery & Binary Logging for Cloud SQL PostgreSQL', 'Database instance cloudsql-nordic-ehr-pg16 requires automated backups with at least 7-day retention for SOC 2', 'HIGH', 'SOC2_TYPE_II', 'SOC2 CC6.6', 'Update Cloud SQL instance settings to enable point-in-time recovery and automated daily backups', 'OPEN', TRUE),
('88888888-8888-8888-8888-888888888803', '44444444-4444-4444-4444-444444444402', '55555555-5555-5555-5555-555555555504', '66666666-6666-6666-6666-666666666606', 'Enforce Customer-Managed Encryption Keys (CMEK) via Azure Key Vault', 'Database storage volume must use dedicated KMS key rotation rather than default platform encryption', 'MEDIUM', 'ISO_27001', 'ISO 27001 A.10', 'Attach Azure Key Vault customer key to Azure SQL Server instance', 'OPEN', FALSE)
ON CONFLICT DO NOTHING;

-- 11. Insert Automation Workflows
INSERT INTO automation_workflows (id, customer_id, name, description, target_provider, trigger_type, schedule_cron, action_type, action_payload, requires_approval, is_active) VALUES
('99999999-9999-9999-9999-999999999901', '44444444-4444-4444-4444-444444444401', 'Off-Hours Non-Production VM Shutdown', 'Automatically stops development and staging Compute Engine instances at 19:00 CET and starts at 07:00 CET', 'GCP', 'SCHEDULE', '0 19 * * 1-5', 'STOP_DEV_VMS', '{"target_tags":["env:dev","env:staging"],"auto_resume_cron":"0 7 * * 1-5"}'::jsonb, FALSE, TRUE),
('99999999-9999-9999-9999-999999999902', '44444444-4444-4444-4444-444444444401', 'Purge Unattached EBS & Persistent Disks (> 14 Days)', 'Identifies and deletes orphaned cloud disks older than 14 days after generating a final safety snapshot', 'ALL', 'SCHEDULE', '0 2 * * 0', 'PURGE_UNATTACHED_DISKS', '{"create_snapshot_before_delete":true,"retention_days":30}'::jsonb, TRUE, TRUE),
('99999999-9999-9999-9999-999999999903', '44444444-4444-4444-4444-444444444402', 'Pre-Market Risk Engine Auto-Scale', 'Scales up BigQuery reservations and Azure SQL compute pools at 06:00 CET before European trading hours', 'GCP', 'SCHEDULE', '0 6 * * 1-5', 'RESIZE_K8S_NODEPOOL', '{"target_nodes":12,"min_nodes":4}'::jsonb, FALSE, TRUE)
ON CONFLICT DO NOTHING;

-- 12. Insert Support Tickets
INSERT INTO support_tickets (id, ticket_number, customer_id, created_by_user_id, assigned_to_user_id, title, description, category, priority, status, sla_due_at) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'SWED-8491', '44444444-4444-4444-4444-444444444401', '33333333-3333-3333-3333-333333333304', '33333333-3333-3333-3333-333333333302', 'GKE Ingress SSL Handshake Latency Spike in Stockholm Region', 'Observing intermittent 502 Bad Gateway responses during high-throughput patient sync. Need immediate SRE investigation.', 'INFRASTRUCTURE', 'P1_CRITICAL', 'IN_PROGRESS', NOW() + INTERVAL '45 minutes'),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'SWED-8492', '44444444-4444-4444-4444-444444444401', '33333333-3333-3333-3333-333333333304', '33333333-3333-3333-3333-333333333303', 'FinOps Analysis Request: BigQuery Slot Reservation Optimization', 'Please review our Q3 query utilization to evaluate migrating from on-demand pricing to 100 Edition Baseline commitment.', 'FINOPS', 'P3_MEDIUM', 'OPEN', NOW() + INTERVAL '24 hours')
ON CONFLICT (ticket_number) DO NOTHING;

-- Insert Ticket Messages
INSERT INTO ticket_messages (ticket_id, sender_user_id, sender_name, message, is_internal_note) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '33333333-3333-3333-3333-333333333304', 'Karin Larsson', 'We noticed increased p99 latency starting at 09:15 CET on endpoint api.nordichealth.se/v1/sync. Logs attached.', FALSE),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '33333333-3333-3333-3333-333333333302', 'Astrid Bergström', '[INTERNAL NOTE]: Checked Cloud Armor logs - observed high rate of TLS renegotiation requests from a partner IP block. Adjusting rate limiting threshold.', TRUE),
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '33333333-3333-3333-3333-333333333302', 'Astrid Bergström', 'Hello Karin, our SRE team has isolated the issue to a transient rate limit edge filter. We have deployed a hotfix to Cloud Armor and traffic is normalizing.', FALSE);

-- 13. Insert Initial Audit Logs
INSERT INTO audit_logs (organization_id, customer_id, user_id, user_email, user_role, action, resource_type, resource_id, ip_address, status, details) VALUES
('22222222-2222-2222-2222-222222222201', NULL, '33333333-3333-3333-3333-333333333301', 'admin@swedtel.com', 'SUPER_ADMIN', 'SYSTEM_INITIALIZATION', 'PLATFORM', 'SWEDTEL-SAAS-V1', '127.0.0.1', 'SUCCESS', '{"version":"1.0.0","environment":"production"}'::jsonb),
('22222222-2222-2222-2222-222222222201', '44444444-4444-4444-4444-444444444401', '33333333-3333-3333-3333-333333333302', 'engineer@swedtel.com', 'CLOUD_ENGINEER', 'CLOUD_ACCOUNT_VALIDATION', 'CLOUD_ACCOUNT', '55555555-5555-5555-5555-555555555501', '192.168.1.100', 'SUCCESS', '{"provider":"GCP","projectId":"nordic-health-prod-5849","authType":"WIF"}'::jsonb);
