-- ====================================================================
-- SWEDTEL Cloud Management Platform - PostgreSQL Database Schema
-- Version: 1.0.0
-- Migration: 001_initial_schema.sql
-- ====================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. Organizations (Top-level SaaS Tenants & Managing Entity)
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    type VARCHAR(50) NOT NULL DEFAULT 'CUSTOMER', -- 'PROVIDER' (SWEDTEL) or 'CUSTOMER'
    tier VARCHAR(50) NOT NULL DEFAULT 'ENTERPRISE',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 2. Users & Identities
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    job_title VARCHAR(100),
    phone VARCHAR(50),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_secret VARCHAR(255),
    last_login_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 3. Roles & Permissions (Server-Side RBAC)
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_system_role BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(100) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL
);

CREATE TABLE role_permissions (
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE user_roles (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    granted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, role_id, organization_id)
);

-- 4. Customers (Managed Tenant Organizations)
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    industry VARCHAR(100) NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    tier VARCHAR(50) NOT NULL DEFAULT 'ENTERPRISE', -- 'STARTER', 'GROWTH', 'ENTERPRISE', 'MISSION_CRITICAL'
    sla_level VARCHAR(50) NOT NULL DEFAULT '24/7 Premium (99.99%)',
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE', -- 'ACTIVE', 'PROVISIONING', 'SUSPENDED'
    monthly_budget NUMERIC(12, 2) NOT NULL DEFAULT 50000.00,
    dedicated_engineer_id UUID REFERENCES users(id) ON DELETE SET NULL,
    account_manager_id UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 5. Cloud Accounts & Projects (Cross-Cloud Credential & Account References)
CREATE TABLE cloud_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    provider VARCHAR(50) NOT NULL, -- 'GCP', 'AWS', 'AZURE'
    name VARCHAR(255) NOT NULL,
    account_or_project_id VARCHAR(255) NOT NULL,
    target_service_account VARCHAR(255),
    environment VARCHAR(50) NOT NULL DEFAULT 'PRODUCTION', -- 'PRODUCTION', 'STAGING', 'DEVELOPMENT', 'DR'
    connection_type VARCHAR(50) NOT NULL DEFAULT 'WIF', -- 'WIF' (Workload Identity), 'STS_ASSUME_ROLE', 'SERVICE_PRINCIPAL', 'SECRET_MANAGER_REF'
    connection_mode VARCHAR(50) NOT NULL DEFAULT 'DEMO', -- 'DEMO', 'LIVE'
    auth_secret_name VARCHAR(255), -- Reference key in Google Secret Manager (NEVER raw secret in DB)
    status VARCHAR(50) NOT NULL DEFAULT 'CONNECTED', -- 'CONNECTED', 'DEGRADED', 'SYNC_PENDING', 'AUTH_ERROR', 'PERMISSION_ERROR', 'API_NOT_ENABLED'
    last_synced_at TIMESTAMP WITH TIME ZONE,
    last_sync_status VARCHAR(50) DEFAULT 'SUCCESS', -- 'SUCCESS', 'FAILED', 'SYNCING', 'PENDING'
    last_sync_error TEXT,
    is_demo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_customer_provider_account UNIQUE(customer_id, provider, account_or_project_id)
);

CREATE TABLE cloud_projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cloud_account_id UUID NOT NULL REFERENCES cloud_accounts(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    project_identifier VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    region VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 6. Cloud Resources (Inventory & Telemetry)
CREATE TABLE cloud_resources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    cloud_account_id UUID NOT NULL REFERENCES cloud_accounts(id) ON DELETE CASCADE,
    project_id VARCHAR(255),
    provider VARCHAR(50) NOT NULL,
    resource_type VARCHAR(100) NOT NULL, -- 'KUBERNETES_CLUSTER', 'VIRTUAL_MACHINE', 'MANAGED_DATABASE', 'OBJECT_STORAGE', 'VPC_NETWORK', 'SERVERLESS_FUNCTION'
    resource_id VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    region VARCHAR(100) NOT NULL,
    zone VARCHAR(100),
    status VARCHAR(50) NOT NULL DEFAULT 'HEALTHY', -- 'HEALTHY', 'WARNING', 'CRITICAL', 'STOPPED'
    cpu_utilization_pct NUMERIC(5, 2) DEFAULT 0.00,
    memory_utilization_pct NUMERIC(5, 2) DEFAULT 0.00,
    disk_utilization_pct NUMERIC(5, 2) DEFAULT 0.00,
    network_in_mbps NUMERIC(10, 2) DEFAULT 0.00,
    network_out_mbps NUMERIC(10, 2) DEFAULT 0.00,
    monthly_cost NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    tags JSONB DEFAULT '{}'::jsonb,
    metadata JSONB DEFAULT '{}'::jsonb,
    connection_mode VARCHAR(50) NOT NULL DEFAULT 'DEMO',
    is_demo BOOLEAN NOT NULL DEFAULT TRUE,
    last_telemetry_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 7. FinOps & Cost Records
CREATE TABLE cost_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    cloud_account_id UUID NOT NULL REFERENCES cloud_accounts(id) ON DELETE CASCADE,
    provider VARCHAR(50) NOT NULL,
    service_name VARCHAR(150) NOT NULL,
    project_identifier VARCHAR(255),
    cost_date DATE NOT NULL,
    amount NUMERIC(12, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'EUR',
    usage_unit VARCHAR(50),
    usage_quantity NUMERIC(16, 4),
    is_anomaly BOOLEAN NOT NULL DEFAULT FALSE,
    anomaly_reason TEXT,
    is_demo BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE budgets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    monthly_limit NUMERIC(12, 2) NOT NULL,
    current_spend NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(10) NOT NULL DEFAULT 'EUR',
    alert_threshold_pct INT NOT NULL DEFAULT 85,
    alert_emails TEXT[] NOT NULL DEFAULT '{}',
    status VARCHAR(50) NOT NULL DEFAULT 'ON_TRACK', -- 'ON_TRACK', 'NEAR_LIMIT', 'EXCEEDED'
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 8. Alerts & SRE Incidents
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    cloud_account_id UUID REFERENCES cloud_accounts(id) ON DELETE SET NULL,
    resource_id UUID REFERENCES cloud_resources(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    severity VARCHAR(50) NOT NULL, -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'
    status VARCHAR(50) NOT NULL DEFAULT 'OPEN', -- 'OPEN', 'ACKNOWLEDGED', 'IN_PROGRESS', 'RESOLVED'
    source VARCHAR(100) NOT NULL, -- 'GCP_CLOUD_MONITORING', 'AWS_CLOUDWATCH', 'AZURE_MONITOR', 'SWEDTEL_FINOPS_DETECTOR'
    metric_name VARCHAR(100),
    threshold_value VARCHAR(100),
    actual_value VARCHAR(100),
    triggered_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    resolution_notes TEXT
);

CREATE TABLE incidents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    alert_id UUID REFERENCES alerts(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    severity VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'INVESTIGATING', -- 'INVESTIGATING', 'IDENTIFIED', 'MONITORING', 'RESOLVED'
    root_cause_analysis TEXT,
    ai_runbook_remediation TEXT,
    assigned_engineer_id UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMP WITH TIME ZONE
);

-- 9. Security Posture & CIS Compliance
CREATE TABLE security_findings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    cloud_account_id UUID REFERENCES cloud_accounts(id) ON DELETE SET NULL,
    resource_id UUID REFERENCES cloud_resources(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    severity VARCHAR(50) NOT NULL, -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
    compliance_framework VARCHAR(100) NOT NULL DEFAULT 'CIS_BENCHMARK_V2', -- 'CIS_BENCHMARK_V2', 'SOC2_TYPE_II', 'ISO_27001', 'GDPR'
    cis_control_id VARCHAR(50) NOT NULL,
    remediation_steps TEXT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'OPEN', -- 'OPEN', 'REMEDIATING', 'RESOLVED', 'SUPPRESSED'
    is_automated_fix_available BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 10. Cloud Automation & Governance Workflows
CREATE TABLE automation_workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    target_provider VARCHAR(50) NOT NULL, -- 'GCP', 'AWS', 'AZURE', 'ALL'
    trigger_type VARCHAR(50) NOT NULL, -- 'SCHEDULE', 'THRESHOLD', 'SECURITY_EVENT', 'MANUAL'
    schedule_cron VARCHAR(100),
    threshold_metric VARCHAR(100),
    threshold_value NUMERIC(12, 2),
    action_type VARCHAR(100) NOT NULL, -- 'STOP_DEV_VMS', 'PURGE_UNATTACHED_DISKS', 'AUTO_SNAPSHOT_DBS', 'RESIZE_K8S_NODEPOOL'
    action_payload JSONB DEFAULT '{}'::jsonb,
    requires_approval BOOLEAN NOT NULL DEFAULT TRUE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE automation_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL REFERENCES automation_workflows(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    triggered_by VARCHAR(100) NOT NULL, -- 'CRON_SCHEDULER', 'SYSTEM_RULE', 'USER'
    status VARCHAR(50) NOT NULL DEFAULT 'RUNNING', -- 'RUNNING', 'COMPLETED', 'FAILED', 'PENDING_APPROVAL', 'REJECTED'
    started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMP WITH TIME ZONE,
    duration_ms INT,
    execution_log TEXT,
    approved_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    approval_timestamp TIMESTAMP WITH TIME ZONE
);

-- 11. Support Helpdesk & Ticket Management
CREATE TABLE support_tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_number VARCHAR(50) NOT NULL UNIQUE,
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    assigned_to_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(100) NOT NULL DEFAULT 'INFRASTRUCTURE', -- 'INFRASTRUCTURE', 'FINOPS', 'SECURITY', 'NETWORK', 'BILLING'
    priority VARCHAR(50) NOT NULL DEFAULT 'P2_HIGH', -- 'P1_CRITICAL', 'P2_HIGH', 'P3_MEDIUM', 'P4_LOW'
    status VARCHAR(50) NOT NULL DEFAULT 'OPEN', -- 'OPEN', 'IN_PROGRESS', 'WAITING_CUSTOMER', 'RESOLVED', 'CLOSED'
    sla_due_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE TABLE ticket_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_id UUID NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
    sender_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    sender_name VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_internal_note BOOLEAN NOT NULL DEFAULT FALSE, -- SWEDTEL engineers internal collaboration
    attachments JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 12. Reports & Executive Documents
CREATE TABLE reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL, -- 'FINOPS_MONTHLY', 'CIS_SECURITY_AUDIT', 'SLA_UPTIME', 'CARBON_SUSTAINABILITY'
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    generated_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    file_url VARCHAR(500),
    summary_data JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 13. SOC 2 Compliant Server-Side Audit Logs (Immutable)
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
    customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    user_email VARCHAR(255) NOT NULL,
    user_role VARCHAR(100) NOT NULL,
    action VARCHAR(150) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id VARCHAR(255),
    ip_address VARCHAR(100),
    user_agent TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'SUCCESS', -- 'SUCCESS', 'DENIED', 'FAILURE'
    details JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 14. Real-Time In-App Notifications
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL DEFAULT 'INFO', -- 'INFO', 'ALERT', 'SECURITY', 'FINOPS'
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    link VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- ====================================================================
-- Performance Indexes & Foreign Key Optimizations
-- ====================================================================

CREATE INDEX idx_users_org_id ON users(organization_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_customers_org_id ON customers(organization_id);
CREATE INDEX idx_cloud_accounts_customer_id ON cloud_accounts(customer_id);
CREATE INDEX idx_cloud_resources_customer_id ON cloud_resources(customer_id);
CREATE INDEX idx_cloud_resources_provider ON cloud_resources(provider);
CREATE INDEX idx_cloud_resources_status ON cloud_resources(status);
CREATE INDEX idx_cost_records_customer_date ON cost_records(customer_id, cost_date);
CREATE INDEX idx_cost_records_service ON cost_records(service_name);
CREATE INDEX idx_alerts_customer_status ON alerts(customer_id, status);
CREATE INDEX idx_security_findings_customer_status ON security_findings(customer_id, status);
CREATE INDEX idx_automation_workflows_customer ON automation_workflows(customer_id);
CREATE INDEX idx_support_tickets_customer ON support_tickets(customer_id, status);
CREATE INDEX idx_ticket_messages_ticket_id ON ticket_messages(ticket_id);
CREATE INDEX idx_audit_logs_org_customer ON audit_logs(organization_id, customer_id, created_at DESC);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);
