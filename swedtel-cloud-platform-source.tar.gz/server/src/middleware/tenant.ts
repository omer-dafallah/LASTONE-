// ====================================================================
// SWEDTEL Cloud Management Platform - Multi-Tenant Isolation Middleware
// ====================================================================

import { Request, Response, NextFunction } from 'express';
import { OrganizationType, UserRole } from '../types/index.js';

export interface TenantContext {
  isProviderAdmin: boolean;
  accessibleCustomerIds: string[]; // Customer IDs the active user is permitted to query
  activeCustomerId?: string;       // Explicit single-tenant filter if selected
}

declare global {
  namespace Express {
    interface Request {
      tenantContext?: TenantContext;
    }
  }
}

export function enforceTenantContext(req: Request, res: Response, next: NextFunction): void {
  const user = req.user;

  if (!user) {
    res.status(401).json({
      success: false,
      error: 'UNAUTHORIZED',
      message: 'Authentication context is required for tenant isolation.'
    });
    return;
  }

  // 1. SWEDTEL Internal Staff (Super Admin, Cloud Engineer, FinOps, Account Manager)
  // Have fleet-wide authority, but may optionally filter queries down to a single tenant.
  if (user.organizationType === OrganizationType.PROVIDER) {
    const requestedTenant = req.headers['x-swedtel-tenant-id'] as string || req.query.customerId as string;
    
    req.tenantContext = {
      isProviderAdmin: true,
      accessibleCustomerIds: ['*'], // Unrestricted access across all customers
      activeCustomerId: requestedTenant && requestedTenant !== 'ALL' ? requestedTenant : undefined
    };
    return next();
  }

  // 2. Customer Tenants (Customer Admin, Customer Viewer)
  // STRICT ENFORCEMENT: Their access is strictly locked to their own bound customer ID.
  // Even if the client sends a different customerId in query, headers, or body, it is IGNORED or REJECTED.
  const boundCustomerId = user.customerId;
  if (!boundCustomerId) {
    res.status(403).json({
      success: false,
      error: 'TENANT_NOT_BOUND',
      message: 'Customer user identity has no bound customer organization.'
    });
    return;
  }

  // If a malicious customer attempts to supply an external customer ID in params
  const explicitRequested = req.params.customerId || req.query.customerId || req.body?.customerId;
  if (explicitRequested && explicitRequested !== boundCustomerId) {
    res.status(403).json({
      success: false,
      error: 'CROSS_TENANT_VIOLATION',
      message: 'Access Denied: You are not authorized to access resources belonging to other customer tenants.'
    });
    return;
  }

  req.tenantContext = {
    isProviderAdmin: false,
    accessibleCustomerIds: [boundCustomerId],
    activeCustomerId: boundCustomerId
  };

  next();
}
