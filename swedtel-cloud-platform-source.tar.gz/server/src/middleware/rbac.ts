// ====================================================================
// SWEDTEL Cloud Management Platform - Server-Side RBAC Middleware
// ====================================================================

import { Request, Response, NextFunction } from 'express';
import { UserRole } from '../types/index.js';

export function requireRole(...allowedRoles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = req.user;

    if (!user) {
      res.status(401).json({
        success: false,
        error: 'UNAUTHORIZED',
        message: 'Authentication is required.'
      });
      return;
    }

    if (user.role === UserRole.SUPER_ADMIN) {
      return next(); // Super Admin bypasses all checks
    }

    if (!allowedRoles.includes(user.role)) {
      res.status(403).json({
        success: false,
        error: 'FORBIDDEN_INSUFFICIENT_ROLE',
        message: `Action requires one of the following roles: [${allowedRoles.join(', ')}]. Current role: ${user.role}`
      });
      return;
    }

    next();
  };
}

export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = req.user;

    if (!user) {
      res.status(401).json({ success: false, error: 'UNAUTHORIZED' });
      return;
    }

    if (user.role === UserRole.SUPER_ADMIN || user.permissions.includes('*') || user.permissions.includes(permission)) {
      return next();
    }

    res.status(403).json({
      success: false,
      error: 'FORBIDDEN_INSUFFICIENT_PERMISSION',
      message: `Action requires permission '${permission}'`
    });
  };
}
