// ====================================================================
// SWEDTEL Cloud Management Platform - Authentication Middleware
// ====================================================================

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config/index.js';
import { AuthUserContext, UserRole, OrganizationType } from '../types/index.js';

// Extend Express Request
declare global {
  namespace Express {
    interface Request {
      user?: AuthUserContext;
    }
  }
}

// Development Demo Users for direct identity simulation
export const DEMO_IDENTITIES: Record<string, AuthUserContext> = {
  superadmin: {
    userId: 'user-admin-001',
    email: 'lars.lindqvist@swedtel.se',
    firstName: 'Lars',
    lastName: 'Lindqvist',
    organizationId: 'org-swedtel-hq',
    organizationType: OrganizationType.PROVIDER,
    role: UserRole.SUPER_ADMIN,
    permissions: ['*']
  },
  super_admin: {
    userId: 'user-admin-001',
    email: 'lars.lindqvist@swedtel.se',
    firstName: 'Lars',
    lastName: 'Lindqvist',
    organizationId: 'org-swedtel-hq',
    organizationType: OrganizationType.PROVIDER,
    role: UserRole.SUPER_ADMIN,
    permissions: ['*']
  },
  engineer: {
    userId: 'user-engineer-001',
    email: 'astrid.bergstrom@swedtel.se',
    firstName: 'Astrid',
    lastName: 'Bergström',
    organizationId: 'org-swedtel-hq',
    organizationType: OrganizationType.PROVIDER,
    role: UserRole.CLOUD_ENGINEER,
    permissions: ['cloud:read', 'cloud:write', 'automation:execute', 'tickets:manage', 'alerts:resolve']
  },
  cloud_engineer: {
    userId: 'user-engineer-001',
    email: 'astrid.bergstrom@swedtel.se',
    firstName: 'Astrid',
    lastName: 'Bergström',
    organizationId: 'org-swedtel-hq',
    organizationType: OrganizationType.PROVIDER,
    role: UserRole.CLOUD_ENGINEER,
    permissions: ['cloud:read', 'cloud:write', 'automation:execute', 'tickets:manage', 'alerts:resolve']
  },
  finops: {
    userId: 'user-finops-001',
    email: 'nils.holgersson@swedtel.se',
    firstName: 'Nils',
    lastName: 'Holgersson',
    organizationId: 'org-swedtel-hq',
    organizationType: OrganizationType.PROVIDER,
    role: UserRole.FINOPS_SPECIALIST,
    permissions: ['finops:read', 'finops:write', 'budgets:manage', 'reports:generate']
  },
  finops_lead: {
    userId: 'user-finops-001',
    email: 'nils.holgersson@swedtel.se',
    firstName: 'Nils',
    lastName: 'Holgersson',
    organizationId: 'org-swedtel-hq',
    organizationType: OrganizationType.PROVIDER,
    role: UserRole.FINOPS_SPECIALIST,
    permissions: ['finops:read', 'finops:write', 'budgets:manage', 'reports:generate']
  },
  account_manager: {
    userId: 'user-am-001',
    email: 'sofia.eklund@swedtel.se',
    firstName: 'Sofia',
    lastName: 'Eklund',
    organizationId: 'org-swedtel-hq',
    organizationType: OrganizationType.PROVIDER,
    role: UserRole.ACCOUNT_MANAGER,
    permissions: ['customers:read', 'customers:write', 'tickets:manage', 'reports:read']
  },
  customer_admin: {
    userId: 'user-karin-004',
    email: 'karin.larsson@nordichealth.se',
    firstName: 'Karin',
    lastName: 'Larsson',
    organizationId: 'org-nordic-health',
    organizationType: OrganizationType.CUSTOMER,
    role: UserRole.CUSTOMER_ADMIN,
    customerId: 'cust-nordic-health-001',
    permissions: ['tenant:admin', 'cloud:read', 'finops:read', 'tickets:create', 'reports:read']
  },
  customer_nordic_health_admin: {
    userId: 'user-karin-004',
    email: 'karin.larsson@nordichealth.se',
    firstName: 'Karin',
    lastName: 'Larsson',
    organizationId: 'org-nordic-health',
    organizationType: OrganizationType.CUSTOMER,
    role: UserRole.CUSTOMER_ADMIN,
    customerId: 'cust-nordic-health-001',
    permissions: ['tenant:admin', 'cloud:read', 'finops:read', 'tickets:create', 'reports:read']
  },
  customer_scania_admin: {
    userId: 'user-mats-006',
    email: 'mats.lind@scania-telematics.se',
    firstName: 'Mats',
    lastName: 'Lind',
    organizationId: 'org-scania-fleet',
    organizationType: OrganizationType.CUSTOMER,
    role: UserRole.CUSTOMER_ADMIN,
    customerId: 'cust-sthlm-fin-002',
    permissions: ['tenant:admin', 'cloud:read', 'finops:read', 'tickets:create', 'reports:read']
  },
  customer_viewer: {
    userId: 'user-viewer-005',
    email: 'olof.svensson@nordichealth.se',
    firstName: 'Olof',
    lastName: 'Svensson',
    organizationId: 'org-nordic-health',
    organizationType: OrganizationType.CUSTOMER,
    role: UserRole.CUSTOMER_VIEWER,
    customerId: 'cust-nordic-health-001',
    permissions: ['tenant:view', 'cloud:read', 'finops:read']
  }
};

export function authenticate(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  const devImpersonateHeader = req.headers['x-swedtel-impersonate-role'] as string;

  // 1. Check for standard JWT Bearer Token
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    try {
      const decoded = jwt.verify(token, config.jwtSecret) as AuthUserContext;
      req.user = decoded;
      return next();
    } catch (err) {
      // Fallback if token is expired/invalid during dev
    }
  }

  // 2. Fallback / Dev Identity switcher support (enables instant evaluation without external IdP)
  if (devImpersonateHeader && DEMO_IDENTITIES[devImpersonateHeader.toLowerCase()]) {
    req.user = DEMO_IDENTITIES[devImpersonateHeader.toLowerCase()];
    return next();
  }

  // 3. Default to Super Admin in sandbox if unauthenticated
  req.user = DEMO_IDENTITIES.superadmin;
  next();
}
