// ====================================================================
// SWEDTEL Cloud Management Platform - Server-Side Audit Log Service
// ====================================================================

import { Request } from 'express';
import { dbStore } from '../db/index.js';
import { AuditLog } from '../types/index.js';

export function logAuditEvent(
  req: Request,
  action: string,
  resourceType: string,
  resourceId?: string,
  status: 'SUCCESS' | 'DENIED' | 'FAILURE' | 'PENDING' = 'SUCCESS',
  details: Record<string, unknown> = {}
): void {
  const user = req.user;
  const auditLog: AuditLog = {
    id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    organizationId: user?.organizationId,
    customerId: req.tenantContext?.activeCustomerId || user?.customerId,
    customerName: user?.customerId ? dbStore.getCustomerName(user.customerId) : undefined,
    userId: user?.userId,
    userEmail: user?.email || 'anonymous',
    userRole: user?.role || 'UNKNOWN',
    action,
    resourceType,
    resourceId,
    ipAddress: req.ip || req.socket.remoteAddress || '127.0.0.1',
    userAgent: req.get('user-agent') || 'SWEDTEL-Web-Client',
    status,
    details,
    createdAt: new Date().toISOString()
  };

  dbStore.auditLogs.unshift(auditLog);
  console.log(`[AUDIT] [${auditLog.status}] ${auditLog.userEmail} (${auditLog.userRole}) -> ${auditLog.action} on ${auditLog.resourceType}:${auditLog.resourceId || 'N/A'}`);
}
