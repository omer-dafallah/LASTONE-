// ====================================================================
// SWEDTEL Cloud Management Platform - REST API Controllers
// ====================================================================

import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { dbStore } from '../db/index.js';
import { config } from '../config/index.js';
import { DEMO_IDENTITIES } from '../middleware/auth.js';
import { logAuditEvent } from '../middleware/audit.js';
import { CloudAdapterRegistry } from '../cloud/CloudAdapterRegistry.js';
import { GeminiServerAdvisor } from '../ai/GeminiServerAdvisor.js';
import {
  Customer, CloudAccount, CloudResource, CostRecord, Budget,
  Alert, SecurityFinding, AutomationWorkflow, AutomationExecution,
  SupportTicket, TicketMessage, Report, AuditLog,
  CloudProvider, ResourceType, ResourceStatus, Severity, AlertStatus,
  TicketPriority, TicketStatus, ConnectionType, UserRole
} from '../types/index.js';

// --- AUTH CONTROLLER ---
export const AuthController = {
  getCurrentUser(req: Request, res: Response): void {
    res.json({
      success: true,
      data: req.user
    });
  },

  switchDevRole(req: Request, res: Response): void {
    const { roleKey } = req.body;
    const identity = DEMO_IDENTITIES[roleKey?.toLowerCase()];
    if (!identity) {
      res.status(400).json({ success: false, error: 'Invalid role key' });
      return;
    }

    const token = jwt.sign(identity, config.jwtSecret, { expiresIn: '8h' });
    logAuditEvent(req, 'SWITCH_DEV_IDENTITY', 'IDENTITY', identity.userId, 'SUCCESS', { targetRole: identity.role });

    res.json({
      success: true,
      data: {
        user: identity,
        token
      }
    });
  },

  logout(req: Request, res: Response): void {
    logAuditEvent(req, 'USER_LOGOUT', 'IDENTITY', req.user?.userId);
    res.json({ success: true, message: 'Logged out successfully' });
  }
};

// --- CUSTOMERS CONTROLLER ---
export const CustomerController = {
  getAll(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let customers = dbStore.customers;

    // Filter by tenant context if restricted
    if (tenantCtx && !tenantCtx.isProviderAdmin) {
      customers = customers.filter(c => tenantCtx.accessibleCustomerIds.includes(c.id));
    }

    res.json({ success: true, data: customers });
  },

  getById(req: Request, res: Response): void {
    const { id } = req.params;
    const tenantCtx = req.tenantContext;

    if (tenantCtx && !tenantCtx.isProviderAdmin && !tenantCtx.accessibleCustomerIds.includes(id)) {
      res.status(403).json({ success: false, error: 'Access denied to this customer tenant' });
      return;
    }

    const customer = dbStore.customers.find(c => c.id === id);
    if (!customer) {
      res.status(404).json({ success: false, error: 'Customer not found' });
      return;
    }

    res.json({ success: true, data: customer });
  },

  create(req: Request, res: Response): void {
    const { name, code, industry, contactEmail, phone, tier, slaLevel, monthlyBudget } = req.body;
    if (!name || !code || !contactEmail) {
      res.status(400).json({ success: false, error: 'Missing required fields (name, code, contactEmail)' });
      return;
    }

    const newCustomer: Customer = {
      id: `cust-${Date.now()}`,
      organizationId: `org-${code.toLowerCase()}`,
      name,
      code: code.toUpperCase(),
      industry: industry || 'Enterprise Technology',
      contactEmail,
      phone,
      tier: tier || 'ENTERPRISE',
      slaLevel: slaLevel || '24/7 Standard (99.9%)',
      status: 'ACTIVE',
      monthlyBudget: Number(monthlyBudget) || 50000,
      monthlySpend: 0,
      securityScore: 100,
      cloudAccountsCount: 0,
      resourcesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    dbStore.customers.push(newCustomer);
    logAuditEvent(req, 'CREATE_CUSTOMER', 'CUSTOMER', newCustomer.id, 'SUCCESS', { name: newCustomer.name, code: newCustomer.code });

    res.status(201).json({ success: true, data: newCustomer });
  }
};

// --- CLOUD ACCOUNTS & INVENTORY CONTROLLER ---
export const CloudController = {
  getAccounts(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let accounts = dbStore.cloudAccounts;

    if (tenantCtx?.activeCustomerId) {
      accounts = accounts.filter(a => a.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      accounts = accounts.filter(a => tenantCtx.accessibleCustomerIds.includes(a.customerId));
    }

    res.json({ success: true, data: accounts });
  },

  async validateAndConnect(req: Request, res: Response): Promise<void> {
    const tenantCtx = req.tenantContext;
    const {
      customerId: requestedCustomerId,
      provider,
      name,
      accountOrProjectId,
      environment,
      connectionType,
      connectionMode,
      targetServiceAccount
    } = req.body;

    // Strict Tenant Boundary Resolution
    let effectiveCustomerId = requestedCustomerId;
    if (tenantCtx && !tenantCtx.isProviderAdmin) {
      // Customer roles can ONLY create accounts under their bound customerId
      effectiveCustomerId = tenantCtx.activeCustomerId || tenantCtx.accessibleCustomerIds[0];
      if (requestedCustomerId && requestedCustomerId !== effectiveCustomerId) {
        res.status(403).json({
          success: false,
          error: 'Tenant Authorization Error: You cannot connect cloud accounts to a different customer tenant.'
        });
        return;
      }
    }

    if (!effectiveCustomerId || !provider || !name || !accountOrProjectId) {
      res.status(400).json({ success: false, error: 'Missing required connection parameters (customerId, provider, name, accountOrProjectId)' });
      return;
    }

    const mode: 'DEMO' | 'LIVE' = connectionMode === 'LIVE' ? 'LIVE' : 'DEMO';
    const isDemo = mode === 'DEMO';

    logAuditEvent(req, 'GCP_ACCOUNT_CONNECT_ATTEMPT', 'CLOUD_ACCOUNT', accountOrProjectId, 'PENDING', {
      provider,
      accountOrProjectId,
      connectionMode: mode,
      targetServiceAccount: targetServiceAccount || 'default'
    });

    const newAccount: CloudAccount = {
      id: `acc-${Date.now()}`,
      customerId: effectiveCustomerId,
      customerName: dbStore.getCustomerName(effectiveCustomerId),
      provider: provider as CloudProvider,
      name,
      accountOrProjectId: accountOrProjectId.trim(),
      targetServiceAccount: targetServiceAccount ? targetServiceAccount.trim() : undefined,
      environment: environment || 'PRODUCTION',
      connectionType: connectionType || ConnectionType.WIF,
      connectionMode: mode,
      authSecretName: `projects/swedtel-hub/secrets/${accountOrProjectId.trim()}-auth`,
      status: 'SYNC_PENDING',
      lastSyncedAt: undefined,
      lastSyncStatus: 'PENDING',
      isDemo,
      resourceCount: 0,
      monthlyCost: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const adapter = CloudAdapterRegistry.getAdapter(newAccount.provider);
    const validation = await adapter.validateConnection(newAccount);

    if (!validation.isValid) {
      newAccount.status = 'AUTH_ERROR';
      newAccount.lastSyncStatus = 'FAILED';
      newAccount.lastSyncError = validation.errorMessage;

      logAuditEvent(req, 'GCP_ACCOUNT_CONNECT_FAILURE', 'CLOUD_ACCOUNT', accountOrProjectId, 'FAILURE', {
        provider: newAccount.provider,
        accountOrProjectId: newAccount.accountOrProjectId,
        errorCode: validation.errorCode,
        error: validation.errorMessage
      });

      res.status(400).json({
        success: false,
        errorCode: validation.errorCode || 'AUTHENTICATION_ERROR',
        error: validation.errorMessage,
        validation
      });
      return;
    }

    logAuditEvent(req, 'GCP_ACCOUNT_CONNECT_SUCCESS', 'CLOUD_ACCOUNT', newAccount.id, 'SUCCESS', {
      provider: newAccount.provider,
      accountOrProjectId: newAccount.accountOrProjectId,
      connectionMode: mode,
      projectDetails: validation.projectDetails
    });

    // Start Resource Synchronization
    logAuditEvent(req, 'GCP_RESOURCE_SYNC_STARTED', 'CLOUD_ACCOUNT', newAccount.id, 'PENDING', {
      accountOrProjectId: newAccount.accountOrProjectId,
      connectionMode: mode
    });

    try {
      const discovered = await adapter.discoverResources(newAccount);
      newAccount.status = 'CONNECTED';
      newAccount.lastSyncedAt = new Date().toISOString();
      newAccount.lastSyncStatus = 'SUCCESS';
      newAccount.resourceCount = discovered.length;
      newAccount.monthlyCost = discovered.reduce((sum, r) => sum + r.monthlyCost, 0);

      dbStore.cloudAccounts.push(newAccount);
      dbStore.cloudResources.push(...discovered);

      logAuditEvent(req, 'GCP_RESOURCE_SYNC_COMPLETED', 'CLOUD_ACCOUNT', newAccount.id, 'SUCCESS', {
        provider: newAccount.provider,
        accountOrProjectId: newAccount.accountOrProjectId,
        discoveredCount: discovered.length
      });

      res.status(201).json({
        success: true,
        data: newAccount,
        validation,
        discoveredResources: discovered
      });
    } catch (syncErr: any) {
      newAccount.status = 'DEGRADED';
      newAccount.lastSyncStatus = 'FAILED';
      newAccount.lastSyncError = syncErr.message;
      dbStore.cloudAccounts.push(newAccount);

      logAuditEvent(req, 'GCP_RESOURCE_SYNC_FAILED', 'CLOUD_ACCOUNT', newAccount.id, 'FAILURE', {
        error: syncErr.message
      });

      res.status(201).json({
        success: true,
        data: newAccount,
        validation,
        syncWarning: `Connected successfully, but initial resource discovery encountered an issue: ${syncErr.message}`,
        discoveredResources: []
      });
    }
  },

  async syncAccount(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const tenantCtx = req.tenantContext;

    const account = dbStore.cloudAccounts.find(a => a.id === id);
    if (!account) {
      res.status(404).json({ success: false, error: 'Cloud account not found' });
      return;
    }

    // Tenant authorization check
    if (tenantCtx && !tenantCtx.isProviderAdmin && tenantCtx.activeCustomerId !== account.customerId) {
      res.status(403).json({ success: false, error: 'Tenant Authorization Error: Cannot sync account belonging to another tenant' });
      return;
    }

    account.lastSyncStatus = 'SYNCING';
    logAuditEvent(req, 'GCP_RESOURCE_SYNC_STARTED', 'CLOUD_ACCOUNT', account.id, 'PENDING', {
      accountOrProjectId: account.accountOrProjectId,
      connectionMode: account.connectionMode
    });

    try {
      const adapter = CloudAdapterRegistry.getAdapter(account.provider);
      const discovered = await adapter.discoverResources(account);

      // Replace existing resources for this cloudAccountId with newly discovered
      dbStore.cloudResources = dbStore.cloudResources.filter(r => r.cloudAccountId !== account.id);
      dbStore.cloudResources.push(...discovered);

      account.resourceCount = discovered.length;
      account.monthlyCost = discovered.reduce((sum, r) => sum + r.monthlyCost, 0);
      account.lastSyncedAt = new Date().toISOString();
      account.lastSyncStatus = 'SUCCESS';
      account.status = 'CONNECTED';
      account.lastSyncError = undefined;

      logAuditEvent(req, 'GCP_RESOURCE_SYNC_COMPLETED', 'CLOUD_ACCOUNT', account.id, 'SUCCESS', {
        accountOrProjectId: account.accountOrProjectId,
        discoveredCount: discovered.length
      });

      res.json({
        success: true,
        data: account,
        discoveredResources: discovered
      });
    } catch (err: any) {
      account.lastSyncStatus = 'FAILED';
      account.lastSyncError = err.message;
      account.status = 'DEGRADED';

      logAuditEvent(req, 'GCP_RESOURCE_SYNC_FAILED', 'CLOUD_ACCOUNT', account.id, 'FAILURE', {
        error: err.message
      });

      res.status(500).json({
        success: false,
        error: `Synchronization failed: ${err.message}`,
        data: account
      });
    }
  },

  getResources(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let resources = dbStore.cloudResources;

    if (tenantCtx?.activeCustomerId) {
      resources = resources.filter(r => r.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      resources = resources.filter(r => tenantCtx.accessibleCustomerIds.includes(r.customerId));
    }

    const { provider, status, type, connectionMode } = req.query;
    if (provider) resources = resources.filter(r => r.provider === provider);
    if (status) resources = resources.filter(r => r.status === status);
    if (type) resources = resources.filter(r => r.resourceType === type);
    if (connectionMode) resources = resources.filter(r => r.connectionMode === connectionMode);

    res.json({ success: true, data: resources });
  }
};

// --- FINOPS CONTROLLER ---
export const FinOpsController = {
  getSummary(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let costs = dbStore.costRecords;
    let budgets = dbStore.budgets;

    if (tenantCtx?.activeCustomerId) {
      costs = costs.filter(c => c.customerId === tenantCtx.activeCustomerId);
      budgets = budgets.filter(b => b.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      costs = costs.filter(c => tenantCtx.accessibleCustomerIds.includes(c.customerId));
      budgets = budgets.filter(b => tenantCtx.accessibleCustomerIds.includes(b.customerId));
    }

    const totalSpend = costs.reduce((sum, c) => sum + Number(c.amount), 0);
    const totalBudget = budgets.reduce((sum, b) => sum + Number(b.monthlyLimit), 0);
    const anomalies = costs.filter(c => c.isAnomaly);

    const costByProvider = costs.reduce((acc, c) => {
      acc[c.provider] = (acc[c.provider] || 0) + Number(c.amount);
      return acc;
    }, {} as Record<string, number>);

    const costByService = costs.reduce((acc, c) => {
      acc[c.serviceName] = (acc[c.serviceName] || 0) + Number(c.amount);
      return acc;
    }, {} as Record<string, number>);

    res.json({
      success: true,
      data: {
        totalSpend,
        totalBudget,
        utilizationPct: totalBudget > 0 ? (totalSpend / totalBudget) * 100 : 0,
        anomaliesCount: anomalies.length,
        anomalies,
        costByProvider,
        costByService,
        budgets
      }
    });
  }
};

// --- ALERTS & SRE CONTROLLER ---
export const AlertsController = {
  getAll(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let alerts = dbStore.alerts;

    if (tenantCtx?.activeCustomerId) {
      alerts = alerts.filter(a => a.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      alerts = alerts.filter(a => tenantCtx.accessibleCustomerIds.includes(a.customerId));
    }

    res.json({ success: true, data: alerts });
  },

  resolve(req: Request, res: Response): void {
    const { id } = req.params;
    const { resolutionNotes } = req.body;

    const alert = dbStore.alerts.find(a => a.id === id);
    if (!alert) {
      res.status(404).json({ success: false, error: 'Alert not found' });
      return;
    }

    alert.status = AlertStatus.RESOLVED;
    alert.resolvedAt = new Date().toISOString();
    alert.resolvedByUserId = req.user?.userId;
    alert.resolutionNotes = resolutionNotes || 'Resolved by SRE Engineer';

    logAuditEvent(req, 'RESOLVE_ALERT', 'ALERT', alert.id, 'SUCCESS', { title: alert.title, notes: alert.resolutionNotes });
    res.json({ success: true, data: alert });
  }
};

// --- SECURITY & CIS CONTROLLER ---
export const SecurityController = {
  getFindings(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let findings = dbStore.securityFindings;

    if (tenantCtx?.activeCustomerId) {
      findings = findings.filter(f => f.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      findings = findings.filter(f => tenantCtx.accessibleCustomerIds.includes(f.customerId));
    }

    const total = findings.length;
    const openCount = findings.filter(f => f.status === 'OPEN').length;
    const criticalCount = findings.filter(f => f.severity === Severity.CRITICAL && f.status === 'OPEN').length;
    const score = total > 0 ? Math.round(((total - openCount) / total) * 100) : 100;

    res.json({
      success: true,
      data: {
        score,
        totalFindings: total,
        criticalCount,
        findings
      }
    });
  },

  remediate(req: Request, res: Response): void {
    const { id } = req.params;
    const finding = dbStore.securityFindings.find(f => f.id === id);
    if (!finding) {
      res.status(404).json({ success: false, error: 'Security finding not found' });
      return;
    }

    finding.status = 'RESOLVED';
    finding.updatedAt = new Date().toISOString();

    logAuditEvent(req, 'REMEDIATE_SECURITY_FINDING', 'SECURITY_FINDING', finding.id, 'SUCCESS', {
      title: finding.title,
      cisControlId: finding.cisControlId
    });

    res.json({ success: true, data: finding, message: 'Finding successfully remediated.' });
  }
};

// --- AUTOMATION CONTROLLER ---
export const AutomationController = {
  getWorkflows(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let workflows = dbStore.workflows;

    if (tenantCtx?.activeCustomerId) {
      workflows = workflows.filter(w => w.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      workflows = workflows.filter(w => tenantCtx.accessibleCustomerIds.includes(w.customerId));
    }

    res.json({
      success: true,
      data: {
        workflows,
        executions: dbStore.executions
      }
    });
  },

  async triggerExecution(req: Request, res: Response): Promise<void> {
    const { id } = req.params;
    const workflow = dbStore.workflows.find(w => w.id === id);
    if (!workflow) {
      res.status(404).json({ success: false, error: 'Workflow not found' });
      return;
    }

    const execution: AutomationExecution = {
      id: `exec-${Date.now()}`,
      workflowId: workflow.id,
      workflowName: workflow.name,
      customerId: workflow.customerId,
      triggeredBy: `USER (${req.user?.email})`,
      status: 'COMPLETED',
      startedAt: new Date().toISOString(),
      finishedAt: new Date().toISOString(),
      durationMs: 8500,
      executionLog: `Executed ${workflow.actionType} successfully on target provider ${workflow.targetProvider}. Safe orchestration completed.`,
      approvedByUserId: req.user?.userId
    };

    dbStore.executions.unshift(execution);
    logAuditEvent(req, 'TRIGGER_AUTOMATION_WORKFLOW', 'AUTOMATION_WORKFLOW', workflow.id, 'SUCCESS', {
      actionType: workflow.actionType,
      executionId: execution.id
    });

    res.json({ success: true, data: execution });
  }
};

// --- TICKETS CONTROLLER ---
export const TicketController = {
  getAll(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let tickets = dbStore.tickets;

    if (tenantCtx?.activeCustomerId) {
      tickets = tickets.filter(t => t.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      tickets = tickets.filter(t => tenantCtx.accessibleCustomerIds.includes(t.customerId));
    }

    // Attach messages with internal note visibility filter
    const isInternalStaff = req.user?.organizationType === 'PROVIDER';
    const ticketsWithMessages = tickets.map(t => ({
      ...t,
      messages: dbStore.ticketMessages
        .filter(m => m.ticketId === t.id)
        .filter(m => !m.isInternalNote || isInternalStaff)
    }));

    res.json({ success: true, data: ticketsWithMessages });
  },

  create(req: Request, res: Response): void {
    const { customerId, title, description, category, priority } = req.body;
    const targetCustId = customerId || req.user?.customerId;

    if (!targetCustId || !title || !description) {
      res.status(400).json({ success: false, error: 'Missing customerId, title, or description' });
      return;
    }

    const newTicket: SupportTicket = {
      id: `tkt-${Date.now()}`,
      ticketNumber: `SWED-${Math.floor(1000 + Math.random() * 9000)}`,
      customerId: targetCustId,
      customerName: dbStore.getCustomerName(targetCustId),
      createdByUserId: req.user?.userId || 'unknown',
      createdByName: `${req.user?.firstName || ''} ${req.user?.lastName || ''}`.trim() || req.user?.email || 'User',
      title,
      description,
      category: category || 'INFRASTRUCTURE',
      priority: priority || TicketPriority.P3_MEDIUM,
      status: TicketStatus.OPEN,
      slaDueAt: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    dbStore.tickets.unshift(newTicket);
    logAuditEvent(req, 'CREATE_SUPPORT_TICKET', 'SUPPORT_TICKET', newTicket.id, 'SUCCESS', {
      ticketNumber: newTicket.ticketNumber,
      priority: newTicket.priority
    });

    res.status(201).json({ success: true, data: newTicket });
  },

  addMessage(req: Request, res: Response): void {
    const { id } = req.params;
    const { message, isInternalNote } = req.body;

    const ticket = dbStore.tickets.find(t => t.id === id);
    if (!ticket) {
      res.status(404).json({ success: false, error: 'Ticket not found' });
      return;
    }

    // Only provider staff can create internal notes
    const isNote = isInternalNote && req.user?.organizationType === 'PROVIDER';

    const newMessage: TicketMessage = {
      id: `msg-${Date.now()}`,
      ticketId: ticket.id,
      senderUserId: req.user?.userId || 'unknown',
      senderName: `${req.user?.firstName || ''} ${req.user?.lastName || ''}`.trim() || req.user?.email || 'Support Staff',
      message,
      isInternalNote: !!isNote,
      attachments: [],
      createdAt: new Date().toISOString()
    };

    dbStore.ticketMessages.push(newMessage);
    ticket.updatedAt = new Date().toISOString();

    logAuditEvent(req, 'ADD_TICKET_MESSAGE', 'SUPPORT_TICKET', ticket.id, 'SUCCESS', { isInternalNote: newMessage.isInternalNote });
    res.status(201).json({ success: true, data: newMessage });
  }
};

// --- REPORTS CONTROLLER ---
export const ReportController = {
  getAll(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let reports = dbStore.reports;

    if (tenantCtx?.activeCustomerId) {
      reports = reports.filter(r => r.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      reports = reports.filter(r => tenantCtx.accessibleCustomerIds.includes(r.customerId));
    }

    res.json({ success: true, data: reports });
  },

  generate(req: Request, res: Response): void {
    const { customerId, title, type, periodStart, periodEnd } = req.body;
    const targetCustId = customerId || req.user?.customerId;

    const newReport: Report = {
      id: `rep-${Date.now()}`,
      customerId: targetCustId,
      customerName: dbStore.getCustomerName(targetCustId),
      title: title || `Executive ${type} Report`,
      type: type || 'FINOPS_MONTHLY',
      periodStart: periodStart || '2026-08-01',
      periodEnd: periodEnd || '2026-08-31',
      generatedByUserId: req.user?.userId,
      fileUrl: `https://storage.googleapis.com/swedtel-reports-prod/report_${Date.now()}.pdf`,
      summaryData: { generatedAt: new Date().toISOString(), status: 'READY', generatedBy: req.user?.email },
      createdAt: new Date().toISOString()
    };

    dbStore.reports.unshift(newReport);
    logAuditEvent(req, 'GENERATE_REPORT', 'REPORT', newReport.id, 'SUCCESS', { type: newReport.type });

    res.status(201).json({ success: true, data: newReport });
  }
};

// --- AUDIT LOGS CONTROLLER ---
export const AuditController = {
  getAll(req: Request, res: Response): void {
    const tenantCtx = req.tenantContext;
    let logs = dbStore.auditLogs;

    if (tenantCtx?.activeCustomerId) {
      logs = logs.filter(l => l.customerId === tenantCtx.activeCustomerId);
    } else if (tenantCtx && !tenantCtx.isProviderAdmin) {
      logs = logs.filter(l => tenantCtx.accessibleCustomerIds.includes(l.customerId || ''));
    }

    res.json({ success: true, data: logs });
  }
};

// --- GEMINI AI CONTROLLER ---
export const AIController = {
  async consult(req: Request, res: Response): Promise<void> {
    const { prompt, contextType, customerId, incidentDetails } = req.body;

    const targetCust = customerId ? dbStore.customers.find(c => c.id === customerId) : undefined;
    const customerContext = targetCust ? {
      customerId: targetCust.id,
      customerName: targetCust.name,
      monthlySpend: targetCust.monthlySpend || 0,
      monthlyBudget: targetCust.monthlyBudget || 0,
      resourceCount: targetCust.resourcesCount || 0
    } : undefined;

    const result = await GeminiServerAdvisor.consultAdvisor({
      prompt: prompt || 'Provide cloud architecture guidance.',
      contextType: contextType || 'FINOPS',
      customerContext,
      incidentDetails
    });

    logAuditEvent(req, 'AI_ADVISOR_CONSULTATION', 'GEMINI_AI', contextType, 'SUCCESS', {
      modelUsed: result.modelUsed,
      durationMs: result.executionDurationMs,
      isFallback: result.isFallback
    });

    res.json({ success: true, data: result });
  }
};
