// ====================================================================
// SWEDTEL Cloud Management Platform - REST API Route Definitions
// ====================================================================

import { Router } from 'express';
import {
  AuthController,
  CustomerController,
  CloudController,
  FinOpsController,
  AlertsController,
  SecurityController,
  AutomationController,
  TicketController,
  ReportController,
  AuditController,
  AIController
} from '../controllers/allControllers.js';
import { requireRole } from '../middleware/rbac.js';
import { authenticate } from '../middleware/auth.js';
import { enforceTenantContext } from '../middleware/tenant.js';
import { UserRole } from '../types/index.js';

export const apiRouter = Router();

// Public Health Check Probe
apiRouter.get('/health', (req, res) => {
  res.json({
    status: 'HEALTHY',
    service: 'swedtel-cloud-platform-api',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// 1. Identity & Authentication Resolver
apiRouter.use(authenticate);

// Public Identity Switcher
apiRouter.post('/auth/dev-switch-role', AuthController.switchDevRole);

// 2. Multi-Tenant Context Resolver across all protected routes
apiRouter.use(enforceTenantContext);

// Session Endpoints
apiRouter.get('/auth/me', AuthController.getCurrentUser);
apiRouter.post('/auth/logout', AuthController.logout);

// 2. Customers
apiRouter.get('/customers', CustomerController.getAll);
apiRouter.get('/customers/:id', CustomerController.getById);
apiRouter.post('/customers', requireRole(UserRole.SUPER_ADMIN, UserRole.ACCOUNT_MANAGER), CustomerController.create);

// 3. Cloud Accounts & Resources
apiRouter.get('/cloud/accounts', CloudController.getAccounts);
apiRouter.post('/cloud/accounts/validate-and-connect', requireRole(UserRole.SUPER_ADMIN, UserRole.CLOUD_ENGINEER, UserRole.CUSTOMER_ADMIN), CloudController.validateAndConnect);
apiRouter.post('/cloud/accounts/:id/sync', requireRole(UserRole.SUPER_ADMIN, UserRole.CLOUD_ENGINEER, UserRole.CUSTOMER_ADMIN), CloudController.syncAccount);
apiRouter.get('/cloud/resources', CloudController.getResources);

// 4. FinOps & Costs
apiRouter.get('/finops/summary', FinOpsController.getSummary);

// 5. Monitoring & Alerts
apiRouter.get('/alerts', AlertsController.getAll);
apiRouter.post('/alerts/:id/resolve', requireRole(UserRole.SUPER_ADMIN, UserRole.CLOUD_ENGINEER, UserRole.CUSTOMER_ADMIN), AlertsController.resolve);

// 6. Security & CIS Compliance
apiRouter.get('/security/findings', SecurityController.getFindings);
apiRouter.post('/security/findings/:id/remediate', requireRole(UserRole.SUPER_ADMIN, UserRole.CLOUD_ENGINEER, UserRole.CUSTOMER_ADMIN), SecurityController.remediate);

// 7. Automation & Governance
apiRouter.get('/automation/workflows', AutomationController.getWorkflows);
apiRouter.post('/automation/workflows/:id/execute', requireRole(UserRole.SUPER_ADMIN, UserRole.CLOUD_ENGINEER), AutomationController.triggerExecution);

// 8. Support Helpdesk
apiRouter.get('/tickets', TicketController.getAll);
apiRouter.post('/tickets', TicketController.create);
apiRouter.post('/tickets/:id/messages', TicketController.addMessage);

// 9. Reports
apiRouter.get('/reports', ReportController.getAll);
apiRouter.post('/reports/generate', requireRole(UserRole.SUPER_ADMIN, UserRole.FINOPS_SPECIALIST, UserRole.ACCOUNT_MANAGER, UserRole.CUSTOMER_ADMIN), ReportController.generate);

// 10. Audit Logs (Restricted)
apiRouter.get('/audit/logs', requireRole(UserRole.SUPER_ADMIN, UserRole.CLOUD_ENGINEER, UserRole.CUSTOMER_ADMIN), AuditController.getAll);

// 11. Server-Side Gemini AI Advisor
apiRouter.post('/ai/consult', AIController.consult);
