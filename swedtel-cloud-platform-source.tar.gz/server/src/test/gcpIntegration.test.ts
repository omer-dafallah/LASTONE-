// ====================================================================
// SWEDTEL Cloud Management Platform - GCP Integration Test Suite
// Validates:
// 1. GcpClientFactory authentication & error classification
// 2. GoogleCloudProvider validation (Demo vs Live)
// 3. Multi-service discovery mapping (Compute, Storage, GKE, SQL)
// 4. Safe read-only execution guard
// 5. Tenant context isolation
// ====================================================================

import { describe, it } from 'node:test';
import assert from 'node:assert';
import { GcpClientFactory } from '../cloud/gcp/GcpClientFactory.js';
import { GoogleCloudProvider } from '../cloud/GoogleCloudProvider.js';
import { CloudAccount, CloudProvider, ConnectionType, ResourceStatus, ResourceType } from '../types/index.js';

describe('Google Cloud Integration & Security Architecture', () => {

  describe('1. GcpClientFactory Error Classification', () => {
    it('should classify 403 PERMISSION_DENIED correctly', () => {
      const err = {
        code: 403,
        message: 'The caller does not have permission to access project nordic-health-prod'
      };
      const result = GcpClientFactory.classifyGcpError(err, 'Resource Manager Test');
      assert.strictEqual(result.code, 'PERMISSION_ERROR');
      assert.match(result.message, /\[PERMISSION_ERROR\]/);
    });

    it('should classify SERVICE_DISABLED as API_NOT_ENABLED', () => {
      const err = {
        code: 403,
        message: 'Compute Engine API has not been used in project 123456 before or it is disabled. Enable it by visiting https://console.developers.google.com'
      };
      const result = GcpClientFactory.classifyGcpError(err, 'Compute API Test');
      assert.strictEqual(result.code, 'API_NOT_ENABLED');
      assert.match(result.message, /\[API_NOT_ENABLED\]/);
    });

    it('should classify 404 NOT_FOUND as PROJECT_NOT_FOUND', () => {
      const err = {
        code: 404,
        message: 'Project non-existent-gcp-project was not found'
      };
      const result = GcpClientFactory.classifyGcpError(err, 'Project Test');
      assert.strictEqual(result.code, 'PROJECT_NOT_FOUND');
      assert.match(result.message, /\[PROJECT_NOT_FOUND\]/);
    });

    it('should classify Service Account Impersonation failures', () => {
      const err = {
        message: 'Unable to impersonate: iam.serviceAccounts.generateAccessToken returned 403'
      };
      const result = GcpClientFactory.classifyGcpError(err, 'Impersonation Test');
      assert.strictEqual(result.code, 'IMPERSONATION_ERROR');
      assert.match(result.message, /\[IMPERSONATION_ERROR\]/);
    });

    it('should classify transient network connectivity errors', () => {
      const err = {
        code: 'ENOTFOUND',
        message: 'getaddrinfo ENOTFOUND cloudresourcemanager.googleapis.com'
      };
      const result = GcpClientFactory.classifyGcpError(err, 'Network Test');
      assert.strictEqual(result.code, 'NETWORK_ERROR');
      assert.match(result.message, /\[NETWORK_ERROR\]/);
    });
  });

  describe('2. GoogleCloudProvider - Connection Validation', () => {
    const provider = new GoogleCloudProvider();

    it('should reject invalid GCP project ID naming conventions', async () => {
      const invalidAccount: CloudAccount = {
        id: 'acc-test-01',
        customerId: 'cust-nordic-001',
        provider: CloudProvider.GCP,
        name: 'Invalid GCP',
        accountOrProjectId: 'INVALID_PROJECT_NAME!',
        environment: 'PRODUCTION',
        connectionType: ConnectionType.WIF,
        connectionMode: 'DEMO',
        status: 'SYNC_PENDING',
        isDemo: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const result = await provider.validateConnection(invalidAccount);
      assert.strictEqual(result.isValid, false);
      assert.strictEqual(result.errorCode, 'INVALID_CONFIG');
      assert.ok(result.errorMessage && /Invalid Google Cloud Project ID format/.test(result.errorMessage));
    });

    it('should validate DEMO MODE account deterministically', async () => {
      const demoAccount: CloudAccount = {
        id: 'acc-test-02',
        customerId: 'cust-nordic-001',
        provider: CloudProvider.GCP,
        name: 'Demo Nordic Health GCP',
        accountOrProjectId: 'nordic-health-prod-5849',
        environment: 'PRODUCTION',
        connectionType: ConnectionType.WIF,
        connectionMode: 'DEMO',
        status: 'CONNECTED',
        isDemo: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const result = await provider.validateConnection(demoAccount);
      assert.strictEqual(result.isValid, true);
      assert.strictEqual(result.provider, CloudProvider.GCP);
      assert.strictEqual(result.accountOrProjectId, 'nordic-health-prod-5849');
      assert.ok(result.detectedPermissions.includes('roles/viewer'));
      assert.ok(result.detectedPermissions.includes('roles/compute.viewer'));
      assert.ok(result.detectedPermissions.includes('roles/container.viewer'));
      assert.strictEqual(result.projectDetails?.state, 'ACTIVE');
    });
  });

  describe('3. GoogleCloudProvider - Resource Discovery & Cost Tracking', () => {
    const provider = new GoogleCloudProvider();

    it('should discover resources with correct typed schema in DEMO mode', async () => {
      const account: CloudAccount = {
        id: 'acc-test-03',
        customerId: 'cust-nordic-001',
        customerName: 'Nordic Health Solutions AB',
        provider: CloudProvider.GCP,
        name: 'Nordic Health GCP',
        accountOrProjectId: 'nordic-health-prod-5849',
        environment: 'PRODUCTION',
        connectionType: ConnectionType.WIF,
        connectionMode: 'DEMO',
        status: 'CONNECTED',
        isDemo: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const resources = await provider.discoverResources(account);
      assert.ok(Array.isArray(resources));
      assert.ok(resources.length >= 2);

      const gke = resources.find(r => r.resourceType === ResourceType.KUBERNETES_CLUSTER);
      assert.ok(gke);
      assert.strictEqual(gke?.provider, CloudProvider.GCP);
      assert.strictEqual(gke?.status, ResourceStatus.HEALTHY);
      assert.strictEqual(gke?.region, 'europe-north1');
      assert.ok((gke?.monthlyCost ?? 0) > 0);
      assert.strictEqual(gke?.isDemo, true);

      const db = resources.find(r => r.resourceType === ResourceType.MANAGED_DATABASE);
      assert.ok(db);
      assert.strictEqual(db?.provider, CloudProvider.GCP);
      assert.strictEqual(db?.status, ResourceStatus.HEALTHY);
    });

    it('should return live telemetry metrics structure', async () => {
      const account: CloudAccount = {
        id: 'acc-test-04',
        customerId: 'cust-nordic-001',
        provider: CloudProvider.GCP,
        name: 'Nordic Health GCP',
        accountOrProjectId: 'nordic-health-prod-5849',
        environment: 'PRODUCTION',
        connectionType: ConnectionType.WIF,
        connectionMode: 'DEMO',
        status: 'CONNECTED',
        isDemo: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const telemetry = await provider.fetchResourceTelemetry(account, 'gke-nordic-prod');
      assert.ok(telemetry.timestamp);
      assert.ok(typeof telemetry.cpuPct === 'number');
      assert.ok(typeof telemetry.memoryPct === 'number');
      assert.ok(typeof telemetry.networkInMbps === 'number');
    });

    it('should query cost records with correct multi-cloud currency standards', async () => {
      const account: CloudAccount = {
        id: 'acc-test-05',
        customerId: 'cust-nordic-001',
        provider: CloudProvider.GCP,
        name: 'Nordic Health GCP',
        accountOrProjectId: 'nordic-health-prod-5849',
        environment: 'PRODUCTION',
        connectionType: ConnectionType.WIF,
        connectionMode: 'DEMO',
        status: 'CONNECTED',
        isDemo: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const costs = await provider.fetchCostRecords(account, '2026-09-01', '2026-09-02');
      assert.ok(costs.length > 0);
      assert.strictEqual(costs[0].currency, 'EUR');
      assert.strictEqual(costs[0].provider, CloudProvider.GCP);
    });
  });

  describe('4. Safe Execution Guard (Read-Only Policy)', () => {
    const provider = new GoogleCloudProvider();

    it('should enforce read-only safety guard on LIVE projects', async () => {
      const liveAccount: CloudAccount = {
        id: 'acc-live-01',
        customerId: 'cust-nordic-001',
        provider: CloudProvider.GCP,
        name: 'Live Target Project',
        accountOrProjectId: 'live-prod-enterprise-8890',
        environment: 'PRODUCTION',
        connectionType: ConnectionType.WIF,
        connectionMode: 'LIVE',
        status: 'CONNECTED',
        isDemo: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const result = await provider.executeAutomationAction(liveAccount, 'RESTART_VM', { vmName: 'core-api-node-01' });
      assert.strictEqual(result.success, true);
      assert.match(result.log, /READ-ONLY SECURITY GUARD/);
      assert.match(result.log, /forbids destructive mutations/);
    });
  });
});
