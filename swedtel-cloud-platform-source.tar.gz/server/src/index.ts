// ====================================================================
// SWEDTEL Cloud Management Platform - Enterprise SaaS Backend API
// Main Server Entry Point
// ====================================================================

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { config } from './config/index.js';
import { initDatabase } from './db/index.js';
import { authenticate } from './middleware/auth.js';
import { apiRouter } from './routes/api.js';

const app = express();

// 1. Security & Standard Middlewares
app.use(helmet({
  contentSecurityPolicy: false, // Allows flexible integration in containerized sandboxes
  crossOriginEmbedderPolicy: false
}));
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-swedtel-impersonate-role', 'x-swedtel-tenant-id']
}));
app.use(express.json({ limit: '10mb' }));
app.use(morgan('combined'));

// 2. Health & Telemetry Probes (GCP Cloud Run Ready)
app.get('/healthz', (req: Request, res: Response) => {
  res.json({
    status: 'HEALTHY',
    service: 'swedtel-cloud-platform-api',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    env: config.env
  });
});

app.get('/readyz', (req: Request, res: Response) => {
  res.json({
    status: 'READY',
    db: 'READY',
    secretManager: 'CONNECTED',
    geminiAi: config.gemini.apiKey ? 'KEY_PROVISIONED' : 'FALLBACK_MODE'
  });
});

// 3. API Mount with Authentication
app.use('/api/v1', authenticate, apiRouter);

// 4. Global Error Handler
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('[UNHANDLED ERROR]', err);
  res.status(500).json({
    success: false,
    error: 'INTERNAL_SERVER_ERROR',
    message: err.message || 'An unexpected internal error occurred.',
    timestamp: new Date().toISOString()
  });
});

// 5. Server Initialization
async function startServer() {
  await initDatabase();
  app.listen(config.port, '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(`🚀 SWEDTEL Cloud Management Platform API running on port ${config.port}`);
    console.log(`🌐 Health Probe: http://0.0.0.0:${config.port}/healthz`);
    console.log(`🔒 Environment: ${config.env}`);
    console.log(`⚡ Multi-Tenancy: Server-Side Enforced`);
    console.log(`=======================================================`);
  });
}

startServer();
