// ====================================================================
// SWEDTEL Cloud Management Platform - Comprehensive Automated Test Suite
// Verifies: Endpoints, Auth, RBAC, Multi-Tenant Boundaries, FinOps,
// SRE Alerts, Automation, Tickets, Audit Logs, Gemini Engine, SQL Syntax.
// ====================================================================

import http from 'http';
import fs from 'fs';
import path from 'path';
import express from 'express';
import cors from 'cors';
import { apiRouter } from './routes/api.js';

interface TestResult {
  category: string;
  name: string;
  passed: boolean;
  error?: string;
  details?: any;
}

const results: TestResult[] = [];

function recordTest(category: string, name: string, passed: boolean, error?: string, details?: any) {
  results.push({ category, name, passed, error, details });
  const statusStr = passed ? '✅ PASS' : '❌ FAIL';
  console.log(`${statusStr} [${category}] ${name}${error ? ` -> ${error}` : ''}`);
}

async function runAllVerificationTests() {
  console.log('\n======================================================');
  console.log('🚀 RUNNING COMPREHENSIVE PLATFORM VERIFICATION TEST SUITE');
  console.log('======================================================\n');

  // --- 1. SQL MIGRATIONS SYNTAX & DDL VERIFICATION ---
  try {
    const migrationDir = path.resolve(process.cwd(), 'migrations');
    const schemaFile = path.join(migrationDir, '001_initial_schema.sql');
    const seedFile = path.join(migrationDir, '002_seed_data.sql');

    if (!fs.existsSync(schemaFile) || !fs.existsSync(seedFile)) {
      throw new Error(`Migration SQL files missing at ${migrationDir}`);
    }

    const schemaSql = fs.readFileSync(schemaFile, 'utf8');
    const seedSql = fs.readFileSync(seedFile, 'utf8');

    const expectedTables = [
      'organizations',
      'customers',
      'users',
      'cloud_accounts',
      'cloud_resources',
      'cost_records',
      'budgets',
      'alerts',
      'security_findings',
      'automation_workflows',
      'automation_executions',
      'support_tickets',
      'ticket_messages',
      'reports',
      'audit_logs'
    ];

    let missingTables: string[] = [];
    for (const table of expectedTables) {
      if (!schemaSql.includes(`CREATE TABLE IF NOT EXISTS ${table}`) && !schemaSql.includes(`CREATE TABLE ${table}`)) {
        missingTables.push(table);
      }
    }

    if (missingTables.length > 0) {
      recordTest('Database DDL', 'Verify Relational Schema Tables', false, `Missing tables: ${missingTables.join(', ')}`);
    } else {
      recordTest('Database DDL', 'Verify Relational Schema Tables', true, undefined, { tableCount: expectedTables.length });
    }

    // Verify Seeds SQL
    const hasSeedInserts = seedSql.includes('INSERT INTO organizations') && seedSql.includes('INSERT INTO customers') && seedSql.includes('INSERT INTO cloud_accounts');
    recordTest('Database Seeds', 'Verify Seed DDL & Multi-Tenant Entities', hasSeedInserts, hasSeedInserts ? undefined : 'Seed data missing initial inserts');
  } catch (err: any) {
    recordTest('Database Migrations', 'SQL Parsing', false, err.message);
  }

  // --- 2. SPIN UP EXPRESS APP INSTANCE FOR API TESTING ---
  const app = express();
  app.use(cors());
  app.use(express.json());
  app.use('/api', apiRouter);

  const server = http.createServer(app);
  const TEST_PORT = 4099;

  await new Promise<void>((resolve) => {
    server.listen(TEST_PORT, () => resolve());
  });

  const BASE = `http://127.0.0.1:${TEST_PORT}/api`;

  async function apiCall(endpoint: string, options: { method?: string; headers?: Record<string, string>; body?: any } = {}) {
    const res = await fetch(`${BASE}${endpoint}`, {
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      },
      body: options.body ? JSON.stringify(options.body) : undefined
    });
    const json: any = await res.json().catch(() => ({}));
    return { status: res.status, ok: res.ok, data: json };
  }

  try {
    // 3. HEALTH CHECK
    const health = await apiCall('/health');
    recordTest('System Health', 'GET /api/health', health.status === 200 && health.data.status === 'HEALTHY', health.ok ? undefined : `Status ${health.status}`);

    // 4. AUTHENTICATION - Dev Role Switching & Tokens
    const rolesToTest = [
      { key: 'SUPER_ADMIN', expectedOrg: 'PROVIDER', expectedRole: 'SUPER_ADMIN' },
      { key: 'CLOUD_ENGINEER', expectedOrg: 'PROVIDER', expectedRole: 'CLOUD_ENGINEER' },
      { key: 'FINOPS_LEAD', expectedOrg: 'PROVIDER', expectedRole: 'FINOPS_SPECIALIST' },
      { key: 'CUSTOMER_NORDIC_HEALTH_ADMIN', expectedOrg: 'CUSTOMER', expectedRole: 'CUSTOMER_ADMIN', customerId: 'cust-nordic-health-001' },
      { key: 'CUSTOMER_SCANIA_ADMIN', expectedOrg: 'CUSTOMER', expectedRole: 'CUSTOMER_ADMIN', customerId: 'cust-sthlm-fin-002' }
    ];

    const tokens: Record<string, string> = {};

    for (const r of rolesToTest) {
      const authRes = await apiCall('/auth/dev-switch-role', {
        method: 'POST',
        body: { roleKey: r.key }
      });
      const valid = authRes.status === 200 && authRes.data.data?.token && authRes.data.data?.user?.role === r.expectedRole;
      if (valid) {
        tokens[r.key] = authRes.data.data.token;
      }
      recordTest('Authentication', `Switch to role ${r.key}`, valid, valid ? undefined : `Failed: status=${authRes.status}`);
    }

    const superAdminToken = tokens['SUPER_ADMIN'];
    const engineerToken = tokens['CLOUD_ENGINEER'];
    const finopsToken = tokens['FINOPS_LEAD'];
    const nordicHealthToken = tokens['CUSTOMER_NORDIC_HEALTH_ADMIN'];

    // 5. CURRENT USER VERIFICATION
    const meRes = await apiCall('/auth/me', {
      headers: { Authorization: `Bearer ${superAdminToken}` }
    });
    recordTest('Authentication', 'GET /api/auth/me with Bearer token', meRes.status === 200 && meRes.data.data?.email === 'lars.lindqvist@swedtel.se');

    // 6. CUSTOMER CRUD
    const getCustomersRes = await apiCall('/customers', {
      headers: { Authorization: `Bearer ${superAdminToken}` }
    });
    const customersCount = getCustomersRes.data.data?.length || 0;
    recordTest('Customer Management', 'GET /api/customers (Provider Role)', getCustomersRes.status === 200 && customersCount >= 2);

    const createCustomerRes = await apiCall('/customers', {
      method: 'POST',
      headers: { Authorization: `Bearer ${superAdminToken}` },
      body: {
        name: 'Volvo Group Telematics',
        code: 'VOLVO_TELEMATICS',
        industry: 'Automotive & Logistics',
        contactEmail: 'cloud-infra@volvo.se',
        tier: 'ENTERPRISE',
        monthlyBudget: 150000
      }
    });
    recordTest('Customer Management', 'POST /api/customers (Create new customer)', createCustomerRes.status === 201 && createCustomerRes.data.data?.name === 'Volvo Group Telematics');

    // 7. MULTI-TENANT ISOLATION TESTS
    // Test A: Customer cannot see all customers
    const custGetOtherCusts = await apiCall('/customers', {
      headers: { Authorization: `Bearer ${nordicHealthToken}` }
    });
    const tenantIsProtected = custGetOtherCusts.status === 200 && custGetOtherCusts.data.data?.length === 1 && custGetOtherCusts.data.data[0].id === 'cust-nordic-health-001';
    recordTest('Tenant Isolation', 'Customer token only sees own tenant record in /api/customers', tenantIsProtected);

    // Test B: Cross-tenant header spoofing rejection or automatic override
    const custSpoofRes = await apiCall('/cloud/resources', {
      headers: {
        Authorization: `Bearer ${nordicHealthToken}`,
        'x-customer-id': 'cust-sthlm-fin-002' // Attempting to spoof another tenant!
      }
    });
    const spoofPrevented = custSpoofRes.status === 200 && custSpoofRes.data.data.every((r: any) => r.customerId === 'cust-nordic-health-001');
    recordTest('Tenant Isolation', 'Spoofed x-customer-id header safely overridden by server-side JWT tenant context', spoofPrevented);

    // 8. CLOUD ACCOUNTS
    const cloudAccountsRes = await apiCall('/cloud/accounts', {
      headers: { Authorization: `Bearer ${superAdminToken}` }
    });
    recordTest('Cloud Accounts', 'GET /api/cloud/accounts', cloudAccountsRes.status === 200 && cloudAccountsRes.data.data?.length > 0);

    const connectAccountRes = await apiCall('/cloud/accounts/validate-and-connect', {
      method: 'POST',
      headers: { Authorization: `Bearer ${superAdminToken}` },
      body: {
        customerId: 'cust-nordic-health-001',
        provider: 'GCP',
        name: 'Nordic Health EU-North DR Project',
        accountOrProjectId: 'nordic-health-dr-9920',
        environment: 'DR',
        connectionType: 'WIF',
        authSecretName: 'projects/swedtel-hub/secrets/nordic-gcp-wif'
      }
    });
    recordTest('Cloud Accounts', 'POST /api/cloud/accounts/validate-and-connect (WIF GCP Account)', connectAccountRes.status === 201 && connectAccountRes.data.data?.status === 'CONNECTED');

    // 9. CLOUD RESOURCES & TELEMETRY
    const resourcesRes = await apiCall('/cloud/resources', {
      headers: { Authorization: `Bearer ${superAdminToken}` }
    });
    recordTest('Infrastructure & Telemetry', 'GET /api/cloud/resources (Telemetry Stream)', resourcesRes.status === 200 && resourcesRes.data.data?.length > 0);

    // 10. FINOPS COST DASHBOARD
    const finOpsRes = await apiCall('/finops/summary', {
      headers: { Authorization: `Bearer ${finopsToken}` }
    });
    recordTest('FinOps Intelligence', 'GET /api/finops/summary (Spend, CUD, Anomalies)', finOpsRes.status === 200 && finOpsRes.data.data?.totalSpend > 0);

    // 11. ALERTS & SRE INCIDENTS
    const alertsRes = await apiCall('/alerts', {
      headers: { Authorization: `Bearer ${engineerToken}` }
    });
    recordTest('Incident Management', 'GET /api/alerts', alertsRes.status === 200 && alertsRes.data.data?.length > 0);

    if (alertsRes.data.data?.length > 0) {
      const openAlert = alertsRes.data.data[0];
      const resolveRes = await apiCall(`/alerts/${openAlert.id}/resolve`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${engineerToken}` },
        body: { resolutionNotes: 'Auto-scaled Kubernetes pod replicas to handle load spike' }
      });
      recordTest('Incident Management', `POST /api/alerts/${openAlert.id}/resolve`, resolveRes.status === 200 && resolveRes.data.data?.status === 'RESOLVED');
    }

    // 12. AUTOMATION & TWO-MAN RULE RUNBOOKS
    const wfRes = await apiCall('/automation/workflows', {
      headers: { Authorization: `Bearer ${engineerToken}` }
    });
    recordTest('Automation', 'GET /api/automation/workflows', wfRes.status === 200 && wfRes.data.data?.workflows?.length > 0);

    if (wfRes.data.data?.workflows?.length > 0) {
      const wf = wfRes.data.data.workflows[0];
      const execRes = await apiCall(`/automation/workflows/${wf.id}/execute`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${engineerToken}` }
      });
      recordTest('Automation', `POST /api/automation/workflows/${wf.id}/execute (Trigger runbook)`, execRes.status === 200 && execRes.data.data?.status === 'COMPLETED');
    }

    // 13. SUPPORT TICKETS & PRIVATE INTERNAL NOTES
    const ticketsRes = await apiCall('/tickets', {
      headers: { Authorization: `Bearer ${superAdminToken}` }
    });
    recordTest('Support Desk', 'GET /api/tickets', ticketsRes.status === 200 && ticketsRes.data.data?.length > 0);

    const targetTicket = ticketsRes.data.data[0];
    // Add Internal note from Provider
    const addNoteRes = await apiCall(`/tickets/${targetTicket.id}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${engineerToken}` },
      body: { message: 'Internal diagnostic note: Investigating memory leak on node-3.', isInternalNote: true }
    });
    recordTest('Support Desk', 'POST /api/tickets/:id/messages (Internal note by engineer)', addNoteRes.status === 201 && addNoteRes.data.data?.isInternalNote === true);

    // Verify Customer cannot see internal notes
    const custTicketRes = await apiCall('/tickets', {
      headers: { Authorization: `Bearer ${nordicHealthToken}` }
    });
    const customerView = custTicketRes.data.data?.find((t: any) => t.id === targetTicket.id);
    const hasLeakedInternalNote = customerView?.messages?.some((m: any) => m.isInternalNote === true);
    recordTest('Security & Isolation', 'Internal engineering notes hidden from customer tenant view', hasLeakedInternalNote === false);

    // 14. EXECUTIVE REPORTS
    const reportsRes = await apiCall('/reports', {
      headers: { Authorization: `Bearer ${superAdminToken}` }
    });
    recordTest('Reports', 'GET /api/reports', reportsRes.status === 200 && reportsRes.data.data?.length > 0);

    const genReportRes = await apiCall('/reports/generate', {
      method: 'POST',
      headers: { Authorization: `Bearer ${superAdminToken}` },
      body: {
        customerId: 'cust-nordic-health-001',
        type: 'CIS_SECURITY',
        title: 'Q3 Automated CIS Benchmark Compliance Audit'
      }
    });
    recordTest('Reports', 'POST /api/reports/generate (Generate report)', genReportRes.status === 201 && genReportRes.data.data?.summaryData?.status === 'READY');

    // 15. SOC 2 AUDIT TRAIL
    const auditRes = await apiCall('/audit/logs', {
      headers: { Authorization: `Bearer ${superAdminToken}` }
    });
    recordTest('SOC 2 Audit Trail', 'GET /api/audit/logs (Audit entries logged for all operations)', auditRes.status === 200 && auditRes.data.data?.length > 0);

    // 16. GEMINI SERVER ADVISOR
    const geminiRes = await apiCall('/ai/consult', {
      method: 'POST',
      headers: { Authorization: `Bearer ${superAdminToken}` },
      body: {
        prompt: 'Analyze current GKE resource utilization and suggest cost optimization roadmap.',
        contextType: 'FINOPS',
        customerId: 'cust-nordic-health-001'
      }
    });
    const geminiValid = geminiRes.status === 200 && geminiRes.data.data?.markdownResponse?.length > 50;
    recordTest('Gemini AI Engine', 'POST /api/ai/consult (Autonomous server-side advisory & fallback)', geminiValid, geminiValid ? undefined : 'Gemini response empty');
  } finally {
    server.close();
  }

  // --- PRINT SUMMARY ---
  console.log('\n======================================================');
  console.log('📊 TEST EXECUTION SUMMARY:');
  const total = results.length;
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  console.log(`Total Tests Run: ${total}`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Success Rate: ${Math.round((passed / total) * 100)}%`);
  console.log('======================================================\n');
}

runAllVerificationTests().catch(err => {
  console.error('Fatal test runner error:', err);
  process.exit(1);
});
