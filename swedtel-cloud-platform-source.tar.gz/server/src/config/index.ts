// ====================================================================
// SWEDTEL Cloud Management Platform - Server Configuration & Secret Loader
// ====================================================================

import dotenv from 'dotenv';
dotenv.config();

export interface ServerConfig {
  env: 'development' | 'staging' | 'production';
  port: number;
  jwtSecret: string;
  jwtExpiresIn: string;
  database: {
    url?: string;
    host?: string;
    port?: number;
    user?: string;
    password?: string;
    name?: string;
    ssl: boolean;
  };
  gemini: {
    apiKey: string;
    proModel: string;
    flashModel: string;
    flashLiteModel: string;
  };
  gcp: {
    projectId: string;
    region: string;
    wifAudience?: string;
    secretManagerPrefix: string;
  };
}

export const config: ServerConfig = {
  env: (process.env.NODE_ENV as 'development' | 'staging' | 'production') || 'development',
  port: parseInt(process.env.PORT || '4000', 10),
  jwtSecret: process.env.JWT_SECRET || 'swedtel-enterprise-jwt-secret-key-nordic-tech-2026-prod',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  database: {
    url: process.env.DATABASE_URL,
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    user: process.env.DB_USER || 'swedtel_admin',
    password: process.env.DB_PASSWORD || 'swedtel_password',
    name: process.env.DB_NAME || 'swedtel_cloud_db',
    ssl: process.env.DB_SSL === 'true',
  },
  gemini: {
    // In production on Google Cloud Run, Secret Manager mounts this or injects as env var
    apiKey: process.env.GEMINI_API_KEY || process.env.API_KEY || '',
    proModel: 'gemini-3.1-pro-preview',
    flashModel: 'gemini-3.5-flash',
    flashLiteModel: 'gemini-3.1-flash-lite-preview',
  },
  gcp: {
    projectId: process.env.GCP_PROJECT_ID || 'swedtel-cloud-platform',
    region: process.env.GCP_REGION || 'europe-north1',
    wifAudience: process.env.GCP_WIF_AUDIENCE,
    secretManagerPrefix: process.env.GCP_SECRET_PREFIX || 'projects/swedtel-cloud-platform/secrets/',
  },
};
