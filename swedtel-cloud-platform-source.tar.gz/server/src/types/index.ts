// ====================================================================
// SWEDTEL Cloud Management Platform - Core Domain Types & DTOs
// ====================================================================

export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  CLOUD_ENGINEER = 'CLOUD_ENGINEER',
  FINOPS_SPECIALIST = 'FINOPS_SPECIALIST',
  ACCOUNT_MANAGER = 'ACCOUNT_MANAGER',
  CUSTOMER_ADMIN = 'CUSTOMER_ADMIN',
  CUSTOMER_VIEWER = 'CUSTOMER_VIEWER'
}

export enum OrganizationType {
  PROVIDER = 'PROVIDER', // SWEDTEL Internal
  CUSTOMER = 'CUSTOMER'  // Tenant Organization
}

export enum CloudProvider {
  GCP = 'GCP',
  AWS = 'AWS',
  AZURE = 'AZURE'
}

export enum ResourceType {
  KUBERNETES_CLUSTER = 'KUBERNETES_CLUSTER',
  VIRTUAL_MACHINE = 'VIRTUAL_MACHINE',
  MANAGED_DATABASE = 'MANAGED_DATABASE',
  OBJECT_STORAGE = 'OBJECT_STORAGE',
  VPC_NETWORK = 'VPC_NETWORK',
  SERVERLESS_FUNCTION = 'SERVERLESS_FUNCTION'
}

export enum ResourceStatus {
  HEALTHY = 'HEALTHY',
  WARNING = 'WARNING',
  CRITICAL = 'CRITICAL',
  STOPPED = 'STOPPED'
}

export enum Severity {
  CRITICAL = 'CRITICAL',
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW',
  INFO = 'INFO'
}

export enum AlertStatus {
  OPEN = 'OPEN',
  ACKNOWLEDGED = 'ACKNOWLEDGED',
  IN_PROGRESS = 'IN_PROGRESS',
  RESOLVED = 'RESOLVED'
}

export enum TicketPriority {
  P1_CRITICAL = 'P1_CRITICAL',
  P2_HIGH = 'P2_HIGH',
  P3_MEDIUM = 'P3_MEDIUM',
  P4_LOW = 'P4_LOW'
}

export enum TicketStatus {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  WAITING_CUSTOMER = 'WAITING_CUSTOMER',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED'
}

export enum ConnectionType {
  WIF = 'WIF', // Google Cloud Workload Identity Federation (Keyless)
  STS_ASSUME_ROLE = 'STS_ASSUME_ROLE', // AWS STS Cross-Account IAM Role
  SERVICE_PRINCIPAL = 'SERVICE_PRINCIPAL', // Azure Entra ID Service Principal
  SECRET_MANAGER_REF = 'SECRET_MANAGER_REF'
}

// Server-Side Authorization & User Session Context
export interface AuthUserContext {
  userId: string;
  email: string;
  firstName: string;
  lastName: string;
  organizationId: string;
  organizationType: OrganizationType;
  role: UserRole;
  customerId?: string; // Set when user is scoped to a specific customer or operating on a tenant
  permissions: string[];
}

// Domain Entities
export interface Organization {
  id: string;
  name: string;
  code: string;
  type: OrganizationType;
  tier: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  organizationId: string;
  name: string;
  code: string;
  industry: string;
  contactEmail: string;
  phone?: string;
  tier: string;
  slaLevel: string;
  status: 'ACTIVE' | 'PROVISIONING' | 'SUSPENDED';
  monthlyBudget: number;
  monthlySpend?: number;
  securityScore?: number;
  cloudAccountsCount?: number;
  resourcesCount?: number;
  dedicatedEngineerId?: string;
  accountManagerId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CloudAccount {
  id: string;
  customerId: string;
  customerName?: string;
  provider: CloudProvider;
  name: string;
  accountOrProjectId: string;
  targetServiceAccount?: string;
  environment: 'PRODUCTION' | 'STAGING' | 'DEVELOPMENT' | 'DR';
  connectionType: ConnectionType;
  connectionMode: 'DEMO' | 'LIVE';
  authSecretName?: string;
  status: 'CONNECTED' | 'DEGRADED' | 'SYNC_PENDING' | 'AUTH_ERROR' | 'PERMISSION_ERROR' | 'API_NOT_ENABLED';
  lastSyncedAt?: string;
  lastSyncStatus?: 'SUCCESS' | 'FAILED' | 'SYNCING' | 'PENDING';
  lastSyncError?: string;
  isDemo: boolean;
  resourceCount?: number;
  monthlyCost?: number;
  createdAt: string;
  updatedAt: string;
}

export interface CloudResource {
  id: string;
  customerId: string;
  customerName?: string;
  cloudAccountId: string;
  projectId?: string;
  provider: CloudProvider;
  resourceType: ResourceType;
  resourceId: string;
  name: string;
  region: string;
  zone?: string;
  status: ResourceStatus;
  cpuUtilizationPct: number;
  memoryUtilizationPct: number;
  diskUtilizationPct: number;
  networkInMbps: number;
  networkOutMbps: number;
  monthlyCost: number;
  tags: Record<string, string>;
  isDemo: boolean;
  connectionMode?: 'DEMO' | 'LIVE';
  metadata?: Record<string, any>;
  lastTelemetryAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface CostRecord {
  id: string;
  customerId: string;
  customerName?: string;
  cloudAccountId: string;
  provider: CloudProvider;
  serviceName: string;
  projectIdentifier?: string;
  costDate: string;
  amount: number;
  currency: string;
  usageUnit?: string;
  usageQuantity?: number;
  isAnomaly: boolean;
  anomalyReason?: string;
  isDemo: boolean;
}

export interface Budget {
  id: string;
  customerId: string;
  customerName?: string;
  name: string;
  monthlyLimit: number;
  currentSpend: number;
  currency: string;
  alertThresholdPct: number;
  alertEmails: string[];
  status: 'ON_TRACK' | 'NEAR_LIMIT' | 'EXCEEDED';
  createdAt: string;
  updatedAt: string;
}

export interface Alert {
  id: string;
  customerId: string;
  customerName?: string;
  cloudAccountId?: string;
  resourceId?: string;
  title: string;
  description: string;
  severity: Severity;
  status: AlertStatus;
  source: string;
  metricName?: string;
  thresholdValue?: string;
  actualValue?: string;
  triggeredAt: string;
  resolvedAt?: string;
  resolvedByUserId?: string;
  resolutionNotes?: string;
}

export interface SecurityFinding {
  id: string;
  customerId: string;
  customerName?: string;
  cloudAccountId?: string;
  resourceId?: string;
  title: string;
  description: string;
  severity: Severity;
  complianceFramework: string;
  cisControlId: string;
  remediationSteps: string;
  status: 'OPEN' | 'REMEDIATING' | 'RESOLVED' | 'SUPPRESSED';
  isAutomatedFixAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AutomationWorkflow {
  id: string;
  customerId: string;
  customerName?: string;
  name: string;
  description?: string;
  targetProvider: 'GCP' | 'AWS' | 'AZURE' | 'ALL';
  triggerType: 'SCHEDULE' | 'THRESHOLD' | 'SECURITY_EVENT' | 'MANUAL';
  scheduleCron?: string;
  thresholdMetric?: string;
  thresholdValue?: number;
  actionType: string;
  actionPayload: Record<string, unknown>;
  requiresApproval: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AutomationExecution {
  id: string;
  workflowId: string;
  workflowName?: string;
  customerId: string;
  triggeredBy: string;
  status: 'RUNNING' | 'COMPLETED' | 'FAILED' | 'PENDING_APPROVAL' | 'REJECTED';
  startedAt: string;
  finishedAt?: string;
  durationMs?: number;
  executionLog?: string;
  approvedByUserId?: string;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  customerId: string;
  customerName?: string;
  createdByUserId: string;
  createdByName?: string;
  assignedToUserId?: string;
  assignedToName?: string;
  title: string;
  description: string;
  category: string;
  priority: TicketPriority;
  status: TicketStatus;
  slaDueAt?: string;
  messages?: TicketMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface TicketMessage {
  id: string;
  ticketId: string;
  senderUserId: string;
  senderName: string;
  message: string;
  isInternalNote: boolean;
  attachments: string[];
  createdAt: string;
}

export interface Report {
  id: string;
  customerId: string;
  customerName?: string;
  title: string;
  type: 'FINOPS_MONTHLY' | 'CIS_SECURITY_AUDIT' | 'SLA_UPTIME' | 'CARBON_SUSTAINABILITY';
  periodStart: string;
  periodEnd: string;
  generatedByUserId?: string;
  fileUrl?: string;
  summaryData: Record<string, unknown>;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  organizationId?: string;
  customerId?: string;
  customerName?: string;
  userId?: string;
  userEmail: string;
  userRole: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  ipAddress?: string;
  userAgent?: string;
  status: 'SUCCESS' | 'DENIED' | 'FAILURE' | 'PENDING';
  details: Record<string, unknown>;
  createdAt: string;
}
