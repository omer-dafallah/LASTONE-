// ====================================================================
// SWEDTEL Cloud Management Platform - Cloud Provider Abstraction Layer
// ====================================================================

import { CloudProvider, CloudResource, CostRecord, CloudAccount } from '../types/index.js';

export interface ProviderValidationResult {
  isValid: boolean;
  provider: CloudProvider;
  accountOrProjectId: string;
  errorCode?: string;
  errorMessage?: string;
  detectedPermissions: string[];
  identityPrincipal: string;
  projectDetails?: {
    projectId: string;
    projectNumber?: string;
    displayName?: string;
    state?: string;
    createTime?: string;
  };
}

export interface MetricSample {
  timestamp: string;
  cpuPct: number;
  memoryPct: number;
  diskPct: number;
  networkInMbps: number;
  networkOutMbps: number;
}

export interface CloudProviderAdapter {
  readonly provider: CloudProvider;
  readonly isLiveIntegration: boolean; // Indicates if real network calls to Cloud SDK are active

  /**
   * Validates account credentials (e.g. STS AssumeRole, WIF Service Account, Azure SP)
   */
  validateConnection(account: CloudAccount): Promise<ProviderValidationResult>;

  /**
   * Discovers and indexes all cloud resources across regions
   */
  discoverResources(account: CloudAccount): Promise<CloudResource[]>;

  /**
   * Fetches real-time telemetry metrics for a specific resource
   */
  fetchResourceTelemetry(account: CloudAccount, resourceId: string): Promise<MetricSample>;

  /**
   * Queries provider billing / cost & usage datasets
   */
  fetchCostRecords(account: CloudAccount, startDate: string, endDate: string): Promise<CostRecord[]>;

  /**
   * Safely triggers an automation action (e.g. Stop VM, Resize Cluster)
   */
  executeAutomationAction(
    account: CloudAccount,
    actionType: string,
    payload: Record<string, unknown>
  ): Promise<{ success: boolean; log: string }>;
}
