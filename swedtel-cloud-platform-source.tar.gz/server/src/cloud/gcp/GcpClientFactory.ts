// ====================================================================
// SWEDTEL Cloud Management Platform - GCP Client & Authentication Factory
// Supports:
// 1. Local Application Default Credentials (ADC) for development / test
// 2. Server-side Google Cloud authentication in Cloud Run
// 3. Service Account Impersonation for Customer Target Service Accounts
// ====================================================================

import { GoogleAuth, Impersonated } from 'google-auth-library';
import { google, compute_v1, storage_v1, container_v1, sqladmin_v1beta4, monitoring_v3, cloudresourcemanager_v3, cloudasset_v1 } from 'googleapis';

export interface GcpAuthOptions {
  projectId: string;
  targetServiceAccount?: string; // e.g. swedtel-reader@customer-proj.iam.gserviceaccount.com
  callerServiceAccount?: string; // Default SWEDTEL caller SA in Cloud Run
}

export type GcpErrorCode =
  | 'AUTHENTICATION_ERROR'
  | 'PERMISSION_ERROR'
  | 'API_NOT_ENABLED'
  | 'PROJECT_NOT_FOUND'
  | 'IMPERSONATION_ERROR'
  | 'NETWORK_ERROR'
  | 'INVALID_CONFIG'
  | 'UNKNOWN_ERROR';

export interface GcpServiceClients {
  auth: any;
  projectId: string;
  targetServiceAccount?: string;
  resourceManager: cloudresourcemanager_v3.Cloudresourcemanager;
  compute: compute_v1.Compute;
  storage: storage_v1.Storage;
  container: container_v1.Container;
  sqladmin: sqladmin_v1beta4.Sqladmin;
  monitoring: monitoring_v3.Monitoring;
  asset: cloudasset_v1.Cloudasset;
}

export class GcpClientFactory {
  private static authCache = new Map<string, any>();

  /**
   * Generates or retrieves an authenticated client configured for direct ADC
   * or Service Account Impersonation.
   */
  public static async getAuthenticatedClients(options: GcpAuthOptions): Promise<GcpServiceClients> {
    const { projectId, targetServiceAccount } = options;

    if (!projectId) {
      throw this.createError('INVALID_CONFIG', 'GCP Project ID must not be empty.');
    }

    const cacheKey = `${projectId}::${targetServiceAccount || 'default'}`;
    let authClient = this.authCache.get(cacheKey);

    if (!authClient) {
      authClient = await this.createAuthClient(options);
      this.authCache.set(cacheKey, authClient);
    }

    return {
      auth: authClient,
      projectId,
      targetServiceAccount,
      resourceManager: google.cloudresourcemanager({ version: 'v3', auth: authClient }),
      compute: google.compute({ version: 'v1', auth: authClient }),
      storage: google.storage({ version: 'v1', auth: authClient }),
      container: google.container({ version: 'v1', auth: authClient }),
      sqladmin: google.sqladmin({ version: 'v1beta4', auth: authClient }),
      monitoring: google.monitoring({ version: 'v3', auth: authClient }),
      asset: google.cloudasset({ version: 'v1', auth: authClient })
    };
  }

  /**
   * Creates an Auth Client using either Direct GoogleAuth or ImpersonatedAccountCredential
   */
  private static async createAuthClient(options: GcpAuthOptions): Promise<any> {
    const { projectId, targetServiceAccount } = options;

    const scopes = [
      'https://www.googleapis.com/auth/cloud-platform.read-only',
      'https://www.googleapis.com/auth/compute.readonly',
      'https://www.googleapis.com/auth/devstorage.read_only',
      'https://www.googleapis.com/auth/monitoring.read',
      'https://www.googleapis.com/auth/sqlservice.admin'
    ];

    try {
      // 1. Initialize Base GoogleAuth (Uses ADC or Cloud Run Metadata Server)
      const baseAuth = new GoogleAuth({
        scopes,
        projectId
      });

      // 2. If no target Service Account is specified, use base ADC/Cloud Run credentials
      if (!targetServiceAccount) {
        return baseAuth;
      }

      // 3. Service Account Impersonation via iamcredentials
      const sourceClient = await baseAuth.getClient();
      const impersonatedClient = new Impersonated({
        sourceClient: sourceClient as any,
        targetPrincipal: targetServiceAccount,
        lifetime: 3600, // 1 hour token lifetime
        targetScopes: scopes
      });

      return impersonatedClient;
    } catch (err: any) {
      throw this.classifyGcpError(err, 'Failed to initialize Google Cloud Authentication credentials');
    }
  }

  /**
   * Classifies error responses into structured SWEDTEL error codes
   */
  public static classifyGcpError(error: any, fallbackMessage: string): Error & { code: GcpErrorCode; details?: any } {
    const errObj = error || {};
    const message: string = errObj.message || fallbackMessage || 'Unknown Google Cloud error';
    const status: number = errObj.status || errObj.code || 0;
    const errors: any[] = errObj.errors || [];

    let code: GcpErrorCode = 'UNKNOWN_ERROR';

    if (status === 404 || message.toLowerCase().includes('not found') || message.toLowerCase().includes('project not found')) {
      code = 'PROJECT_NOT_FOUND';
    } else if (
      status === 403 &&
      (message.toLowerCase().includes('has not been used') ||
        message.toLowerCase().includes('is not enabled') ||
        message.toLowerCase().includes('service disabled') ||
        message.toLowerCase().includes('api not enabled'))
    ) {
      code = 'API_NOT_ENABLED';
    } else if (
      message.toLowerCase().includes('impersonat') ||
      message.toLowerCase().includes('serviceaccounttokencreator') ||
      message.toLowerCase().includes('iamcredentials')
    ) {
      code = 'IMPERSONATION_ERROR';
    } else if (
      status === 403 ||
      message.toLowerCase().includes('permission denied') ||
      message.toLowerCase().includes('caller does not have required permission')
    ) {
      code = 'PERMISSION_ERROR';
    } else if (
      status === 401 ||
      message.toLowerCase().includes('unauthenticated') ||
      message.toLowerCase().includes('invalid credentials') ||
      message.toLowerCase().includes('could not load the default credentials')
    ) {
      code = 'AUTHENTICATION_ERROR';
    } else if (
      message.toLowerCase().includes('econnrefused') ||
      message.toLowerCase().includes('etimedout') ||
      message.toLowerCase().includes('enotfound') ||
      message.toLowerCase().includes('network')
    ) {
      code = 'NETWORK_ERROR';
    }

    const err = new Error(`[${code}] ${message}`) as Error & { code: GcpErrorCode; details?: any };
    err.code = code;
    err.details = {
      originalStatus: status,
      originalMessage: message,
      errors
    };
    return err;
  }

  private static createError(code: GcpErrorCode, message: string): Error & { code: GcpErrorCode } {
    const err = new Error(`[${code}] ${message}`) as Error & { code: GcpErrorCode };
    err.code = code;
    return err;
  }
}
