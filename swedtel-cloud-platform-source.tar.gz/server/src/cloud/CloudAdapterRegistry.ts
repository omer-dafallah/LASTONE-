// ====================================================================
// SWEDTEL Cloud Management Platform - Cloud Adapter Registry Factory
// ====================================================================

import { CloudProvider } from '../types/index.js';
import { CloudProviderAdapter } from './CloudProviderAdapter.js';
import { GoogleCloudProvider } from './GoogleCloudProvider.js';
import { AWSProvider, AzureProvider } from './AWSProvider.js';

export class CloudAdapterRegistry {
  private static adapters: Map<CloudProvider, CloudProviderAdapter> = new Map<CloudProvider, CloudProviderAdapter>([
    [CloudProvider.GCP, new GoogleCloudProvider()],
    [CloudProvider.AWS, new AWSProvider()],
    [CloudProvider.AZURE, new AzureProvider()]
  ]);

  public static getAdapter(provider: CloudProvider): CloudProviderAdapter {
    const adapter = this.adapters.get(provider);
    if (!adapter) {
      throw new Error(`Unsupported cloud provider adapter: ${provider}`);
    }
    return adapter;
  }

  public static registerAdapter(provider: CloudProvider, adapter: CloudProviderAdapter): void {
    this.adapters.set(provider, adapter);
  }
}
