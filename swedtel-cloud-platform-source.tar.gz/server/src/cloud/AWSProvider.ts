// ====================================================================
// SWEDTEL Cloud Management Platform - AWS & Azure Provider Adapters
// ====================================================================

import {
  CloudProviderAdapter,
  ProviderValidationResult,
  MetricSample
} from './CloudProviderAdapter.js';
import {
  CloudProvider,
  CloudAccount,
  CloudResource,
  CostRecord,
  ResourceType,
  ResourceStatus
} from '../types/index.js';

export class AWSProvider implements CloudProviderAdapter {
  public readonly provider = CloudProvider.AWS;
  public readonly isLiveIntegration = false; // Safe mock adapter until AWS STS role is provisioned

  public async validateConnection(account: CloudAccount): Promise<ProviderValidationResult> {
    const accountId = account.accountOrProjectId.trim();
    const isValidId = /^\d{12}$/.test(accountId);

    if (!isValidId) {
      return {
        isValid: false,
        provider: CloudProvider.AWS,
        accountOrProjectId: accountId,
        errorMessage: 'Invalid AWS Account ID. Must be a 12-digit numeric identifier.',
        detectedPermissions: [],
        identityPrincipal: 'arn:aws:iam::526512498681:role/SwedtelManagementRole'
      };
    }

    return {
      isValid: true,
      provider: CloudProvider.AWS,
      accountOrProjectId: accountId,
      detectedPermissions: [
        'sts:AssumeRole',
        'ec2:DescribeInstances',
        'cloudwatch:GetMetricData',
        'ce:GetCostAndUsage'
      ],
      identityPrincipal: `arn:aws:iam::${accountId}:role/SwedtelCloudCrossAccountRole`
    };
  }

  public async discoverResources(account: CloudAccount): Promise<CloudResource[]> {
    const now = new Date().toISOString();
    return [
      {
        id: `res-ec2-${account.id}`,
        customerId: account.customerId,
        customerName: account.customerName,
        cloudAccountId: account.id,
        provider: CloudProvider.AWS,
        resourceType: ResourceType.VIRTUAL_MACHINE,
        resourceId: 'i-0a883921049bfe91',
        name: 'ec2-telehealth-webrtc-node01',
        region: 'eu-north-1',
        zone: 'eu-north-1a',
        status: ResourceStatus.WARNING,
        cpuUtilizationPct: 89.2,
        memoryUtilizationPct: 92.5,
        diskUtilizationPct: 44.0,
        networkInMbps: 1200.0,
        networkOutMbps: 2100.0,
        monthlyCost: 1850.00,
        tags: { service: 'webrtc', autoscaling: 'enabled' },
        isDemo: true,
        lastTelemetryAt: now,
        createdAt: now,
        updatedAt: now
      }
    ];
  }

  public async fetchResourceTelemetry(account: CloudAccount, resourceId: string): Promise<MetricSample> {
    return {
      timestamp: new Date().toISOString(),
      cpuPct: 88.0 + Math.random() * 5.0,
      memoryPct: 91.0 + Math.random() * 3.0,
      diskPct: 44.0,
      networkInMbps: 1250.0,
      networkOutMbps: 2150.0
    };
  }

  public async fetchCostRecords(account: CloudAccount, startDate: string, endDate: string): Promise<CostRecord[]> {
    const today = new Date().toISOString().split('T')[0];
    return [
      {
        id: `cost-aws-ec2-${Date.now()}`,
        customerId: account.customerId,
        customerName: account.customerName,
        cloudAccountId: account.id,
        provider: CloudProvider.AWS,
        serviceName: 'Amazon EC2 Compute',
        projectIdentifier: account.accountOrProjectId,
        costDate: today,
        amount: 185.00,
        currency: 'EUR',
        isAnomaly: true,
        anomalyReason: 'Unexpected +145% spike in unattached gp3 EBS IOPS during batch ingest',
        isDemo: true
      }
    ];
  }

  public async executeAutomationAction(
    account: CloudAccount,
    actionType: string,
    payload: Record<string, unknown>
  ): Promise<{ success: boolean; log: string }> {
    return {
      success: true,
      log: `[AWS Adapter (Safe Simulation)] Simulated ${actionType} on account ${account.accountOrProjectId}. No destructive live API calls made.`
    };
  }
}

export class AzureProvider implements CloudProviderAdapter {
  public readonly provider = CloudProvider.AZURE;
  public readonly isLiveIntegration = false; // Safe mock adapter until Azure Service Principal is provisioned

  public async validateConnection(account: CloudAccount): Promise<ProviderValidationResult> {
    const subscriptionId = account.accountOrProjectId.trim();
    const isValidUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(subscriptionId);

    if (!isValidUuid) {
      return {
        isValid: false,
        provider: CloudProvider.AZURE,
        accountOrProjectId: subscriptionId,
        errorMessage: 'Invalid Azure Subscription ID. Must be a valid UUID.',
        detectedPermissions: [],
        identityPrincipal: 'swedtel-sp@swedtel-azure.onmicrosoft.com'
      };
    }

    return {
      isValid: true,
      provider: CloudProvider.AZURE,
      accountOrProjectId: subscriptionId,
      detectedPermissions: [
        'Microsoft.Resources/subscriptions/read',
        'Microsoft.Compute/virtualMachines/read',
        'Microsoft.CostManagement/query/action'
      ],
      identityPrincipal: 'swedtel-sp@swedtel-azure.onmicrosoft.com'
    };
  }

  public async discoverResources(account: CloudAccount): Promise<CloudResource[]> {
    const now = new Date().toISOString();
    return [
      {
        id: `res-azsql-${account.id}`,
        customerId: account.customerId,
        customerName: account.customerName,
        cloudAccountId: account.id,
        provider: CloudProvider.AZURE,
        resourceType: ResourceType.MANAGED_DATABASE,
        resourceId: 'azsql-sthlm-ledger-db',
        name: 'azsql-sthlm-ledger-db',
        region: 'swedencentral',
        status: ResourceStatus.HEALTHY,
        cpuUtilizationPct: 35.0,
        memoryUtilizationPct: 60.0,
        diskUtilizationPct: 50.0,
        networkInMbps: 450.0,
        networkOutMbps: 650.0,
        monthlyCost: 18900.00,
        tags: { env: 'prod', region: 'sweden-central' },
        isDemo: true,
        lastTelemetryAt: now,
        createdAt: now,
        updatedAt: now
      }
    ];
  }

  public async fetchResourceTelemetry(account: CloudAccount, resourceId: string): Promise<MetricSample> {
    return {
      timestamp: new Date().toISOString(),
      cpuPct: 34.0 + Math.random() * 4.0,
      memoryPct: 59.0 + Math.random() * 3.0,
      diskPct: 50.0,
      networkInMbps: 460.0,
      networkOutMbps: 670.0
    };
  }

  public async fetchCostRecords(account: CloudAccount, startDate: string, endDate: string): Promise<CostRecord[]> {
    const today = new Date().toISOString().split('T')[0];
    return [
      {
        id: `cost-az-sql-${Date.now()}`,
        customerId: account.customerId,
        customerName: account.customerName,
        cloudAccountId: account.id,
        provider: CloudProvider.AZURE,
        serviceName: 'Azure SQL Managed Instance',
        projectIdentifier: account.accountOrProjectId,
        costDate: today,
        amount: 630.00,
        currency: 'EUR',
        isAnomaly: false,
        isDemo: true
      }
    ];
  }

  public async executeAutomationAction(
    account: CloudAccount,
    actionType: string,
    payload: Record<string, unknown>
  ): Promise<{ success: boolean; log: string }> {
    return {
      success: true,
      log: `[Azure Adapter (Safe Simulation)] Simulated ${actionType} on subscription ${account.accountOrProjectId}. No destructive live API calls made.`
    };
  }
}
